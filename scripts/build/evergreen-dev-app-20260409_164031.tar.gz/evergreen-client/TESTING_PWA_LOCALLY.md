# Testing PWA Locally with HTTPS

To test PWA features (including theme-color status bar) before production, you need HTTPS. Here are several options:

## Option 1: Use ngrok (Easiest - Recommended)

### Setup:
1. **Install ngrok**: Download from https://ngrok.com/download
2. **Sign up** for a free account (gets you a free HTTPS URL)
3. **Get your auth token** from the ngrok dashboard

### Run:
```bash
# Terminal 1: Start your backend
cd evergreen-server
python main.py

# Terminal 2: Start your frontend
cd evergreen-client
pnpm run dev:network

# Terminal 3: Create HTTPS tunnel for frontend
ngrok http 3000

# Terminal 4: Create HTTPS tunnel for backend (optional, or use ngrok URL)
ngrok http 8000
```

### Use:
- Use the ngrok HTTPS URL (e.g., `https://abc123.ngrok.io`) on your phone
- Update the API URL in the debug component to use the backend ngrok URL
- Install as PWA - Chrome will allow full PWA installation over HTTPS
- Test theme colors in the installed PWA

## Option 2: Use localtunnel (Free, No Signup)

### Setup:
```bash
npm install -g localtunnel
```

### Run:
```bash
# Terminal 1: Start your backend
cd evergreen-server
python main.py

# Terminal 2: Start your frontend
cd evergreen-client
pnpm run dev:network

# Terminal 3: Create HTTPS tunnel for frontend
lt --port 3000

# Terminal 4: Create HTTPS tunnel for backend
lt --port 8000
```

### Use:
- Use the provided HTTPS URLs on your phone
- Update API URL in debug component
- Install as PWA and test

## Option 3: Use Cloudflare Tunnel (Free, More Setup)

1. Install cloudflared: https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/install-and-setup/
2. Run: `cloudflared tunnel --url http://localhost:3000`
3. Use the provided HTTPS URL

## Option 4: Use mkcert for Local HTTPS (Most Complex)

This creates a local HTTPS certificate that your phone needs to trust.

### Setup:
```bash
# Install mkcert
# Windows: choco install mkcert
# Mac: brew install mkcert
# Linux: See https://github.com/FiloSottile/mkcert

# Create local CA
mkcert -install

# Generate certificates
cd evergreen-client
mkcert localhost 192.168.1.14

# Rename to cert.pem and key.pem
```

Then configure Next.js to use HTTPS (requires custom server setup).

## Quick Test with ngrok (Recommended)

1. Install ngrok: https://ngrok.com/download
2. Sign up and get auth token
3. Run: `ngrok config add-authtoken YOUR_TOKEN`
4. Start your servers:
   ```bash
   # Backend
   cd evergreen-server && python main.py
   
   # Frontend  
   cd evergreen-client && pnpm run dev:network
   
   # ngrok for frontend
   ngrok http 3000
   ```
5. Use the HTTPS URL from ngrok on your phone
6. Update API URL in debug component to point to backend
7. Install as PWA - full PWA features will work!

## Notes:
- ngrok free tier gives you a random URL each time (changes on restart)
- ngrok paid plans give you fixed URLs
- localtunnel is free but URLs are temporary
- All methods allow full PWA installation with HTTPS

