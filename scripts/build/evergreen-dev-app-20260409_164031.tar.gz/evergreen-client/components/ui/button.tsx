import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"
import { useGlassStyles } from "@/hooks/use-glass-styles"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full text-sm font-medium ring-offset-background transition-transform duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 relative overflow-hidden",
  {
    variants: {
      variant: {
        default: "text-emerald-950 dark:text-white hover:scale-105 active:scale-95 border border-primary/60 dark:border-primary/70",
        destructive:
          "text-white hover:scale-105 active:scale-95 border border-red-500/30 dark:border-red-500/30",
        outline:
          "text-foreground dark:text-foreground border border-border hover:scale-105 active:scale-95",
        secondary:
          "text-foreground dark:text-foreground hover:scale-105 active:scale-95 border border-border dark:[&_svg]:text-white/90",
        ghost: "text-foreground dark:text-foreground hover:scale-105 active:scale-95 border border-border/50 dark:border-border/30",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-full px-3",
        lg: "h-11 rounded-full px-8",
        icon: "h-10 w-10 rounded-full",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "default", size, asChild = false, style, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    
    // Check if evergreen-button class is present - if so, skip inline background/border styles
    const hasEvergreenClass = className?.includes("evergreen-button")
    const hasCustomBg = className?.includes("bg-")
    
    // Use shared glass styles hook
    const glassStyles = useGlassStyles({
      variant,
      hasCustomBg,
      hasEvergreenClass,
      customStyle: style,
    })
    
    return (
      <Comp
        className={cn(
          buttonVariants({ variant, size, className }),
          variant !== "link" && "liquid-glass-highlight"
        )}
        style={glassStyles}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
