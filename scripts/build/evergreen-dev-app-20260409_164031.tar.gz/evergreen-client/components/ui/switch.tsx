"use client"

import * as React from "react"
import * as SwitchPrimitives from "@radix-ui/react-switch"

import { cn } from "@/lib/utils"

const Switch = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitives.Root>,
  React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root>
>(({ className, ...props }, ref) => {
  const rootRef = React.useRef<HTMLButtonElement>(null)
  const combinedRef = React.useCallback(
    (node: HTMLButtonElement | null) => {
      rootRef.current = node
      if (typeof ref === "function") {
        ref(node)
      } else if (ref) {
        ref.current = node
      }
    },
    [ref]
  )

  React.useEffect(() => {
    const root = rootRef.current
    if (!root) return

    const updateBackground = () => {
      const isChecked = root.getAttribute("data-state") === "checked"
      const primaryValue = getComputedStyle(document.documentElement).getPropertyValue("--primary").trim()
      
      if (isChecked && primaryValue) {
        // Check if primary value is in RGB format (3 numbers without %) or HSL format (has %)
        if (primaryValue.includes("%")) {
          // HSL format (e.g., "145 100% 35%")
          root.style.backgroundColor = `hsl(${primaryValue})`
        } else {
          // RGB format (e.g., "16 185 129")
          const rgbValues = primaryValue.split(/\s+/).filter(v => v)
          if (rgbValues.length === 3) {
            root.style.backgroundColor = `rgb(${primaryValue})`
          } else {
            // Fallback to HSL
            root.style.backgroundColor = `hsl(${primaryValue})`
          }
        }
      } else {
        root.style.backgroundColor = ""
      }
    }

    // Initial update
    updateBackground()

    // Watch for state changes
    const observer = new MutationObserver(updateBackground)
    observer.observe(root, {
      attributes: true,
      attributeFilter: ["data-state"],
    })

    // Watch for CSS variable changes (theme color changes)
    const styleObserver = new MutationObserver(updateBackground)
    styleObserver.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    })

    return () => {
      observer.disconnect()
      styleObserver.disconnect()
    }
  }, [])

  return (
    <SwitchPrimitives.Root
      className={cn(
        "peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=unchecked]:bg-muted",
        className
      )}
      style={{
        borderRadius: '9999px',
      }}
      {...props}
      ref={combinedRef}
    >
      <SwitchPrimitives.Thumb
        className={cn(
          "pointer-events-none block h-5 w-5 rounded-full shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0 border border-border/50",
          "bg-white dark:bg-gray-300",
          "data-[state=checked]:bg-white dark:data-[state=checked]:bg-black"
        )}
      />
    </SwitchPrimitives.Root>
  )
})
Switch.displayName = SwitchPrimitives.Root.displayName

export { Switch }
