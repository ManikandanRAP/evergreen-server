"use client"

import * as React from "react"
import { useEffect, useState } from "react"
import * as AlertDialogPrimitive from "@radix-ui/react-alert-dialog"
import { X } from "lucide-react"

import { cn } from "@/lib/utils"
import { buttonVariants } from "@/components/ui/button"
import { useGlassStyles } from "@/hooks/use-glass-styles"

const AlertDialog = AlertDialogPrimitive.Root

const AlertDialogTrigger = AlertDialogPrimitive.Trigger

const AlertDialogPortal = AlertDialogPrimitive.Portal

const AlertDialogOverlay = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Overlay
    className={cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    )}
    {...props}
    ref={ref}
  />
))
AlertDialogOverlay.displayName = AlertDialogPrimitive.Overlay.displayName

const AlertDialogContent = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Content>
>(({ className, ...props }, ref) => {
  const [isDark, setIsDark] = useState(false)
  
  useEffect(() => {
    const checkTheme = () => {
      setIsDark(document.documentElement.classList.contains('dark'))
    }
    checkTheme()
    
    const observer = new MutationObserver(checkTheme)
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    })
    
    return () => observer.disconnect()
  }, [])
  
  return (
    <AlertDialogPortal>
      <AlertDialogOverlay />
      <AlertDialogPrimitive.Content
        ref={ref}
        className={cn(
          "fixed left-[50%] top-[50%] z-50 w-full max-w-[90vw] sm:max-w-md md:max-w-lg translate-x-[-50%] translate-y-[-50%] gap-0 border border-black/10 dark:border-white/5 rounded-2xl shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] relative overflow-hidden flex flex-col",
          className
        )}
        style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          maxHeight: '90vh',
          boxShadow: isDark 
            ? "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)"
            : "0 4px 24px rgba(0, 0, 0, 0.12), 0 2px 6px rgba(0, 0, 0, 0.08)",
          backgroundColor: isDark 
            ? "rgb(20, 20, 20)" 
            : "rgb(255, 255, 255)",
          ...props.style,
        }}
        {...props}
      />
    </AlertDialogPortal>
  )
})
AlertDialogContent.displayName = AlertDialogPrimitive.Content.displayName

const AlertDialogHeader = ({
  className,
  hideClose = false,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { hideClose?: boolean }) => {
  const childrenArray = React.Children.toArray(props.children)
  const titleElement = childrenArray.find((child) => {
    if (React.isValidElement(child)) {
      const childType = child.type as any
      return childType === AlertDialogTitle || childType?.displayName === "AlertDialogTitle"
    }
    return false
  })
  const otherChildren = childrenArray.filter((child) => {
    if (React.isValidElement(child)) {
      const childType = child.type as any
      return childType !== AlertDialogTitle && childType?.displayName !== "AlertDialogTitle"
    }
    return true
  })

  return (
    <div
      className={cn(
        "flex flex-row items-center justify-between px-6 py-4 border-b border-border bg-muted/30",
        className
      )}
      {...props}
    >
      <div className="flex-1 min-w-0">
        {titleElement}
        {otherChildren.length > 0 && (
          <div className="mt-1">
            {otherChildren}
          </div>
        )}
      </div>
      {!hideClose && (
        <AlertDialogPrimitive.Cancel
          className={cn(
            buttonVariants({ variant: "outline", size: "sm" }),
            "navigation-button h-9 w-9 rounded-full flex items-center justify-center p-0 flex-shrink-0 ml-4"
          )}
          style={{
            boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
          }}
        >
          <X className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </AlertDialogPrimitive.Cancel>
      )}
    </div>
  )
}
AlertDialogHeader.displayName = "AlertDialogHeader"

const AlertDialogFooter = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "flex flex-col gap-2 sm:flex-row sm:justify-end sm:gap-2 px-6 py-4 border-t border-border bg-muted/30",
      className
    )}
    {...props}
  />
)
AlertDialogFooter.displayName = "AlertDialogFooter"

const AlertDialogTitle = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Title
    ref={ref}
    className={cn("text-lg sm:text-xl font-semibold text-left flex items-center gap-2", className)}
    {...props}
  />
))
AlertDialogTitle.displayName = AlertDialogPrimitive.Title.displayName

const AlertDialogDescription = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground px-6 py-4", className)}
    {...props}
  />
))
AlertDialogDescription.displayName =
  AlertDialogPrimitive.Description.displayName

const AlertDialogAction = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Action>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Action>
>(({ className, style, ...props }, ref) => {
  // Check if custom background color is provided (like bg-red-600)
  const hasCustomBg = className?.includes('bg-')
  
  // Use shared glass styles hook
  const glassStyles = useGlassStyles({
    variant: "default",
    hasCustomBg,
    customStyle: style,
  })
  
  return (
    <AlertDialogPrimitive.Action
      ref={ref}
      className={cn(buttonVariants(), "w-full sm:w-auto liquid-glass-highlight", className)}
      style={glassStyles}
      {...(props as any)}
    />
  )
})
AlertDialogAction.displayName = AlertDialogPrimitive.Action.displayName

const AlertDialogCancel = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Cancel>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Cancel>
>(({ className, style, ...props }, ref) => {
  // Use shared glass styles hook
  const glassStyles = useGlassStyles({
    variant: "outline",
    customStyle: style,
  })
  
  return (
    <AlertDialogPrimitive.Cancel
      ref={ref}
      className={cn(
        buttonVariants({ variant: "outline" }),
        "w-full sm:w-auto liquid-glass-highlight",
        className
      )}
      style={glassStyles}
      {...(props as any)}
    />
  )
})
AlertDialogCancel.displayName = AlertDialogPrimitive.Cancel.displayName

export {
  AlertDialog,
  AlertDialogPortal,
  AlertDialogOverlay,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
}
