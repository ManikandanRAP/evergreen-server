"use client"

import * as React from "react"
import * as PopoverPrimitive from "@radix-ui/react-popover"

import { cn } from "@/lib/utils"

// Helper to check if liquid glass is enabled
const isLiquidGlassEnabled = (): boolean => {
  if (typeof window === "undefined") return true
  try {
    const stored = localStorage.getItem("evergreen_user_settings")
    if (stored) {
      const parsed = JSON.parse(stored)
      return parsed.liquidGlassEnabled !== false
    }
  } catch (error) {
    // Ignore errors
  }
  return true
}

const Popover = PopoverPrimitive.Root

const PopoverTrigger = PopoverPrimitive.Trigger

const PopoverContent = React.forwardRef<
  React.ElementRef<typeof PopoverPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof PopoverPrimitive.Content>
>(({ className, align = "center", sideOffset = 4, ...props }, ref) => {
  const [isDark, setIsDark] = React.useState(false)
  const [liquidGlassEnabled, setLiquidGlassEnabled] = React.useState(true)
  
  React.useEffect(() => {
    const checkTheme = () => {
      setIsDark(document.documentElement.classList.contains('dark'))
    }
    checkTheme()
    
    const observer = new MutationObserver(checkTheme)
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    })
    
    return () => observer.disconnect()
  }, [])

  React.useEffect(() => {
    const checkLiquidGlass = () => {
      setLiquidGlassEnabled(isLiquidGlassEnabled())
    }
    checkLiquidGlass()
    const interval = setInterval(checkLiquidGlass, 100)
    return () => clearInterval(interval)
  }, [])
  
  const bgColor = liquidGlassEnabled
    ? (isDark ? "rgba(20, 20, 20, 0.95)" : "rgba(255, 255, 255, 0.95)")
    : (isDark ? "hsl(var(--popover))" : "hsl(var(--popover))")
  
  return (
    <PopoverPrimitive.Portal>
      <PopoverPrimitive.Content
        ref={ref}
        align={align}
        sideOffset={sideOffset}
        className={cn(
          "z-[60] w-72 rounded-2xl border border-border p-4 text-popover-foreground outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 relative overflow-hidden",
          className
        )}
        style={{
          backgroundColor: bgColor,
          boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
        }}
        {...props}
      />
    </PopoverPrimitive.Portal>
  )
})
PopoverContent.displayName = PopoverPrimitive.Content.displayName

export { Popover, PopoverTrigger, PopoverContent }
