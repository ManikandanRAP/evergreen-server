import * as React from "react"

import { cn } from "@/lib/utils"

interface InputProps extends React.ComponentProps<"input"> {
  endAdornment?: React.ReactNode
  wrapperClassName?: string
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, wrapperClassName, type, endAdornment, ...props }, ref) => {
    const [isDark, setIsDark] = React.useState(false)
    
    React.useEffect(() => {
      const checkTheme = () => {
        setIsDark(document.documentElement.classList.contains('dark'))
      }
      checkTheme()
      
      const observer = new MutationObserver(checkTheme)
      observer.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['class']
      })
      
      return () => observer.disconnect()
    }, [])
    
    return (
      <div 
        className={cn(
          "relative w-full h-10 rounded-full input-wrapper",
          wrapperClassName
        )}
        style={{
          backgroundColor: isDark 
            ? "rgba(255, 255, 255, 0.1)"
            : "rgba(255, 255, 255, 0.9)",
          boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
          border: "1px solid hsl(var(--border))",
        }}
      >
        <input
          type={type}
          className={cn(
            "flex h-full w-full rounded-full border-0 outline-none px-3 py-2 text-sm text-foreground ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 relative z-10 bg-transparent transition-all duration-300",
            endAdornment && "pr-10",
            className
          )}
          style={{
            border: "none",
            outline: "none",
            boxShadow: "none",
          }}
          ref={ref}
          {...props}
        />
        {endAdornment && (
          <div className="absolute right-0 top-0 h-full flex items-center z-20 pointer-events-none">
            <div className="pointer-events-auto h-full">
              {endAdornment}
            </div>
          </div>
        )}
      </div>
    )
  }
)
Input.displayName = "Input"

export { Input }
