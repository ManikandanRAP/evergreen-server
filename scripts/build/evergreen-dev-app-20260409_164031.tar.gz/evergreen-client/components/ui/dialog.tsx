"use client"

import * as React from "react"
import * as DialogPrimitive from "@radix-ui/react-dialog"
import { X } from "lucide-react"

import { cn } from "@/lib/utils"
import { buttonVariants } from "@/components/ui/button"

const Dialog = DialogPrimitive.Root

const DialogTrigger = DialogPrimitive.Trigger

const DialogPortal = DialogPrimitive.Portal

const DialogClose = DialogPrimitive.Close

const DialogOverlay = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Overlay
    ref={ref}
    className={cn(
      "fixed inset-0 z-50 bg-black/80 mobile-dialog-overlay data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    )}
    onTouchStart={(e) => {
      // Check if any popover is open
      const hasOpenPopover = document.querySelector('[data-state="open"]:not([data-radix-dialog-content]):not([data-radix-dialog-overlay])') ||
                            document.querySelector('[aria-expanded="true"]:not([data-radix-dialog-content]):not([data-radix-dialog-overlay])')
      
      // Only prevent if touching the overlay itself (not dialog content)
      const target = e.target as Element;
      const isOverlayTouch = target.classList.contains('mobile-dialog-overlay') || 
                            target.classList.contains('bg-black/80');
      
      if (hasOpenPopover && isOverlayTouch) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }
      
      // Prevent overlay from closing dialog on mobile when touching inside dialog content
      if (target.closest('[data-radix-dialog-content]') || 
          target.closest('[data-radix-popover-content]') || 
          target.closest('[data-radix-select-content]') ||
          target.closest('[data-radix-command]') ||
          target.closest('[data-radix-popover-trigger]') ||
          target.closest('[data-radix-select-trigger]')) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }
    }}
    onTouchEnd={(e) => {
      // Check if any popover is open
      const hasOpenPopover = document.querySelector('[data-state="open"]:not([data-radix-dialog-content]):not([data-radix-dialog-overlay])') ||
                            document.querySelector('[aria-expanded="true"]:not([data-radix-dialog-content]):not([data-radix-dialog-overlay])')
      
      // Only prevent if touching the overlay itself (not dialog content)
      const target = e.target as Element;
      const isOverlayTouch = target.classList.contains('mobile-dialog-overlay') || 
                            target.classList.contains('bg-black/80');
      
      if (hasOpenPopover && isOverlayTouch) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }
      
      // Prevent overlay from closing dialog on mobile when touching inside dialog content
      if (target.closest('[data-radix-dialog-content]') || 
          target.closest('[data-radix-popover-content]') || 
          target.closest('[data-radix-select-content]') ||
          target.closest('[data-radix-command]') ||
          target.closest('[data-radix-popover-trigger]') ||
          target.closest('[data-radix-select-trigger]')) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }
    }}
    onPointerDown={(e) => {
      // Prevent overlay from closing dialog when clicking inside dialog content
      const target = e.target as Element;
      if (target.closest('[data-radix-dialog-content]') || 
          target.closest('[data-radix-popover-content]') || 
          target.closest('[data-radix-select-content]') ||
          target.closest('[data-radix-command]') ||
          target.closest('[data-radix-popover-trigger]') ||
          target.closest('[data-radix-select-trigger]')) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }
    }}
    onMouseDown={(e) => {
      // Prevent overlay from closing dialog when clicking inside dialog content
      const target = e.target as Element;
      if (target.closest('[data-radix-dialog-content]') || 
          target.closest('[data-radix-popover-content]') || 
          target.closest('[data-radix-select-content]') ||
          target.closest('[data-radix-command]') ||
          target.closest('[data-radix-popover-trigger]') ||
          target.closest('[data-radix-select-trigger]')) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }
    }}
    {...props}
  />
))
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName

const DialogContent = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content> & { hideClose?: boolean }
>(({ className, children, hideClose = false, ...props }, ref) => {
  const [isDark, setIsDark] = React.useState(false)
  
  React.useEffect(() => {
    const checkTheme = () => {
      setIsDark(document.documentElement.classList.contains('dark'))
    }
    checkTheme()
    
    const observer = new MutationObserver(checkTheme)
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    })
    
    return () => observer.disconnect()
  }, [])
  
  return (
    <DialogPortal>
      <DialogOverlay />
      <DialogPrimitive.Content
        ref={ref}
        data-radix-dialog-content
        className={cn(
          "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-0 border border-black/10 dark:border-white/5 p-6 duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-2xl relative overflow-hidden max-h-[90vh] max-w-[90vw] overflow-y-auto",
          className
        )}
        style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          maxHeight: '90vh',
          boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
          backgroundColor: isDark ? "rgb(20, 20, 20)" : "rgb(255, 255, 255)",
          ...props.style,
        }}
        {...props}
      >
      {children}
      </DialogPrimitive.Content>
    </DialogPortal>
  )
})
DialogContent.displayName = DialogPrimitive.Content.displayName

const DialogTitle = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Title
    ref={ref}
    className={cn(
      "text-lg font-semibold leading-none tracking-tight text-left",
      className
    )}
    {...props}
  />
))
DialogTitle.displayName = DialogPrimitive.Title.displayName

const DialogDescription = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground text-left", className)}
    {...props}
  />
))
DialogDescription.displayName = DialogPrimitive.Description.displayName

const DialogHeader = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & { hideClose?: boolean }
>(({ className, hideClose = false, children, ...props }, ref) => {
  // Check if this is a custom layout (like show-view-dialog)
  // Custom layouts typically have flex-row or other custom classes
  const hasCustomLayout = className && (
    className.includes('flex-row') || 
    className.includes('flex-row-reverse') ||
    className.includes('justify-between') ||
    className.includes('px-6') ||
    className.includes('py-4')
  )

  // If custom layout, add default styling but allow override
  // Still add close button unless hideClose is true
  if (hasCustomLayout) {
    // Recursively check if children already include a close button
    const hasCloseButton = (() => {
      const checkForClose = (node: React.ReactNode): boolean => {
        if (!React.isValidElement(node)) return false
        
        const nodeType = node.type as any
        // Check if it's DialogClose
        if (nodeType === DialogClose || 
            (typeof nodeType === 'object' && nodeType?.displayName === DialogPrimitive.Close.displayName)) {
          return true
        }
        
        // Check if it has asChild with DialogClose
        if (node.props?.asChild && React.isValidElement(node.props.children)) {
          const childType = node.props.children.type as any
          if (childType === DialogClose || 
              (typeof childType === 'object' && childType?.displayName === DialogPrimitive.Close.displayName)) {
            return true
          }
        }
        
        // Recursively check children
        if (node.props?.children) {
          const childrenArray = React.Children.toArray(node.props.children)
          return childrenArray.some(child => checkForClose(child))
        }
        
        return false
      }
      
      return React.Children.toArray(children).some(child => checkForClose(child))
    })()

    return (
      <div
        ref={ref}
        className={cn(
          "bg-muted/30 border-b relative",
          className
        )}
        {...props}
      >
        {children}
        {!hideClose && !hasCloseButton && (
          <DialogPrimitive.Close 
            className={cn(
              buttonVariants({ variant: "outline", size: "sm" }),
              "navigation-button h-9 w-9 rounded-full flex items-center justify-center p-0 flex-shrink-0 absolute top-4 right-4 z-10"
            )}
            style={{
              boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
            }}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </DialogPrimitive.Close>
        )}
      </div>
    )
  }

  // Standard layout: separate title and description
  const childrenArray = React.Children.toArray(children)
  let titleElement: React.ReactNode = null
  let descriptionElement: React.ReactNode = null
  const otherChildren: React.ReactNode[] = []

  childrenArray.forEach((child) => {
    if (React.isValidElement(child)) {
      const childType = child.type as any
      // Check if it's DialogTitle
      if (childType === DialogTitle || (childType?.displayName === "DialogTitle") || 
          (typeof childType === 'object' && childType?.render && childType?.displayName === DialogPrimitive.Title.displayName)) {
        titleElement = child
      } 
      // Check if it's DialogDescription
      else if (childType === DialogDescription || (childType?.displayName === "DialogDescription") ||
               (typeof childType === 'object' && childType?.render && childType?.displayName === DialogPrimitive.Description.displayName)) {
        descriptionElement = child
      } 
      else {
        otherChildren.push(child)
      }
    } else {
      otherChildren.push(child)
    }
  })

  // Standard layout: title and close button on same line, description below, all left-aligned
  return (
    <div
      ref={ref}
      className={cn(
        "flex flex-col space-y-1.5 text-left bg-muted/30 border-b",
        className
      )}
      {...props}
    >
      {/* Title and Close Button Row */}
      <div className="flex items-center justify-between gap-4 w-full">
        <div className="flex-1 min-w-0">
          {titleElement}
        </div>
        {!hideClose && (
          <DialogPrimitive.Close 
            className={cn(
              buttonVariants({ variant: "outline", size: "sm" }),
              "navigation-button h-9 w-9 rounded-full flex items-center justify-center p-0 flex-shrink-0"
            )}
            style={{
              boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
            }}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </DialogPrimitive.Close>
        )}
      </div>
      {/* Description below title */}
      {descriptionElement && (
        <div className="w-full text-left">
          {descriptionElement}
        </div>
      )}
      {/* Other children */}
      {otherChildren.length > 0 && (
        <div className="w-full">
          {otherChildren}
        </div>
      )}
    </div>
  )
})
DialogHeader.displayName = "DialogHeader"

const DialogFooter = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2 bg-muted/30 border-t",
      className
    )}
    {...props}
  />
)
DialogFooter.displayName = "DialogFooter"

export {
  Dialog,
  DialogPortal,
  DialogOverlay,
  DialogClose,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
}
