"use client"

import { ReactNode } from "react"

interface AnimatedContentWrapperProps {
  cardsView: ReactNode
  listView: ReactNode
  viewMode: "cards" | "list"
  className?: string
}

export default function AnimatedContentWrapper({ 
  cardsView,
  listView,
  viewMode, 
  className = "" 
}: AnimatedContentWrapperProps) {
  return (
    <div className={`relative overflow-hidden ${className}`}>
      <div 
        className="flex items-start transition-transform duration-300 ease-in-out"
        style={{
          transform: viewMode === "cards" 
            ? "translateX(0%)" 
            : "translateX(-100%)",
          alignContent: "flex-start"
        }}
      >
        {/* Cards view - takes up full width, always rendered to prevent remounting */}
        <div className="w-full flex-shrink-0" style={{ 
          maxHeight: viewMode === "list" ? "0px" : "none",
          overflow: viewMode === "list" ? "hidden" : "visible",
          opacity: viewMode === "list" ? 0 : 1
        }}>
          {cardsView}
        </div>
        
        {/* List view - takes up full width, always rendered to prevent remounting */}
        <div className="w-full flex-shrink-0" style={{ 
          maxHeight: viewMode === "cards" ? "0px" : "none",
          overflow: viewMode === "cards" ? "hidden" : "visible",
          opacity: viewMode === "cards" ? 0 : 1
        }}>
          {listView}
        </div>
      </div>
    </div>
  )
}
