"use client"

import React, { useRef, useEffect, useState } from "react"
import { useSettings, DeveloperLog } from "@/lib/settings-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { 
  Terminal, 
  Trash2, 
  Download, 
  Copy, 
  ChevronDown, 
  ChevronUp,
  Info,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Command,
  Loader2,
  Play,
  Pause,
  RefreshCw
} from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "@/hooks/use-toast"

interface DeveloperConsoleProps {
  className?: string
  maxHeight?: string
  showHeader?: boolean
}

const LOG_TYPE_COLORS = {
  info: {
    bg: "bg-blue-500/10 dark:bg-blue-400/10",
    border: "border-blue-500/30 dark:border-blue-400/30",
    text: "text-blue-600 dark:text-blue-400",
    icon: Info,
  },
  success: {
    bg: "bg-emerald-500/10 dark:bg-emerald-400/10",
    border: "border-emerald-500/30 dark:border-emerald-400/30",
    text: "text-emerald-600 dark:text-emerald-400",
    icon: CheckCircle2,
  },
  warning: {
    bg: "bg-amber-500/10 dark:bg-amber-400/10",
    border: "border-amber-500/30 dark:border-amber-400/30",
    text: "text-amber-600 dark:text-amber-400",
    icon: AlertTriangle,
  },
  error: {
    bg: "bg-red-500/10 dark:bg-red-400/10",
    border: "border-red-500/30 dark:border-red-400/30",
    text: "text-red-600 dark:text-red-400",
    icon: XCircle,
  },
  command: {
    bg: "bg-purple-500/10 dark:bg-purple-400/10",
    border: "border-purple-500/30 dark:border-purple-400/30",
    text: "text-purple-600 dark:text-purple-400",
    icon: Command,
  },
}

function formatTimestamp(date: Date): string {
  const d = new Date(date)
  const hours = d.getHours().toString().padStart(2, '0')
  const minutes = d.getMinutes().toString().padStart(2, '0')
  const seconds = d.getSeconds().toString().padStart(2, '0')
  const ms = d.getMilliseconds().toString().padStart(3, '0')
  return `${hours}:${minutes}:${seconds}.${ms}`
}

export default function DeveloperConsole({ 
  className, 
  maxHeight = "400px",
  showHeader = true 
}: DeveloperConsoleProps) {
  const { settings, clearDeveloperLogs, formatDate, formatTime } = useSettings()
  const scrollRef = useRef<HTMLDivElement>(null)
  const [autoScroll, setAutoScroll] = useState(true)
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [filter, setFilter] = useState<DeveloperLog["type"] | "all">("all")
  
  const logs = settings.developerConsoleLogs || []
  
  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (autoScroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [logs.length, autoScroll])
  
  const filteredLogs = filter === "all" 
    ? logs 
    : logs.filter(log => log.type === filter)
  
  const handleCopyLogs = async () => {
    const logText = filteredLogs.map(log => {
      const timestamp = formatTimestamp(new Date(log.timestamp))
      return `[${timestamp}] [${log.type.toUpperCase()}] ${log.message}${log.details ? '\n  ' + log.details : ''}`
    }).join('\n')
    
    try {
      await navigator.clipboard.writeText(logText)
      toast({
        title: "Logs copied",
        description: "Console logs have been copied to clipboard.",
      })
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Could not copy logs to clipboard.",
        variant: "destructive",
      })
    }
  }
  
  const handleDownloadLogs = () => {
    const logText = filteredLogs.map(log => {
      const timestamp = new Date(log.timestamp).toISOString()
      return `[${timestamp}] [${log.type.toUpperCase()}] ${log.message}${log.details ? '\n  Details: ' + log.details : ''}`
    }).join('\n')
    
    const blob = new Blob([logText], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `developer-console-${new Date().toISOString().split('T')[0]}.log`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    
    toast({
      title: "Logs downloaded",
      description: "Console logs have been saved to file.",
    })
  }
  
  const handleClearLogs = () => {
    clearDeveloperLogs()
    toast({
      title: "Logs cleared",
      description: "All console logs have been cleared.",
    })
  }
  
  if (!settings.developerOptionsEnabled) {
    return null
  }
  
  return (
    <Card className={cn("overflow-hidden", className)}>
      {showHeader && (
        <CardHeader className="p-4 pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="h-5 w-5 text-muted-foreground" />
              <CardTitle className="text-base">Developer Console</CardTitle>
              <Badge variant="outline" className="text-xs">
                {logs.length} logs
              </Badge>
            </div>
            <div className="flex items-center gap-1">
              {/* Filter buttons */}
              <div className="hidden sm:flex items-center gap-1 mr-2">
                {(["all", "info", "success", "warning", "error", "command"] as const).map((type) => (
                  <Button
                    key={type}
                    variant={filter === type ? "default" : "ghost"}
                    size="sm"
                    className={cn(
                      "h-6 px-2 text-xs",
                      filter === type && "evergreen-button"
                    )}
                    onClick={() => setFilter(type)}
                  >
                    {type === "all" ? "All" : type.charAt(0).toUpperCase() + type.slice(1)}
                  </Button>
                ))}
              </div>
              
              {/* Action buttons */}
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={() => setAutoScroll(!autoScroll)}
                title={autoScroll ? "Pause auto-scroll" : "Resume auto-scroll"}
              >
                {autoScroll ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={handleCopyLogs}
                title="Copy logs"
              >
                <Copy className="h-3.5 w-3.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={handleDownloadLogs}
                title="Download logs"
              >
                <Download className="h-3.5 w-3.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
                onClick={handleClearLogs}
                title="Clear logs"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={() => setIsCollapsed(!isCollapsed)}
                title={isCollapsed ? "Expand" : "Collapse"}
              >
                {isCollapsed ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronUp className="h-3.5 w-3.5" />}
              </Button>
            </div>
          </div>
          
          {/* Mobile filter dropdown */}
          <div className="sm:hidden mt-2">
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value as DeveloperLog["type"] | "all")}
              className="w-full px-3 py-1.5 text-sm rounded-md border bg-background"
            >
              <option value="all">All Logs</option>
              <option value="info">Info</option>
              <option value="success">Success</option>
              <option value="warning">Warning</option>
              <option value="error">Error</option>
              <option value="command">Command</option>
            </select>
          </div>
        </CardHeader>
      )}
      
      {!isCollapsed && (
        <CardContent className="p-0">
          <div 
            ref={scrollRef}
            className="font-mono text-xs bg-zinc-950 dark:bg-black overflow-auto"
            style={{ maxHeight }}
          >
            {filteredLogs.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-zinc-500">
                <Terminal className="h-8 w-8 mb-2 opacity-50" />
                <p>No logs yet</p>
                <p className="text-xs mt-1">Developer actions will appear here</p>
              </div>
            ) : (
              <div className="divide-y divide-zinc-800">
                {filteredLogs.map((log) => {
                  const typeConfig = LOG_TYPE_COLORS[log.type]
                  const Icon = typeConfig.icon
                  
                  return (
                    <div
                      key={log.id}
                      className={cn(
                        "px-3 py-2 hover:bg-zinc-900/50 transition-colors",
                        typeConfig.bg
                      )}
                    >
                      <div className="flex items-start gap-2">
                        <Icon className={cn("h-3.5 w-3.5 mt-0.5 flex-shrink-0", typeConfig.text)} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-zinc-500">
                              [{formatTimestamp(new Date(log.timestamp))}]
                            </span>
                            <Badge 
                              variant="outline" 
                              className={cn(
                                "text-[10px] px-1.5 py-0 h-4 font-normal",
                                typeConfig.border,
                                typeConfig.text
                              )}
                            >
                              {log.type.toUpperCase()}
                            </Badge>
                          </div>
                          <p className="text-zinc-100 mt-0.5 break-words">
                            {log.message}
                          </p>
                          {log.details && (
                            <pre className="text-zinc-400 mt-1 text-[10px] bg-zinc-900/50 p-2 rounded overflow-x-auto whitespace-pre-wrap break-words">
                              {log.details}
                            </pre>
                          )}
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </CardContent>
      )}
    </Card>
  )
}

// Hook for programmatic logging
export function useDeveloperLog() {
  const { addDeveloperLog, settings } = useSettings()
  
  return {
    log: (message: string, details?: string) => addDeveloperLog("info", message, details),
    success: (message: string, details?: string) => addDeveloperLog("success", message, details),
    warn: (message: string, details?: string) => addDeveloperLog("warning", message, details),
    error: (message: string, details?: string) => addDeveloperLog("error", message, details),
    command: (message: string, details?: string) => addDeveloperLog("command", message, details),
    isEnabled: settings.developerOptionsEnabled,
  }
}

