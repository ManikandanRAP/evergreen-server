"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Eye, EyeOff } from "lucide-react" // Import Eye and EyeOff icons
import Image from "next/image"
import { Checkbox } from "@/components/ui/checkbox"

export default function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false) // State to manage password visibility
  const [rememberMe, setRememberMe] = useState(true) // Default to true for better UX
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const [isDark, setIsDark] = useState(false)
  const { login } = useAuth()

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  useEffect(() => {
    const checkTheme = () => {
      setIsDark(document.documentElement.classList.contains('dark'))
    }
    checkTheme()
    
    const observer = new MutationObserver(checkTheme)
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    })
    
    return () => observer.disconnect()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    const result = await login(email, password, rememberMe)
    if (!result.success) {
      setError(result.error || "Invalid email or password")
    }
    setIsLoading(false)
  }

  // Function to toggle password visibility
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword)
  }

  // Mobile iOS-style layout
  if (isMobile) {
    return (
      <div className="h-dvh flex flex-col bg-background overflow-hidden">
        {/* Centered content container */}
        <div className="flex-1 flex flex-col justify-center items-center px-6 py-6 min-h-0">
          {/* Logo section */}
          <div className="flex flex-col items-center mb-6">
            <div className="mb-4">
              <Image 
                src={isDark ? "/myco-beta-logo-light.png" : "/myco-beta-logo.png"} 
                alt="Myco" 
                width={250} 
                height={63} 
                className="h-16 w-auto" 
                priority 
              />
            </div>
            <h1 className="text-2xl font-bold text-primary text-center mb-3">
              Shows and Ledger Management
            </h1>
            <p className="text-md text-muted-foreground text-center mb-4">
              Sign in to access Myco Dashboard
            </p>
          </div>

          {/* Form section */}
          <div className="w-full max-w-sm">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email-mobile" className="text-sm">Email</Label>
              <Input
                id="email-mobile"
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="transition-all duration-200 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password-mobile" className="text-sm">Password</Label>
              <Input
                id="password-mobile"
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="transition-all duration-200 focus:ring-2 focus:ring-emerald-500"
                endAdornment={
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={togglePasswordVisibility}
                    className="group h-full w-10 rounded-r-full rounded-l-none hover:bg-transparent px-0 hover:scale-100 active:scale-100"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 transition-transform duration-200 group-active:scale-90" />
                    ) : (
                      <Eye className="h-4 w-4 transition-transform duration-200 group-active:scale-90" />
                    )}
                  </Button>
                }
              />
            </div>
            <div className="flex items-center space-x-2 py-2">
              <Checkbox
                id="rememberMe-mobile"
                checked={rememberMe}
                onCheckedChange={(checked) => setRememberMe(checked === true)}
              />
              <Label
                htmlFor="rememberMe-mobile"
                className="text-sm font-normal cursor-pointer"
              >
                Remember me
              </Label>
            </div>
            {error && (
              <Alert variant="destructive" className="mb-2">
                <AlertDescription className="text-sm">{error}</AlertDescription>
              </Alert>
            )}
            <Button
              type="submit"
              className="w-full evergreen-button transition-all duration-200 transform hover:scale-105 mt-4"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Signing in...
                </>
              ) : (
                "Sign In"
              )}
            </Button>
          </form>
          </div>
        </div>
      </div>
    )
  }

  // Desktop layout (existing)
  return (
    <div className="min-h-screen flex items-center justify-center p-8">
      <Card className="w-full max-w-lg evergreen-card shadow-2xl">
        <CardHeader className="text-center space-y-4 px-10 py-10">
          <div className="flex justify-center">
            <Image src={isDark ? "/myco-beta-logo-light.png" : "/myco-beta-logo.png"} alt="Myco" width={250} height={63} className="h-16 w-auto" priority />
          </div>
          <CardTitle className="text-2xl font-bold text-primary">
            Shows and Ledger Management
          </CardTitle>
          <CardDescription>Sign in to access Myco Dashboard</CardDescription>
        </CardHeader>
        <CardContent className="px-8 pb-8">
          <div className="max-w-md mx-auto">
            <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="transition-all duration-200 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            {/* --- Start of Password Field with Show/Hide Button --- */}
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type={showPassword ? "text" : "password"} // Dynamically set type
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="transition-all duration-200 focus:ring-2 focus:ring-emerald-500"
                endAdornment={
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={togglePasswordVisibility}
                    className="group h-full w-10 rounded-r-full rounded-l-none hover:bg-transparent px-0 hover:scale-100 active:scale-100"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 transition-transform duration-200 group-active:scale-90" />
                    ) : (
                      <Eye className="h-4 w-4 transition-transform duration-200 group-active:scale-90" />
                    )}
                  </Button>
                }
              />
            </div>
            {/* --- End of Password Field --- */}
            <div className="flex items-center space-x-2">
              <Checkbox
                id="rememberMe"
                checked={rememberMe}
                onCheckedChange={(checked) => setRememberMe(checked === true)}
              />
              <Label
                htmlFor="rememberMe"
                className="text-sm font-normal cursor-pointer"
              >
                Remember me
              </Label>
            </div>
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <Button
              type="submit"
              className="w-full evergreen-button transition-all duration-200 transform hover:scale-105"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Signing in...
                </>
              ) : (
                "Sign In"
              )}
            </Button>
          </form>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}