"use client"

import { useState, useMemo, useEffect, useCallback } from "react"
import { useAuth } from "@/lib/auth-context"
import { useSettings } from "@/lib/settings-context"
import { useShows } from "@/hooks/use-shows"
import { apiClient, Show } from "@/lib/api-client"
import { toast } from "sonner"
import { useSearchParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { getRankingInfo } from "@/lib/ranking-utils"
import { cn } from "@/lib/utils"
import AnimatedSwitcher from "@/components/animated-switcher"
import AnimatedContentWrapper from "@/components/animated-content-wrapper"
import {
  Plus,
  Filter,
  Edit,
  Eye,
  Radio,
  Trash2,
  Grid3X3,
  List,
  Download,
  Check,
  Upload,
  AlertCircle,
  CheckCircle,
  X,
  Loader2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  MoreVertical,
  MoreHorizontal,
  AlertTriangle,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Archive,
  Minimize2,
  LayoutGrid,
  Search,
} from "lucide-react"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import CreateShowDialog from "@/components/create-show-dialog"
import DeleteShowDialog from "@/components/delete-show-dialog"
import ImportCSVDialog from "@/components/import-csv-dialog"
import ShowViewDialog from "@/components/show-view-dialog"
import { ShowsToolbar, ShowsBottomToolbar } from "@/components/shows-toolbar"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Checkbox } from "@/components/ui/checkbox"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

/** Filter highlight class - adjust values here to change globally */
const FILTER_HIGHLIGHT_CLASS = "outline outline-1 outline-emerald-500"

/** FILTER MODEL */
interface ShowFilters {
  search: string
  minimumGuarantee: string
  subnetwork: string
  format: string
  rate_card: string
  relationship: string
  show_type: string
  genre_name: string
  hasSponsorshipRevenue: string
  hasNonEvergreenRevenue: string
  requiresPartnerLedgerAccess: string
  isOriginal: string
  is_active: string
  age_demographic: string
  genderDemographic: string
  ownershipPercentage: string
  region: string
  is_undersized: string
  cadence: string
  averageLength: string
  adSlots: string
  revenue2023: string
  revenue2024: string
  revenue2025: string
  hasBrandedRevenue: string
  hasMarketingRevenue: string
  hasWebManagementRevenue: string
  show_archived: string
}

const initialFilters: ShowFilters = {
  search: "",
  minimumGuarantee: "",
  subnetwork: "",
  format: "",
  rate_card: "",
  relationship: "",
  show_type: "",
  genre_name: "",
  hasSponsorshipRevenue: "",
  hasNonEvergreenRevenue: "",
  requiresPartnerLedgerAccess: "",
  isOriginal: "",
  is_active: "",
  age_demographic: "",
  genderDemographic: "",
  ownershipPercentage: "",
  region: "",
  is_undersized: "",
  cadence: "all",
  averageLength: "",
  adSlots: "",
  revenue2023: "",
  revenue2024: "",
  revenue2025: "",
  hasBrandedRevenue: "",
  hasMarketingRevenue: "",
  hasWebManagementRevenue: "",
  show_archived: "all",
}

interface ImportResult {
  success: boolean
  message: string
  importedCount?: number
  errors?: string[]
  warnings?: string[]
}

/** Turn raw DB/API errors into user-friendly import messages */
function formatImportError(error: string): string {
  if (/1452|fk_qbo_show_name|FOREIGN KEY.*qbo_show_name.*allclass/i.test(error)) {
    const rowMatch = error.match(/Row\s*(\d+)\s*\(['"]([^'"]+)['"]\)/i);
    const prefix = rowMatch ? `Row ${rowMatch[1]} ('${rowMatch[2]}'): ` : "";
    return `${prefix}QBO Show Name is not in the QuickBooks class list. Leave QBO Show Name blank in the CSV or add the show in QuickBooks and sync.`;
  }
  return error;
}

/** Small labeled divider for filter sections with collapsible toggle */
function SectionDivider({ 
  label, 
  isOpen, 
  onToggle 
}: { 
  label: string
  isOpen?: boolean
  onToggle?: () => void
}) {
  const isCollapsible = typeof isOpen !== 'undefined' && typeof onToggle !== 'undefined'
  
  return (
    <div className="my-4 first:mt-4 grid grid-cols-[1fr_auto_1fr] items-center gap-3">
      <div className="h-px bg-border" />
      <span 
        className={cn(
          "text-sm font-medium text-muted-foreground whitespace-nowrap flex items-center gap-2 px-4 py-1.5 border border-border rounded-full transition-all duration-300",
          isCollapsible && "cursor-pointer hover:scale-105 active:scale-95"
        )}
        onClick={isCollapsible ? onToggle : undefined}
        role={isCollapsible ? "button" : undefined}
        tabIndex={isCollapsible ? 0 : undefined}
        onKeyDown={isCollapsible ? (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault()
            onToggle?.()
          }
        } : undefined}
      >
        {label}
        {isCollapsible && (
          <ChevronDown 
            className={cn(
              "h-5 w-5 transition-transform duration-200",
              isOpen && "rotate-180"
            )} 
          />
        )}
      </span>
      <div className="h-px bg-border" />
    </div>
  )
}

/** Helper for title case formatting */
const toTitleCase = (str: string) =>
  str.replace(/\b\w/g, (char) => char.toUpperCase())

/** Helpers for Standard/Programmatic Splits displayed in views */
const formatPercentage = (n: number | null | undefined) =>
  n === null || typeof n === "undefined" ? "N/A" : `${n}%`

const getStandardSplit = (show: Show) =>
  show.standard_ads_percent ?? null

const getProgrammaticSplit = (show: Show) =>
  show.programmatic_ads_span_percent ?? null

export default function ShowsManagement() {
  const { user } = useAuth()
  const { shows, loading, error, createShow, updateShow, deleteShow, fetchShows } = useShows()
  const searchParams = useSearchParams()
  const router = useRouter()

  const [filters, setFilters] = useState<ShowFilters>(initialFilters)
  const [isClearExiting, setIsClearExiting] = useState(false)
  const [isFiltersOpen, setIsFiltersOpen] = useState(false)
  const [isShowInfoOpen, setIsShowInfoOpen] = useState(true)
  const [isFinancialInfoOpen, setIsFinancialInfoOpen] = useState(true)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false)
  const [viewingShowIndex, setViewingShowIndex] = useState<number | null>(null)
  const [editingShow, setEditingShow] = useState<Show | null>(null)
  const [deletingShow, setDeletingShow] = useState<Show | null>(null)

  /** Default to LIST view (as per earlier change) */
  const [viewMode, setViewMode] = useState<"cards" | "list">("list")

  const [selectedShows, setSelectedShows] = useState<Set<string>>(new Set())
  const [importResult, setImportResult] = useState<ImportResult | null>(null)
  const [isBulkDeleting, setIsBulkDeleting] = useState(false)
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false)
  const [isBulkArchiving, setIsBulkArchiving] = useState(false)
  const [showBulkArchiveConfirm, setShowBulkArchiveConfirm] = useState(false)
  const [isBulkUnarchiving, setIsBulkUnarchiving] = useState(false)
  const [showBulkUnarchiveConfirm, setShowBulkUnarchiveConfirm] = useState(false)
  const [showArchiveConfirm, setShowArchiveConfirm] = useState(false)
  const [showingArchiveShow, setShowingArchiveShow] = useState<Show | null>(null)

  // Sorting state
  type SortField = 'name' | 'show_type' | 'isRateCard' | 'standardSplit' | 'programmaticSplit' | 'ranking_category'
  type SortDirection = 'asc' | 'desc' | null
  const [sortField, setSortField] = useState<SortField | null>(null)
  const [sortDirection, setSortDirection] = useState<SortDirection>(null)

  const handleClearFilters = () => {
    setFilters(initialFilters)
  }

  // Sorting logic
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      // Toggle direction: asc -> desc -> null
      if (sortDirection === 'asc') {
        setSortDirection('desc')
      } else if (sortDirection === 'desc') {
        setSortDirection(null)
        setSortField(null)
      } else {
        setSortDirection('asc')
      }
    } else {
      // New field, start with ascending
      setSortField(field)
      setSortDirection('asc')
    }
  }

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="h-4 w-4 opacity-50" />
    }
    if (sortDirection === 'asc') {
      return <ArrowUp className="h-4 w-4" />
    }
    if (sortDirection === 'desc') {
      return <ArrowDown className="h-4 w-4" />
    }
    return <ArrowUpDown className="h-4 w-4 opacity-50" />
  }

  const handleViewShow = (show: Show) => {
    const index = filteredShows.findIndex((s) => s.id === show.id)
    if (index !== -1) setViewingShowIndex(index)
  }

  const handleEditShow = (show: Show) => {
    setEditingShow(show)
    setIsCreateDialogOpen(true)
  }

  const handleEditExistingShow = (show: Show) => {
    setEditingShow(show)
    setIsCreateDialogOpen(true)
  }

  const handleDeleteShow = (show: Show) => setDeletingShow(show)

  const handleArchiveShow = (show: Show) => {
    setShowingArchiveShow(show)
    setShowArchiveConfirm(true)
  }

  const handleConfirmArchiveShow = async () => {
    if (!showingArchiveShow) return

    try {
      await apiClient.archiveShow(showingArchiveShow.id)
      // Include archived shows in fetch if filter is set to "all" or "archived"
      const includeArchived = filters.show_archived === "all" || filters.show_archived === "archived"
      await fetchShows(undefined, includeArchived)
      setShowArchiveConfirm(false)
      setShowingArchiveShow(null)
    } catch (error) {
      // Error handling is done in the API client
    }
  }

  const handleArchiveFromDialog = (show: Show) => {
    setShowingArchiveShow(show)
    setShowArchiveConfirm(true)
    // Close the show view dialog first
    setViewingShowIndex(null)
  }

  const handleUnarchiveShow = (show: Show) => {
    setShowingArchiveShow(show)
    setShowArchiveConfirm(true)
  }

  const handleConfirmUnarchiveShow = async () => {
    if (!showingArchiveShow) return

    try {
      await apiClient.unarchiveShow(showingArchiveShow.id)
      // Include archived shows in fetch if filter is set to "all" or "archived"
      const includeArchived = filters.show_archived === "all" || filters.show_archived === "archived"
      await fetchShows(undefined, includeArchived)
      setShowArchiveConfirm(false)
      setShowingArchiveShow(null)
    } catch (error) {
      // Error handling is done in the API client
    }
  }

  const handleUnarchiveFromDialog = (show: Show) => {
    setShowingArchiveShow(show)
    setShowArchiveConfirm(true)
    // Close the show view dialog first
    setViewingShowIndex(null)
  }

  const handleShowUpdated = async () => {
    setEditingShow(null)
    await fetchShows()
  }

  const handleShowDeleted = async () => {
    setDeletingShow(null)
    setViewingShowIndex(null)
    const includeArchived = filters.show_archived === "all" || filters.show_archived === "archived"
    await fetchShows(undefined, includeArchived)
  }

  const handleCreateNew = () => {
    setEditingShow(null)
    setIsCreateDialogOpen(true)
  }

  const handleSelectAll = () => {
    if (selectedShows.size === filteredShows.length) {
      setSelectedShows(new Set())
    } else {
      setSelectedShows(new Set(filteredShows.map((show) => show.id)))
    }
  }

  const handleSelectShow = (showId: string) => {
    const next = new Set(selectedShows)
    next.has(showId) ? next.delete(showId) : next.add(showId)
    setSelectedShows(next)
  }

  const handleBulkDelete = () => {
    setShowBulkDeleteConfirm(true)
  }

  const handleBulkArchive = () => {
    setShowBulkArchiveConfirm(true)
  }

  const handleBulkUnarchive = () => {
    setShowBulkUnarchiveConfirm(true)
  }

  const handleConfirmBulkArchive = async () => {
    if (selectedShows.size === 0) return

    setIsBulkArchiving(true)
    try {
      const selectedShowIds = Array.from(selectedShows)
      
      // Use the new bulk archive API
      const result = await apiClient.bulkArchiveShows(selectedShowIds)
      
      // Clear selection after archiving
      setSelectedShows(new Set())
      
      // Show appropriate success/error message
      if (result.failed === 0) {
        toast.success(`Successfully archived all ${result.successful} selected shows!`)
      } else if (result.successful > 0) {
        toast.warning(`Archived ${result.successful} shows, ${result.failed} failed`)
      } else {
        toast.error(`Failed to archive any shows. ${result.message || 'Unknown error'}`)
      }

      // Refresh the shows list - include archived if filter is set to "all" or "archived"
      const includeArchived = filters.show_archived === "all" || filters.show_archived === "archived"
      await fetchShows(undefined, includeArchived)
    } catch (error: any) {
      console.error("Bulk archive error:", error)
      toast.error(error.message || "Failed to archive shows")
    } finally {
      setIsBulkArchiving(false)
      setShowBulkArchiveConfirm(false)
    }
  }

  const handleConfirmBulkUnarchive = async () => {
    if (selectedShows.size === 0) return

    setIsBulkUnarchiving(true)
    try {
      const selectedShowIds = Array.from(selectedShows)
      
      // Use the new bulk unarchive API
      const result = await apiClient.bulkUnarchiveShows(selectedShowIds)
      
      // Clear selection after unarchiving
      setSelectedShows(new Set())
      
      // Show appropriate success/error message
      if (result.failed === 0) {
        toast.success(`Successfully unarchived all ${result.successful} selected shows!`)
      } else if (result.successful > 0) {
        toast.warning(`Unarchived ${result.successful} shows, ${result.failed} failed`)
      } else {
        toast.error(`Failed to unarchive any shows. ${result.message || 'Unknown error'}`)
      }

      // Refresh the shows list - include archived if filter is set to "all" or "archived"
      const includeArchived = filters.show_archived === "all" || filters.show_archived === "archived"
      await fetchShows(undefined, includeArchived)
    } catch (error: any) {
      console.error("Bulk unarchive error:", error)
      toast.error(error.message || "Failed to unarchive shows")
    } finally {
      setIsBulkUnarchiving(false)
      setShowBulkUnarchiveConfirm(false)
    }
  }

  const handleConfirmBulkDelete = async () => {
    if (selectedShows.size === 0) return

    setIsBulkDeleting(true)
    try {
      const selectedShowIds = Array.from(selectedShows)
      
      // Use the new bulk delete API
      const result = await apiClient.bulkDeletePodcasts(selectedShowIds)
      
      // Clear selection after deletion
      setSelectedShows(new Set())
      
      // Show appropriate success/error message
      if (result.failed === 0) {
        toast.success(`Successfully deleted all ${result.successful} selected shows!`)
      } else if (result.successful > 0) {
        toast.warning(`Deleted ${result.successful} shows, ${result.failed} failed`)
      } else {
        toast.error(`Failed to delete any shows. ${result.message || 'Unknown error'}`)
      }

      // Reload the shows list (respect current archive filter)
      setViewingShowIndex(null)
      const includeArchived = filters.show_archived === "all" || filters.show_archived === "archived"
      await fetchShows(undefined, includeArchived)
    } catch (error: any) {
      console.error("Bulk delete failed:", error)
      toast.error(error.message || "Failed to delete selected shows")
    } finally {
      setIsBulkDeleting(false)
      setShowBulkDeleteConfirm(false)
    }
  }

  const handleExportCSV = () => {
    const showsToExport =
      selectedShows.size > 0
        ? filteredShows.filter((show) => selectedShows.has(show.id))
        : filteredShows

    if (showsToExport.length === 0) {
      alert("No shows available to export")
      return
    }

    // Use the same user-friendly headers as the import CSV template
    const csvHeaders = [
      // 1. Core Show Information (Most Important)
      "Show Name", "Show Type", "Format", "Ranking Category", "Is Original Content", "Is Rate Card Show",
      
      // 2. Business & Relationship Details
      "Relationship", "Start Date", "Minimum Guarantee", "Ownership by Evergreen (%)", "Cadence",
      
      // 3. Content & Audience
      "Genre", "Age Demographic", "Gender Demographic (M/F)", "Region Demographic", "Average Length (Minutes)", "Ad Slots",
      
      // 4. Financial Data
      "Span CPM", "Latest CPM", "Revenue 2023", "Revenue 2024", "Revenue 2025",
      
      // 5. Revenue Distribution Percentages (with standard_ads_percent and programmatic_ads_span_percent first)
      "Standard Ads (%)", "Programmatic Ads/Span (%)", "Side Bonus (%)", "YouTube Ads (%)",
      "Subscriptions (%)", "Sponsorship Ad FP - Lead (%)", "Sponsorship Ad - Partner Lead (%)", 
      "Sponsorship Ad - Partner Sold (%)", "Merchandise (%)", "Branded Revenue (%)",
      "Marketing Services Revenue (%)",
      
      // 6. Hands-off Percentages
      "Direct Customer - Hands Off (%)", "YouTube - Hands Off (%)", "Subscription - Hands Off (%)",
      
      // 7. Contact Information
      "Primary Contact (Show)", "Primary Contact (Host)", "Evergreen Production Staff Name",
      
      // 8. System & Operational
      "Subnetwork Name", "Is Active", "Is Undersized", "Primary Education Demographic", "Secondary Education Demographic",
      
      // 9. Revenue Flags
      "Has Sponsorship Revenue", "Has Non Evergreen Revenue", "Has Partner Ledger Access",
      "Has Branded Revenue", "Has Marketing Revenue", "Has Web Management Revenue",
      
      // 10. Integration Data
      "QBO Show Name", "QBO Show ID"
    ]

    const csvData = showsToExport.map((show) => [
      // 1. Core Show Information (Most Important)
      show.title,
      show.show_type,
      show.media_type ? show.media_type.charAt(0).toUpperCase() + show.media_type.slice(1) : "",
      show.ranking_category ? `Level ${show.ranking_category}` : "",
      show.is_original ? "Yes" : "No",
      show.rate_card ? "Yes" : "No",
      
      // 2. Business & Relationship Details
      show.relationship_level ? show.relationship_level.charAt(0).toUpperCase() + show.relationship_level.slice(1) : "",
      show.start_date || "",
      show.minimum_guarantee ? "Yes" : "No",
      show.evergreen_ownership_pct || "",
      show.cadence,
      
      // 3. Content & Audience
      show.genre_name,
      show.age_demographic || "",
      show.gender || "",
      show.region || "",
      show.avg_show_length_mins || "",
      show.ad_slots || "",
      
      // 4. Financial Data
      show.span_cpm_usd || "",
      show.latest_cpm_usd || "",
      show.revenue_2023 || "",
      show.revenue_2024 || "",
      show.revenue_2025 || "",
      
      // 5. Revenue Distribution Percentages (with standard_ads_percent and programmatic_ads_span_percent first)
      show.standard_ads_percent || "",
      show.programmatic_ads_span_percent || "",
      show.side_bonus_percent || "",
      show.youtube_ads_percent || "",
      show.subscriptions_percent || "",
      show.sponsorship_ad_fp_lead_percent || "",
      show.sponsorship_ad_partner_lead_percent || "",
      show.sponsorship_ad_partner_sold_percent || "",
      show.merchandise_percent || "",
      show.branded_revenue_percent || "",
      show.marketing_services_revenue_percent || "",
      
      // 6. Hands-off Percentages
      show.direct_customer_hands_off_percent || "",
      show.youtube_hands_off_percent || "",
      show.subscription_hands_off_percent || "",
      
      // 7. Contact Information
      show.show_primary_contact || "",
      show.show_host_contact || "",
      show.evergreen_production_staff_name || "",
      
      // 8. System & Operational
      show.subnetwork_id || "",
      show.is_active ? "Yes" : "No",
      show.is_undersized ? "Yes" : "No",
      show.primary_education || "",
      show.secondary_education || "",
      
      // 9. Revenue Flags
      show.has_sponsorship_revenue ? "Yes" : "No",
      show.has_non_evergreen_revenue ? "Yes" : "No",
      show.requires_partner_access ? "Yes" : "No",
      show.has_branded_revenue ? "Yes" : "No",
      show.has_marketing_revenue ? "Yes" : "No",
      show.has_web_mgmt_revenue ? "Yes" : "No",
      
      // 10. Integration Data
      show.qbo_show_name || "",
      show.qbo_show_id || "",
    ])

    const csvContent = [csvHeaders, ...csvData]
      .map((row) => row.map((field) => `"${field}"`).join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `evergreen-shows-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleImportComplete = (result: ImportResult) => {
    setImportResult(result)
    if (result.success) {
      fetchShows()
    }
  }

  /** Filtering and Sorting */
  const filteredShows = useMemo(() => {
    let filtered = shows.filter((show) => {
      if (filters.search) {
        const searchTerm = filters.search.toLowerCase()
        const searchableFields = [
          show.title,
          show.show_type,
          show.subnetwork_id,
          show.genre_name,
          show.show_host_contact,
          show.show_primary_contact,
          show.relationship_level,
          show.media_type,
          show.age_demographic,
          show.gender,
        ]
        const matchesSearch = searchableFields.some(
          (field) => field && field.toString().toLowerCase().includes(searchTerm),
        )
        if (!matchesSearch) return false
      }

      if (filters.subnetwork && filters.subnetwork !== "all" && show.subnetwork_id !== filters.subnetwork)
        return false
      if (filters.format && filters.format !== "all" && show.media_type !== filters.format) return false
      if (filters.relationship && filters.relationship !== "all" && show.relationship_level !== filters.relationship)
        return false
      if (filters.show_type && filters.show_type !== "all" && show.show_type?.toLowerCase() !== filters.show_type)
        return false
      if (filters.genre_name && filters.genre_name !== "all" && show.genre_name !== filters.genre_name)
        return false
      if (filters.age_demographic && filters.age_demographic !== "all" && show.age_demographic !== filters.age_demographic)
        return false
      if (filters.genderDemographic && filters.genderDemographic !== "all" && show.gender !== filters.genderDemographic)
        return false
      if (filters.region && filters.region !== "all" && show.region !== filters.region)
        return false
      if (filters.cadence && filters.cadence !== "all" && show.cadence !== filters.cadence)
        return false

      const booleanFilters: (keyof ShowFilters)[] = [
        "rate_card",
        "isOriginal",
        "is_active",
        "is_undersized",
        "minimumGuarantee",
        "hasSponsorshipRevenue",
        "hasNonEvergreenRevenue",
        "requiresPartnerLedgerAccess",
        "hasBrandedRevenue",
        "hasMarketingRevenue",
        "hasWebManagementRevenue",
      ]
      const showToFilterKeyMap: Record<string, keyof Show> = {
        rate_card: "rate_card",
        is_undersized: "is_undersized",
        minimumGuarantee: "minimum_guarantee",
        hasSponsorshipRevenue: "has_sponsorship_revenue",
        hasNonEvergreenRevenue: "has_non_evergreen_revenue",
        requiresPartnerLedgerAccess: "requires_partner_access",
        isOriginal: "is_original",
        is_active: "is_active",
        hasBrandedRevenue: "has_branded_revenue",
        hasMarketingRevenue: "has_marketing_revenue",
        hasWebManagementRevenue: "has_web_mgmt_revenue",
      }

      for (const key of booleanFilters) {
        if (filters[key] && filters[key] !== "all") {
          const filterValue = filters[key] === "yes"
          const showKey = (showToFilterKeyMap[key] || key) as keyof Show
          if ((show as any)[showKey] !== filterValue) return false
        }
      }

      const numericFilters: { filterKey: keyof ShowFilters; showKey: keyof Show }[] = [
        { filterKey: "adSlots", showKey: "ad_slots" },
        { filterKey: "averageLength", showKey: "avg_show_length_mins" },
        { filterKey: "revenue2023", showKey: "revenue_2023" },
        { filterKey: "revenue2024", showKey: "revenue_2024" },
        { filterKey: "revenue2025", showKey: "revenue_2025" },
      ]
      for (const { filterKey, showKey } of numericFilters) {
        if (filters[filterKey]) {
          const filterValue = Number.parseInt(filters[filterKey] as string, 10)
          const showValue = (show as any)[showKey] as number
          if (!isNaN(filterValue) && showValue < filterValue) return false
        }
      }

      if (filters.ownershipPercentage && filters.ownershipPercentage !== "all") {
        const ownership = Number.parseInt(filters.ownershipPercentage)
        if (show.evergreen_ownership_pct !== ownership) return false
      }

      // Archive status filtering
      if (filters.show_archived && filters.show_archived !== "all") {
        if (filters.show_archived === "active" && show.is_archived) return false
        if (filters.show_archived === "archived" && !show.is_archived) return false
      }

      return true
    })

    // Apply sorting if specified
    if (sortField && sortDirection) {
      filtered.sort((a, b) => {
        let aValue: any
        let bValue: any

        switch (sortField) {
          case 'name':
            aValue = a.title?.toLowerCase() || ''
            bValue = b.title?.toLowerCase() || ''
            break
          case 'show_type':
            aValue = a.show_type?.toLowerCase() || ''
            bValue = b.show_type?.toLowerCase() || ''
            break
          case 'isRateCard':
            aValue = a.rate_card ? 1 : 0
            bValue = b.rate_card ? 1 : 0
            break
          case 'standardSplit':
            aValue = getStandardSplit(a) || 0
            bValue = getStandardSplit(b) || 0
            break
          case 'programmaticSplit':
            aValue = getProgrammaticSplit(a) || 0
            bValue = getProgrammaticSplit(b) || 0
            break
          case 'ranking_category':
            aValue = a.ranking_category ? parseInt(a.ranking_category) : 0
            bValue = b.ranking_category ? parseInt(b.ranking_category) : 0
            break
          default:
            return 0
        }

        if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1
        if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1
        return 0
      })
    }

    return filtered
  }, [shows, filters, sortField, sortDirection])

  // Calculate show counts for pills
  const showCounts = useMemo(() => {
    const totalShows = shows.length
    const activeShows = shows.filter(show => !show.is_archived).length
    const archivedShows = shows.filter(show => show.is_archived).length
    
    return {
      total: totalShows,
      active: activeShows,
      archived: archivedShows
    }
  }, [shows])

  /** Active filter chips with individual clear buttons */
  type ActiveBadge = { label: string; value: string; key: keyof ShowFilters }
  
  /** Map raw filter values to display labels */
  const getDisplayValue = (key: keyof ShowFilters, value: string): string => {
    const displayMappings: Partial<Record<keyof ShowFilters, Record<string, string>>> = {
      is_active: { yes: "Active", no: "Inactive" },
      isOriginal: { yes: "Original", no: "Not Original" },
      rate_card: { yes: "Yes", no: "No" },
      is_undersized: { yes: "Yes", no: "No" },
      minimumGuarantee: { yes: "Yes", no: "No" },
      hasSponsorshipRevenue: { yes: "Yes", no: "No" },
      hasNonEvergreenRevenue: { yes: "Yes", no: "No" },
      requiresPartnerLedgerAccess: { yes: "Yes", no: "No" },
      hasBrandedRevenue: { yes: "Yes", no: "No" },
      hasMarketingRevenue: { yes: "Yes", no: "No" },
      hasWebManagementRevenue: { yes: "Yes", no: "No" },
    }
    return displayMappings[key]?.[value] ?? value
  }
  
  const activeFilterBadges: ActiveBadge[] = useMemo(() => {
    const entries: ActiveBadge[] = []
    const pushKey = (label: string, key: keyof ShowFilters) => {
      const v = String(filters[key] ?? "")
      if (v && v !== "all") entries.push({ label, value: getDisplayValue(key, v), key })
    }

    // Search
    pushKey("Search", "search")

    // Show Information
    pushKey("Age Demographic", "age_demographic")
    pushKey("Format", "format")
    pushKey("Gender", "genderDemographic")
    pushKey("Genre", "genre_name")
    pushKey("Original", "isOriginal")
    pushKey("Region", "region")
    pushKey("Relationship", "relationship")
    pushKey("Show Status", "is_active")
    pushKey("Show Type", "show_type")
    pushKey("Subnetwork", "subnetwork")
    pushKey("Rate Card", "rate_card")
    pushKey("Undersized", "is_undersized")
    pushKey("Partner Ledger Access", "requiresPartnerLedgerAccess")

    // Financial Information
    pushKey("Ad Slots ≥", "adSlots")
    pushKey("Avg Length ≥", "averageLength")
    pushKey("Min Guarantee ≥", "minimumGuarantee")
    pushKey("Revenue 2023 ≥", "revenue2023")
    pushKey("Revenue 2024 ≥", "revenue2024")
    pushKey("Revenue 2025 ≥", "revenue2025")
    pushKey("Cadence", "cadence")
    pushKey("Ownership %", "ownershipPercentage")
    pushKey("Branded Revenue", "hasBrandedRevenue")
    pushKey("Marketing Revenue", "hasMarketingRevenue")
    pushKey("Sponsorship Revenue", "hasSponsorshipRevenue")
    pushKey("Web Management Revenue", "hasWebManagementRevenue")
    pushKey("Show Status", "show_archived")

    return entries
  }, [filters])

  const clearSingleFilter = (key: keyof ShowFilters) => {
    setFilters((prev) => ({ ...prev, [key]: "" }))
  }

  /** Pagination */
  const { getPageSize, getTableDensityClass, settings, updateSettings } = useSettings()
  const PAGE_SIZE = useMemo(() => getPageSize("showsManagement") || 12, [getPageSize])
  const [page, setPage] = useState(1)
  const [gotoInput, setGotoInput] = useState<string>("")

  const currentDensity = settings.tableDensity.shows || "default"
  
  const handleDensityChange = (value: "compact" | "default") => {
    updateSettings({
      tableDensity: {
        ...settings.tableDensity,
        shows: value,
      },
    })
  }
  
  const PAGE_SIZE_OPTIONS = [5, 10, 12, 15, 20, 25, 50, 100]
  
  const handlePageSizeChange = (value: string) => {
    const newPageSize = parseInt(value)
    const updates: any = {
      pagination: {
        ...settings.pagination,
        showsManagement: newPageSize,
      },
    }
    
    if (settings.globalPageSize !== null) {
      updates.globalPageSize = null
    }
    
    updateSettings(updates)
    setPage(1)
  }
  
  useEffect(() => setPage(1), [PAGE_SIZE])

  const totalPages = useMemo(
    () => Math.max(1, Math.ceil(filteredShows.length / PAGE_SIZE)),
    [filteredShows.length, PAGE_SIZE]
  )

  useEffect(() => {
    if (page > totalPages) setPage(1)
  }, [totalPages, page])

  const paginatedShows = useMemo(() => {
    const start = (page - 1) * PAGE_SIZE
    return filteredShows.slice(start, start + PAGE_SIZE)
  }, [filteredShows, page, PAGE_SIZE])

  // Optimized pagination handlers with useCallback
  const gotoPrev = useCallback(() => setPage((p) => Math.max(1, p - 1)), [])
  const gotoNext = useCallback(() => setPage((p) => Math.min(totalPages, p + 1)), [totalPages])
  const gotoPage = useCallback((newPage: number) => setPage(Math.max(1, Math.min(totalPages, newPage))), [totalPages])

  const pageRangeStart = filteredShows.length === 0 ? 0 : (page - 1) * PAGE_SIZE + 1
  const pageRangeEnd = Math.min(page * PAGE_SIZE, filteredShows.length)

  const handleGoto = useCallback(() => {
    const n = parseInt(gotoInput, 10)
    if (!isNaN(n)) setPage(Math.min(Math.max(1, n), totalPages))
    setGotoInput("")
  }, [gotoInput, totalPages])

  useEffect(() => {
    setPage(1)
  }, [JSON.stringify(filters)])

  // Handle archive filter changes - fetch archived shows when needed
  useEffect(() => {
    if (user && (filters.show_archived === "all" || filters.show_archived === "archived")) {
      // Check if we already have archived shows
      const hasArchivedShows = shows.some(show => show.is_archived)
      if (!hasArchivedShows) {
        fetchShows(undefined, true)
      }
    }
  }, [filters.show_archived, user])

  // Check for openImport query parameter and open import dialog
  useEffect(() => {
    if (searchParams.get('openImport') === 'true') {
      setIsImportDialogOpen(true)
      // Clean up the URL by removing the query parameter
      const url = new URL(window.location.href)
      url.searchParams.delete('openImport')
      window.history.replaceState({}, '', url.pathname + url.search)
    }
  }, [searchParams])

  const viewingShow = viewingShowIndex !== null ? filteredShows[viewingShowIndex] : null

  const handleNavigate = (direction: "next" | "previous") => {
    if (viewingShowIndex === null) return
    const newIndex = direction === "next" ? viewingShowIndex + 1 : viewingShowIndex - 1
    if (newIndex >= 0 && newIndex < filteredShows.length) setViewingShowIndex(newIndex)
  }

  const getUniqueValues = (key: keyof Show) => {
    const values = shows.map((show) => (show as any)[key]) as (string | number)[]
    return [...new Set(values)]
      .filter(Boolean)
      .sort((a, b) => String(a).localeCompare(String(b)))
  }

  const getYesNoBadge = (value: boolean) => (
    <Badge
      className={`text-xs border pointer-events-none ${
        value
          ? "bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/50 dark:text-emerald-300 dark:border-emerald-700"
          : "bg-red-100 text-red-800 border-red-300 dark:bg-red-900/50 dark:text-red-300 dark:border-red-700"
      }`}
    >
      {value ? "Yes" : "No"}
    </Badge>
  )

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-primary tracking-tight">
              Shows Management
            </h1>
            <p className="text-shimmer">Loading shows...</p>
          </div>
        </div>
        <Card>
          <CardContent className="text-center py-12">
            <div className="relative inline-flex items-center justify-center mb-4">
              <div 
                className="rounded-full p-4"
                style={{
                  backgroundColor: "rgba(255, 255, 255, 0.05)",
                  WebkitBackdropFilter: "blur(12px) saturate(180%)",
                  backdropFilter: "blur(12px) saturate(180%)",
                  boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
                  border: "1px solid hsl(var(--border))",
                }}
              >
                <Loader2 className="h-8 w-8 text-primary animate-spin" />
              </div>
            </div>
            <h3 className="text-lg font-medium mb-2 text-shimmer">Loading Shows</h3>
            <p className="text-shimmer">Please wait while we fetch your shows...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-primary">
              Shows Management
            </h1>
            <p className="text-muted-foreground">Error loading shows</p>
          </div>
        </div>
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <div className="font-medium mb-1">Failed to load shows</div>
            <p className="text-sm">{error}</p>
            <Button
              variant="outline"
              size="sm"
              className="mt-2 bg-transparent"
              onClick={() => fetchShows()}
            >
              Try Again
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
        {/* Title and description - buttons align with title only */}
        <div className="flex-1 flex items-center justify-between md:block md:items-start">
          <div>
            <h1 className="text-xl sm:text-3xl font-bold text-primary tracking-tight leading-tight">
              Shows Management
            </h1>
            {/* Description - right below title */}
            <p className="text-sm text-muted-foreground md:text-base">
              {user?.role === "admin" ? "Manage all shows in the network" : "View your assigned shows"}
            </p>
          </div>
          {/* View switcher, Search, and Table Density - mobile only */}
          <div className="md:hidden flex items-center gap-2">
            <AnimatedSwitcher
              activeIndex={viewMode === "cards" ? 0 : 1}
              onIndexChange={(index) => setViewMode(index === 0 ? "cards" : "list")}
              options={[
                { value: "cards", label: "Cards", icon: Grid3X3 },
                { value: "list", label: "List", icon: List }
              ]}
            />
          </div>
        </div>
        
        {/* Buttons Container - Right side on desktop, below on mobile */}
        <div>
          {/* Mobile Layout */}
          <div className="flex flex-col gap-4 md:hidden">
            {/* Archived shows and Add Show - same line */}
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                onClick={() => router.push("/archived-shows")}
                className="action-button-archived-shows w-full"
              >
                <Archive className="h-4 w-4" />
                Archived Shows
              </Button>

              {user?.role === "admin" && (
                <Button className="evergreen-button w-full" onClick={handleCreateNew}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Show
                </Button>
              )}
            </div>

            {/* Import CSV, Export CSV - same line */}
            <div className="flex items-center gap-2">
              {user?.role === "admin" && (
                <Button
                  variant="outline"
                  onClick={() => setIsImportDialogOpen(true)}
                  className="action-button-import w-full"
                >
                  <Upload className="h-4 w-4" />
                  Import Shows
                </Button>
              )}

              <Button
                variant="outline"
                onClick={handleExportCSV}
                className="action-button-export w-full"
              >
                <Download className="h-4 w-4" />
                Export Shows
              </Button>
            </div>

            {/* Search and Table Density - same line */}
            <div className="flex items-center gap-2">
              <div className="flex-1 relative h-10 min-h-10">
                <Search className="absolute left-3 top-0 h-full flex items-center justify-center w-4 text-muted-foreground z-10 pointer-events-none" aria-hidden />
                <Input
                  id="search-mobile"
                  placeholder="Search Shows..."
                  value={filters.search}
                  onChange={(e) => setFilters((prev) => ({ ...prev, search: e.target.value }))}
                  wrapperClassName="w-full h-full"
                  className="pl-9 pr-10"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (filters.search && !isClearExiting) {
                      setFilters((prev) => ({ ...prev, search: "" }))
                      setIsClearExiting(true)
                    }
                  }}
                  onTransitionEnd={() => isClearExiting && setIsClearExiting(false)}
                  className={cn(
                    "absolute right-0 top-0 bottom-0 w-10 flex items-center justify-center rounded-r-full text-muted-foreground hover:text-foreground hover:bg-muted/50 focus:outline-none focus:ring-0 z-10 transition-all duration-200 ease-out",
                    filters.search && !isClearExiting
                      ? "opacity-100 translate-x-0"
                      : isClearExiting
                        ? "opacity-0 translate-x-2 pointer-events-none"
                        : "opacity-0 translate-x-2 pointer-events-none"
                  )}
                  aria-label="Clear search"
                  aria-hidden={!filters.search && !isClearExiting}
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="flex-1">
                <Select value={currentDensity} onValueChange={handleDensityChange}>
                  <SelectTrigger className="w-full">
                    {currentDensity === "compact" ? (
                      <Minimize2 className="h-4 w-4 mr-2" />
                    ) : (
                      <LayoutGrid className="h-4 w-4 mr-2" />
                    )}
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">Default</SelectItem>
                    <SelectItem value="compact">Compact</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Desktop Layout */}
          <div className="hidden md:flex items-start gap-2">
            {/* Search Shows */}
            <div className="relative w-[280px] min-w-[240px] h-10 min-h-10">
              <Search className="absolute left-3 top-0 h-full flex items-center justify-center w-4 text-muted-foreground z-10 pointer-events-none" aria-hidden />
              <Input
                id="search-desktop"
                placeholder="Search Shows..."
                value={filters.search}
                onChange={(e) => setFilters((prev) => ({ ...prev, search: e.target.value }))}
                wrapperClassName="w-full h-full"
                className="pl-9 pr-10"
              />
              <button
                type="button"
                onClick={() => {
                  if (filters.search && !isClearExiting) {
                    setFilters((prev) => ({ ...prev, search: "" }))
                    setIsClearExiting(true)
                  }
                }}
                onTransitionEnd={() => isClearExiting && setIsClearExiting(false)}
                className={cn(
                  "absolute right-0 top-0 bottom-0 w-10 flex items-center justify-center rounded-r-full text-muted-foreground hover:text-foreground hover:bg-muted/50 focus:outline-none focus:ring-0 z-10 transition-all duration-200 ease-out",
                  filters.search && !isClearExiting
                    ? "opacity-100 translate-x-0"
                    : isClearExiting
                      ? "opacity-0 translate-x-2 pointer-events-none"
                      : "opacity-0 translate-x-2 pointer-events-none"
                )}
                aria-label="Clear search"
                aria-hidden={!filters.search && !isClearExiting}
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Table Density Dropdown */}
            <Select value={currentDensity} onValueChange={handleDensityChange}>
              <SelectTrigger className="w-[140px]">
                {currentDensity === "compact" ? (
                  <Minimize2 className="h-4 w-4 mr-2" />
                ) : (
                  <LayoutGrid className="h-4 w-4 mr-2" />
                )}
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Default</SelectItem>
                <SelectItem value="compact">Compact</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              onClick={() => router.push("/archived-shows")}
              className="action-button-archived-shows"
            >
              <Archive className="h-4 w-4" />
              Archived Shows
            </Button>

            {user?.role === "admin" && (
              <Button
                variant="outline"
                onClick={() => setIsImportDialogOpen(true)}
                className="action-button-import"
              >
                <Upload className="h-4 w-4" />
                Import Shows
              </Button>
            )}

            <Button
              variant="outline"
              onClick={handleExportCSV}
              className="action-button-export"
            >
              <Download className="h-4 w-4" />
              Export Shows
            </Button>

            {user?.role === "admin" && (
              <Button className="evergreen-button" onClick={handleCreateNew}>
                <Plus className="mr-2 h-4 w-4" />
                Add Show
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Import result */}
      {importResult && (
        <Alert variant={importResult.success ? "default" : "destructive"} className="relative">
          <div className="flex items-start gap-2">
            {importResult.success ? (
              <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
            ) : (
              <AlertCircle className="h-4 w-4 mt-0.5" />
            )}
            <div className="w-full">
              <AlertDescription>
                <div className="font-medium mb-1">{importResult.message}</div>
                {importResult.warnings && importResult.warnings.length > 0 && (
                  <div className="mt-2">
                    <p className="text-sm font-medium mb-1 text-muted-foreground">Note:</p>
                    <ul className="text-sm space-y-1 max-h-24 overflow-y-auto text-muted-foreground">
                      {importResult.warnings.map((w, i) => (
                        <li key={i} className="text-xs">• {w}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {importResult.errors && importResult.errors.length > 0 && (
                  <div className="mt-2">
                    <p className="text-sm font-medium mb-1">Errors found:</p>
                    <ul className="text-sm space-y-1 max-h-32 overflow-y-auto">
                      {importResult.errors.map((error, index) => {
                        const friendly = formatImportError(error);
                        return (
                          <li key={index} className="text-xs">• {friendly}</li>
                        );
                      })}
                    </ul>
                    {importResult.errors.length >= 10 && (
                      <p className="text-xs text-muted-foreground mt-1">
                        ... and more errors. Please fix these issues and try again.
                      </p>
                    )}
                  </div>
                )}
              </AlertDescription>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-2 right-2 h-6 w-6 p-0"
            onClick={() => setImportResult(null)}
          >
            <X className="h-4 w-4" />
          </Button>
        </Alert>
      )}

      {/* Filters */}
      <Card className="overflow-visible rounded-[30px] sm:rounded-[24px]">
        <Collapsible open={isFiltersOpen} onOpenChange={setIsFiltersOpen}>
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover:bg-accent/50 transition-colors group px-6 py-3 rounded-[30px] sm:rounded-[24px]">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CardTitle className="flex items-center gap-1.5 font-semibold text-base">
                    <Filter className="h-4 w-4" />
                    Filters
                  </CardTitle>
                </div>
                
                <div className="flex items-center gap-2">
                  {/* Mobile: Button-style badges, Desktop: Pill-style badges */}
                  <div className="hidden sm:flex gap-1">
                    <Badge className="text-xs px-1.5 py-0.5 bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/50 dark:text-blue-300 dark:border-blue-700 pointer-events-none">
                      Total - {showCounts.total}
                    </Badge>
                    <Badge className="text-xs px-1.5 py-0.5 bg-green-100 text-green-800 border-green-300 dark:bg-green-900/50 dark:text-green-300 dark:border-green-700 pointer-events-none">
                      Active - {showCounts.active}
                    </Badge>
                    <Badge className="text-xs px-1.5 py-0.5 bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/50 dark:text-orange-300 dark:border-orange-700 pointer-events-none">
                      Archived - {showCounts.archived}
                    </Badge>
                  </div>
                  
                  {/* Mobile: Button-style badges */}
                  <div className="flex sm:hidden gap-1.5">
                    <div className="px-2 py-1 flex flex-col items-center justify-center w-[60px] gap-0.5 h-8 border border-blue-300 bg-blue-100 dark:bg-blue-900/50 rounded-full pointer-events-none">
                      <span className="text-xs font-bold leading-none text-blue-800 dark:text-blue-300">{showCounts.total}</span>
                      <span className="text-[10px] text-blue-600 dark:text-blue-400 leading-none">Total</span>
                    </div>
                    <div className="px-2 py-1 flex flex-col items-center justify-center w-[60px] gap-0.5 h-8 border border-green-300 bg-green-100 dark:bg-green-900/50 rounded-full pointer-events-none">
                      <span className="text-xs font-bold leading-none text-green-800 dark:text-green-300">{showCounts.active}</span>
                      <span className="text-[10px] text-green-600 dark:text-green-400 leading-none">Active</span>
                    </div>
                    <div className="px-2 py-1 flex flex-col items-center justify-center w-[60px] gap-0.5 h-8 border border-orange-300 bg-orange-100 dark:bg-orange-900/50 rounded-full pointer-events-none">
                      <span className="text-xs font-bold leading-none text-orange-800 dark:text-orange-300">{showCounts.archived}</span>
                      <span className="text-[10px] text-orange-600 dark:text-orange-400 leading-none">Archived</span>
                    </div>
                  </div>
                  
                  <ChevronDown className="h-5 w-5 transition-transform duration-200 group-data-[state=open]:rotate-180" />
                </div>
              </div>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent 
            className="overflow-visible data-[state=closed]:animate-slideUp data-[state=open]:animate-slideDown"
          >
            <CardContent className="space-y-4 pt-1 [&>*:not(:first-child)]:mt-6">


               {/* ---- Divider + Show Information (alphabetical) ---- */}
               <Collapsible open={isShowInfoOpen} onOpenChange={setIsShowInfoOpen}>
               <div className="space-y-2">      {/* Section 2 */}
               <SectionDivider label="Show Information" isOpen={isShowInfoOpen} onToggle={() => setIsShowInfoOpen(!isShowInfoOpen)} />
              <CollapsibleContent className="overflow-visible data-[state=closed]:animate-slideUp data-[state=open]:animate-slideDown">
              <div className="space-y-2">
                 {/* <h4 className="text-sm font-semibold text-muted-foreground">Show Information</h4>  -- replaced by divider */}
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-7 gap-4">
                  {/* Age Demographic */}
                  <div className="space-y-2">
                    <Label>Age Demographic</Label>
                    <Select
                      value={filters.age_demographic}
                      onValueChange={(value) =>
                        setFilters((prev) => ({ ...prev, age_demographic: value }))
                      }
                    >
                      <SelectTrigger className={filters.age_demographic && filters.age_demographic !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="All Ages" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Ages</SelectItem>
                        <SelectItem value="18-24">18-24</SelectItem>
                        <SelectItem value="25-34">25-34</SelectItem>
                        <SelectItem value="35-44">35-44</SelectItem>
                        <SelectItem value="45-54">45-54</SelectItem>
                        <SelectItem value="55+">55+</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Format */}
                  <div className="space-y-2">
                    <Label>Format</Label>
                    <Select
                      value={filters.format}
                      onValueChange={(value) => setFilters((prev) => ({ ...prev, format: value }))}
                    >
                      <SelectTrigger className={filters.format && filters.format !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="All Formats" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Formats</SelectItem>
                        <SelectItem value="audio">Audio</SelectItem>
                        <SelectItem value="video">Video</SelectItem>
                        <SelectItem value="both">Both</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Gender */}
                  <div className="space-y-2">
                    <Label>Gender Demographic</Label>
                    <Select
                      value={filters.genderDemographic}
                      onValueChange={(value) =>
                        setFilters((prev) => ({ ...prev, genderDemographic: value }))
                      }
                    >
                      <SelectTrigger className={filters.genderDemographic && filters.genderDemographic !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="Any" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Any</SelectItem>
                        {getUniqueValues("gender").map((gender) => (
                          <SelectItem key={String(gender)} value={String(gender)}>
                            {gender}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Genre */}
                  <div className="space-y-2">
                    <Label>Genre</Label>
                    <Select
                      value={filters.genre_name}
                      onValueChange={(value) => setFilters((prev) => ({ ...prev, genre_name: value }))}
                    >
                      <SelectTrigger className={filters.genre_name && filters.genre_name !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="All Genres" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Genres</SelectItem>
                        {getUniqueValues("genre_name").map((genre) => (
                          <SelectItem key={String(genre)} value={String(genre)}>
                            {genre}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Original */}
                  <div className="space-y-2">
                    <Label>Original Content</Label>
                    <Select
                      value={filters.isOriginal}
                      onValueChange={(value) => setFilters((prev) => ({ ...prev, isOriginal: value }))}
                    >
                      <SelectTrigger className={filters.isOriginal && filters.isOriginal !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="All Content" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Content</SelectItem>
                        <SelectItem value="yes">Original</SelectItem>
                        <SelectItem value="no">Not Original</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Region */}
                  <div className="space-y-2">
                    <Label>Region</Label>
                    <Select
                      value={filters.region}
                      onValueChange={(value) => setFilters((prev) => ({ ...prev, region: value }))}
                    >
                      <SelectTrigger className={filters.region && filters.region !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="All Regions" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Regions</SelectItem>
                        {getUniqueValues("region").map((region) => (
                          <SelectItem key={String(region)} value={String(region)} className="capitalize">
                            {region}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Subnetwork */}
                  <div className="space-y-2">
                    <Label>Subnetwork</Label>
                    <Select
                      value={filters.subnetwork}
                      onValueChange={(value) => setFilters((prev) => ({ ...prev, subnetwork: value }))}
                    >
                      <SelectTrigger className={filters.subnetwork && filters.subnetwork !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                         <SelectValue placeholder="All Subnetworks" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Subnetworks</SelectItem>
                        {getUniqueValues("subnetwork_id").map((sub) => (
                          <SelectItem key={String(sub)} value={String(sub)}>
                            {sub}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                 </div>
                 
                 {/* Second row for remaining filters */}
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-7 gap-4">
                   {/* Cadence */}
                   <div className="space-y-2">
                     <Label>Cadence</Label>
                     <Select value={filters.cadence} onValueChange={(value) => setFilters((prev) => ({ ...prev, cadence: value }))}>
                       <SelectTrigger className={filters.cadence && filters.cadence !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                         <SelectValue placeholder="All Cadences" />
                       </SelectTrigger>
                       <SelectContent>
                         <SelectItem value="all">All Cadences</SelectItem>
                         <SelectItem value="Daily">Daily</SelectItem>
                         <SelectItem value="Weekly">Weekly</SelectItem>
                         <SelectItem value="Biweekly">Biweekly</SelectItem>
                         <SelectItem value="Monthly">Monthly</SelectItem>
                         <SelectItem value="Ad hoc">Ad hoc</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Relationship */}
                  <div className="space-y-2">
                    <Label>Relationship</Label>
                    <Select
                      value={filters.relationship}
                      onValueChange={(value) => setFilters((prev) => ({ ...prev, relationship: value }))}
                    >
                      <SelectTrigger className={filters.relationship && filters.relationship !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                         <SelectValue placeholder="All Relationships" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Relationships</SelectItem>
                        <SelectItem value="strong">Strong</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="weak">Weak</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Show Status */}
                  <div className="space-y-2">
                    <Label>Show Status</Label>
                    <Select
                      value={filters.is_active}
                      onValueChange={(value) => setFilters((prev) => ({ ...prev, is_active: value }))}
                    >
                      <SelectTrigger className={filters.is_active && filters.is_active !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                         <SelectValue placeholder="All Statuses" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Statuses</SelectItem>
                        <SelectItem value="yes">Active</SelectItem>
                        <SelectItem value="no">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Show Type */}
                  <div className="space-y-2">
                    <Label>Show Type</Label>
                    <Select
                      value={filters.show_type}
                      onValueChange={(value) => setFilters((prev) => ({ ...prev, show_type: value }))}
                    >
                      <SelectTrigger className={filters.show_type && filters.show_type !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                         <SelectValue placeholder="All Show Types" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Show Types</SelectItem>
                        <SelectItem value="original">Original</SelectItem>
                        <SelectItem value="branded">Branded</SelectItem>
                        <SelectItem value="partner">Partner</SelectItem>
                        <SelectItem value="hybrid">Hybrid</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Rate Card */}
                  <div className="space-y-2">
                    <Label>Rate Card Show</Label>
                    <Select
                      value={filters.rate_card}
                      onValueChange={(value) => setFilters((prev) => ({ ...prev, rate_card: value }))}
                    >
                      <SelectTrigger className={filters.rate_card && filters.rate_card !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                         <SelectValue placeholder="All Shows" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Shows</SelectItem>
                        <SelectItem value="yes">Yes</SelectItem>
                        <SelectItem value="no">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Undersized */}
                  <div className="space-y-2">
                    <Label>Undersized Show</Label>
                    <Select
                      value={filters.is_undersized}
                      onValueChange={(value) => setFilters((prev) => ({ ...prev, is_undersized: value }))}
                    >
                      <SelectTrigger className={filters.is_undersized && filters.is_undersized !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                         <SelectValue placeholder="All Sizes" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Sizes</SelectItem>
                        <SelectItem value="yes">Undersized</SelectItem>
                        <SelectItem value="no">Not Undersized</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Archive Status */}
                  <div className="space-y-2">
                    <Label>Show Status</Label>
                    <Select
                      value={filters.show_archived}
                      onValueChange={(value) => setFilters((prev) => ({ ...prev, show_archived: value }))}
                    >
                      <SelectTrigger className={filters.show_archived && filters.show_archived !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="All Shows" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active Shows</SelectItem>
                        <SelectItem value="archived">Archived Shows</SelectItem>
                        <SelectItem value="all">All Shows</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                </div>
              </CollapsibleContent>
              </div>
              </Collapsible>

              {/* ---- Divider + Financial Information ---- */}
              <div style={{ marginTop: '2rem' }}>
              <Collapsible open={isFinancialInfoOpen} onOpenChange={setIsFinancialInfoOpen}>
              <div className="space-y-2">      {/* Section 3 */}
              <SectionDivider label="Financial Information" isOpen={isFinancialInfoOpen} onToggle={() => setIsFinancialInfoOpen(!isFinancialInfoOpen)} />
              <CollapsibleContent className="overflow-visible data-[state=closed]:animate-slideUp data-[state=open]:animate-slideDown">
              <div className="space-y-2">
                {/* <h4 className="text-sm font-semibold text-muted-foreground">Financial Information</h4> -- replaced by divider */}
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-7 gap-4">
                   {/* Partner Ledger Access */}
                   <div className="space-y-2">
                     <Label>Partner Ledger Access</Label>
                     <Select
                       value={filters.requiresPartnerLedgerAccess}
                       onValueChange={(value) =>
                         setFilters((prev) => ({ ...prev, requiresPartnerLedgerAccess: value }))
                       }
                     >
                       <SelectTrigger className={filters.requiresPartnerLedgerAccess && filters.requiresPartnerLedgerAccess !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                         <SelectValue placeholder="Any" />
                       </SelectTrigger>
                       <SelectContent>
                         <SelectItem value="all">Any</SelectItem>
                         <SelectItem value="yes">Yes</SelectItem>
                         <SelectItem value="no">No</SelectItem>
                       </SelectContent>
                     </Select>
                   </div>

                   {/* Average Length */}
                  <div className="space-y-2">
                    <Label>Average Length (min)</Label>
                    <Input
                      type="number"
                      placeholder="e.g. 60"
                      value={filters.averageLength}
                      onChange={(e) =>
                        setFilters((prev) => ({ ...prev, averageLength: e.target.value }))
                      }
                      wrapperClassName={filters.averageLength ? FILTER_HIGHLIGHT_CLASS : ""}
                    />
                  </div>

                  {/* Branded Revenue */}
                  <div className="space-y-2">
                    <Label>Branded Revenue</Label>
                    <Select
                      value={filters.hasBrandedRevenue}
                      onValueChange={(value) =>
                        setFilters((prev) => ({ ...prev, hasBrandedRevenue: value }))
                      }
                    >
                      <SelectTrigger className={filters.hasBrandedRevenue && filters.hasBrandedRevenue !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="Any" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Any</SelectItem>
                        <SelectItem value="yes">Yes</SelectItem>
                        <SelectItem value="no">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Marketing Revenue */}
                  <div className="space-y-2">
                    <Label>Marketing Revenue</Label>
                    <Select
                      value={filters.hasMarketingRevenue}
                      onValueChange={(value) =>
                        setFilters((prev) => ({ ...prev, hasMarketingRevenue: value }))
                      }
                    >
                      <SelectTrigger className={filters.hasMarketingRevenue && filters.hasMarketingRevenue !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="Any" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Any</SelectItem>
                        <SelectItem value="yes">Yes</SelectItem>
                        <SelectItem value="no">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Sponsorship Revenue */}
                  <div className="space-y-2">
                    <Label>Sponsorship Revenue</Label>
                    <Select
                      value={filters.hasSponsorshipRevenue}
                      onValueChange={(value) =>
                        setFilters((prev) => ({ ...prev, hasSponsorshipRevenue: value }))
                      }
                    >
                      <SelectTrigger className={filters.hasSponsorshipRevenue && filters.hasSponsorshipRevenue !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="Any" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Any</SelectItem>
                        <SelectItem value="yes">Yes</SelectItem>
                        <SelectItem value="no">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Web Management Revenue */}
                  <div className="space-y-2">
                    <Label>Web Management Revenue</Label>
                    <Select
                      value={filters.hasWebManagementRevenue}
                      onValueChange={(value) =>
                        setFilters((prev) => ({ ...prev, hasWebManagementRevenue: value }))
                      }
                    >
                      <SelectTrigger className={filters.hasWebManagementRevenue && filters.hasWebManagementRevenue !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="Any" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Any</SelectItem>
                        <SelectItem value="yes">Yes</SelectItem>
                        <SelectItem value="no">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Minimum Guarantee */}
                  <div className="space-y-2">
                    <Label>Minimum Guarantee</Label>
                    <Select
                      value={filters.minimumGuarantee}
                      onValueChange={(value) =>
                        setFilters((prev) => ({ ...prev, minimumGuarantee: value }))
                      }
                    >
                      <SelectTrigger className={filters.minimumGuarantee && filters.minimumGuarantee !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="Any" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Any</SelectItem>
                        <SelectItem value="yes">Yes</SelectItem>
                        <SelectItem value="no">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Ownership % */}
                  <div className="space-y-2">
                    <Label>Ownership %</Label>
                    <Select
                      value={filters.ownershipPercentage}
                      onValueChange={(value) =>
                        setFilters((prev) => ({ ...prev, ownershipPercentage: value }))
                      }
                    >
                      <SelectTrigger className={filters.ownershipPercentage && filters.ownershipPercentage !== "all" ? FILTER_HIGHLIGHT_CLASS : ""}>
                        <SelectValue placeholder="All Ownership" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Ownership</SelectItem>
                        {getUniqueValues("evergreen_ownership_pct").map((percentage) => (
                          <SelectItem key={String(percentage)} value={String(percentage)}>
                            {percentage}%
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Revenue 2023 */}
                  <div className="space-y-2">
                    <Label>Revenue 2023 ($) ≥</Label>
                    <Input
                      type="number"
                      placeholder="e.g. 10000"
                      value={filters.revenue2023}
                      onChange={(e) =>
                        setFilters((prev) => ({ ...prev, revenue2023: e.target.value }))
                      }
                      wrapperClassName={filters.revenue2023 ? FILTER_HIGHLIGHT_CLASS : ""}
                    />
                  </div>

                  {/* Revenue 2024 */}
                  <div className="space-y-2">
                    <Label>Revenue 2024 ($) ≥</Label>
                    <Input
                      type="number"
                      placeholder="e.g. 15000"
                      value={filters.revenue2024}
                      onChange={(e) =>
                        setFilters((prev) => ({ ...prev, revenue2024: e.target.value }))
                      }
                      wrapperClassName={filters.revenue2024 ? FILTER_HIGHLIGHT_CLASS : ""}
                    />
                  </div>

                  {/* Revenue 2025 */}
                  <div className="space-y-2">
                    <Label>Revenue 2025 ($) ≥</Label>
                    <Input
                      type="number"
                      placeholder="e.g. 20000"
                      value={filters.revenue2025}
                      onChange={(e) =>
                        setFilters((prev) => ({ ...prev, revenue2025: e.target.value }))
                      }
                      wrapperClassName={filters.revenue2025 ? FILTER_HIGHLIGHT_CLASS : ""}
                    />
                  </div>

                 </div>
               </div>
          </CollapsibleContent>
          </div>
          </Collapsible>
          </div>

          
          <div className="flex items-start justify-between gap-2 pt-2">
            {/* Chips area */}
            <div className="flex flex-wrap gap-2 max-w-[85%]">
              {activeFilterBadges.map((f, idx) => (
                <Badge
                  key={`${f.label}-${f.value}-${idx}`}
                  className="text-xs border bg-emerald-100 text-emerald-800 border-emerald-300
             dark:bg-emerald-900/40 dark:text-emerald-300 dark:border-emerald-700
             flex items-center gap-1 hover:bg-emerald-100 hover:text-emerald-800
             dark:hover:bg-emerald-900/40 dark:hover:text-emerald-300"
                >
                  <span>{f.label}: {toTitleCase(f.value)}</span>
                  <button
                    type="button"
                    aria-label={`Clear ${f.label}`}
                    className="ml-1 rounded hover:opacity-80"
                    onClick={() => clearSingleFilter(f.key)}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>

            {/* Fixed button */}
            <div className="flex-shrink-0">
              <Button variant="outline" onClick={handleClearFilters}>
                <RotateCcw className="mr-2 h-4 w-4" />
                Clear All Filters
              </Button>
            </div>
          </div>


            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>


      {/* Shows Display */}
      <div className="-mt-2">
        <Card>
          <CardContent className="p-6">
            {/* TOP TOOLBAR: Selection (left) + Pagination (right) */}
            {filteredShows.length > 0 && (
              <ShowsToolbar
                selectedShows={selectedShows}
                filteredShows={filteredShows}
                page={page}
                totalPages={totalPages}
                onGotoPrev={gotoPrev}
                onGotoNext={gotoNext}
                onSelectAll={handleSelectAll}
                onBulkArchive={handleBulkArchive}
                onBulkUnarchive={handleBulkUnarchive}
                onBulkDelete={handleBulkDelete}
                isBulkArchiving={isBulkArchiving}
                isBulkUnarchiving={isBulkUnarchiving}
                isBulkDeleting={isBulkDeleting}
                userRole={user?.role || undefined}
                isTopToolbar={true}
                pageRangeStart={pageRangeStart}
                pageRangeEnd={pageRangeEnd}
                gotoInput={gotoInput}
                setGotoInput={setGotoInput}
                handleGoto={handleGoto}
                pageSize={PAGE_SIZE}
                onPageSizeChange={handlePageSizeChange}
                pageSizeOptions={PAGE_SIZE_OPTIONS}
              />
            )}
            
            {/* Animated Content Area */}
            <AnimatedContentWrapper 
              viewMode={viewMode}
              cardsView={
                  <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6 p-0.5">
                    {paginatedShows.map((show) => (
                <Card
                  key={show.id}
                  className={`group flex flex-col h-full ${
                    selectedShows.has(show.id)
                      ? "shadow-[0_0_0_2px_rgb(16_185_129)] bg-emerald-50/50 dark:bg-emerald-950/20"
                      : ""
                  }`}
                >
                  <CardHeader className="flex-shrink-0 p-4">
                    <div className="space-y-2">
                      <div className="flex items-start gap-3">
                        <Checkbox
                          checked={selectedShows.has(show.id)}
                          onCheckedChange={() => handleSelectShow(show.id)}
                          className="mt-1"
                        />
                        <CardTitle className="text-lg group-hover:text-emerald-600 transition-colors w-full line-clamp-2 leading-tight">
                          {show.title}
                        </CardTitle>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge className="text-xs border bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/50 dark:text-purple-300 dark:border-purple-700 capitalize pointer-events-none">
                          {show.show_type || "N/A"}
                        </Badge>
                        <Badge
                          className={`text-xs border pointer-events-none ${
                            show.rate_card
                              ? "bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/50 dark:text-emerald-300 dark:border-emerald-700"
                              : "bg-red-100 text-red-800 border-red-300 dark:bg-red-900/50 dark:text-red-300 dark:border-red-700"
                          }`}
                        >
                          {`Rate Card - ${show.rate_card ? "Yes" : "No"}`}
                        </Badge>
                        {(() => {
                          const rankingInfo = getRankingInfo(show.ranking_category);
                          return rankingInfo.hasRanking ? (
                            <Badge variant="secondary" className={`text-xs border pointer-events-none ${rankingInfo.badgeClasses}`}>
                              {rankingInfo.displayText}
                            </Badge>
                          ) : null;
                        })()}
                      </div>
                      
                      {/* Split pills - second line */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="relative flex items-center bg-blue-100 dark:bg-blue-900/50 border border-blue-300 dark:border-blue-700 rounded-full overflow-hidden w-32">
                          <span className="text-xs font-bold text-blue-600 dark:text-blue-200 px-2 py-1">Standard</span>
                          <div className="absolute top-0 bottom-0 bg-white dark:bg-black rounded-full flex items-center px-2 right-0">
                            <span className="text-sm font-bold text-blue-600 dark:text-blue-200">{formatPercentage(getStandardSplit(show))}</span>
                          </div>
                        </div>
                        <div className="relative flex items-center bg-purple-100 dark:bg-purple-900/50 border border-purple-300 dark:border-purple-700 rounded-full overflow-hidden w-[10rem]">
                          <span className="text-xs font-bold text-purple-600 dark:text-purple-200 px-2 py-1">Programmatic</span>
                          <div className="absolute top-0 bottom-0 bg-white dark:bg-black rounded-full flex items-center px-2 right-0">
                            <span className="text-sm font-bold text-purple-600 dark:text-purple-200">{formatPercentage(getProgrammaticSplit(show))}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="w-full flex flex-col justify-between pt-0 pb-2">
                    <div>
                      {/* Content area - can be used for additional info if needed */}
                    </div>

                    <div className="flex justify-center gap-2 pt-2 pb-1 border-t border-border/50">
                      {show.is_archived && (
                        <Badge className="text-xs bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/50 dark:text-orange-300 dark:border-orange-700 pointer-events-none">
                          <Archive className="h-3 w-3 mr-1" />
                          Archived
                        </Badge>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 px-3 hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50 border-border hover:border-border"
                        onClick={() => handleViewShow(show)}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        View
                      </Button>
                      {user?.role === "admin" && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="outline" size="sm" className="h-8 px-2 hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50 border-border hover:border-border">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {user?.role === "admin" && !show.is_archived && (
                              <DropdownMenuItem onClick={() => handleEditShow(show)}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                            )}
                            {user?.role === "admin" && (
                              show.is_archived ? (
                                <DropdownMenuItem onClick={() => handleUnarchiveShow(show)} className="text-green-600 focus:text-green-700">
                                  <RotateCcw className="h-4 w-4 mr-2" />
                                  Unarchive
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem onClick={() => handleArchiveShow(show)} className="text-orange-600 focus:text-orange-700">
                                  <Archive className="h-4 w-4 mr-2" />
                                  Archive
                                </DropdownMenuItem>
                              )
                            )}
                            {user?.role === "admin" && (
                              <DropdownMenuItem
                                className="text-red-600 focus:text-red-700"
                                onClick={() => handleDeleteShow(show)}
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </div>
                  </CardContent>
                </Card>
                    ))}
                  </div>
              }
              listView={
                  <div className={`rounded-md border overflow-x-auto ${getTableDensityClass("shows")}`}>
                  <table className="w-full text-sm min-w-[800px]">
                    <thead className="border-b">
                      <tr className="text-left text-sm">
                        <th className="px-2 py-4 w-8 border-r bg-muted/50 text-center whitespace-nowrap text-muted-foreground">
                          <Checkbox
                            checked={selectedShows.size === filteredShows.length && filteredShows.length > 0}
                            onCheckedChange={handleSelectAll}
                          />
                        </th>
                        <th 
                          className="px-4 py-4 font-semibold border-r cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 w-80 whitespace-nowrap text-muted-foreground"
                          onClick={() => handleSort('name')}
                        >
                          <div className="flex items-center gap-2">
                            Show Name
                            {getSortIcon('name')}
                          </div>
                        </th>
                        <th 
                          className="px-4 py-4 font-semibold border-r cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 w-24 whitespace-nowrap text-muted-foreground"
                          onClick={() => handleSort('show_type')}
                        >
                          <div className="flex items-center gap-2">
                            Type
                            {getSortIcon('show_type')}
                          </div>
                        </th>
                        <th 
                          className="px-4 py-4 font-semibold border-r cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 w-32 whitespace-nowrap text-muted-foreground"
                          onClick={() => handleSort('ranking_category')}
                        >
                          <div className="flex items-center gap-2">
                            Ranking
                            {getSortIcon('ranking_category')}
                          </div>
                        </th>
                        <th 
                          className="px-4 py-4 font-semibold border-r cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 w-20 whitespace-nowrap text-muted-foreground"
                          onClick={() => handleSort('isRateCard')}
                        >
                          <div className="flex items-center gap-2">
                            Rate Card
                            {getSortIcon('isRateCard')}
                          </div>
                        </th>
                        <th 
                          className="px-4 py-4 font-semibold border-r cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 w-32 whitespace-nowrap text-muted-foreground"
                          onClick={() => handleSort('standardSplit')}
                        >
                          <div className="flex items-center gap-2">
                            Standard
                            {getSortIcon('standardSplit')}
                          </div>
                        </th>
                        <th 
                          className="px-4 py-4 font-semibold border-r cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 w-36 whitespace-nowrap text-muted-foreground"
                          onClick={() => handleSort('programmaticSplit')}
                        >
                          <div className="flex items-center gap-2">
                            Programmatic
                            {getSortIcon('programmaticSplit')}
                          </div>
                        </th>
                        <th className="px-4 py-4 font-semibold bg-muted/50 w-24 whitespace-nowrap text-muted-foreground">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="[&_tr:last-child]:border-0">
                      {paginatedShows.map((show) => (
                        <tr
                          key={show.id}
                          className={`border-b hover:bg-accent/50 transition-colors ${
                            selectedShows.has(show.id)
                              ? "bg-emerald-50/50 dark:bg-emerald-950/20"
                              : ""
                          }`}
                        >
                          <td className="px-2 py-2 border-r w-8 text-center whitespace-nowrap">
                            <Checkbox
                              checked={selectedShows.has(show.id)}
                              onCheckedChange={() => handleSelectShow(show.id)}
                            />
                          </td>
                          <td className="pl-6 pr-6 py-2 font-medium border-r cursor-pointer hover:bg-accent/30 transition-colors whitespace-nowrap" onClick={() => handleViewShow(show)}>
                            <div className="flex items-center gap-2">
                              <span className="hover:underline">
                                {show.title}
                              </span>
                              {show.is_archived && (
                                <Badge className="text-xs bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/50 dark:text-orange-300 dark:border-orange-700 pointer-events-none">
                                  Archived
                                </Badge>
                              )}
                            </div>
                          </td>
                          <td className="pl-6 pr-6 py-2 capitalize border-r whitespace-nowrap">{show.show_type || "N/A"}</td>
            <td className="pl-6 pr-6 py-2 border-r whitespace-nowrap">
              {(() => {
                const rankingInfo = getRankingInfo(show.ranking_category);
                return rankingInfo.hasRanking ? (
                  <Badge variant="secondary" className={rankingInfo.badgeClasses}>
                    {rankingInfo.displayText}
                  </Badge>
                ) : (
                  <span className="text-muted-foreground">N/A</span>
                );
              })()}
            </td>
                          <td className="pl-6 pr-6 py-2 border-r whitespace-nowrap">{getYesNoBadge(!!show.rate_card)}</td>
                          <td className="pl-6 pr-6 py-2 border-r whitespace-nowrap">{formatPercentage(getStandardSplit(show))}</td>
                          <td className="pl-6 pr-6 py-2 border-r whitespace-nowrap">{formatPercentage(getProgrammaticSplit(show))}</td>
                          <td className="pl-6 pr-6 py-2 whitespace-nowrap">
                            <div className="flex items-center gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-7 px-2 bg-transparent"
                                onClick={() => handleViewShow(show)}
                              >
                                <Eye className="h-3 w-3 mr-1" />
                                View
                              </Button>
                              {user?.role === "admin" && (
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="outline" size="sm" className="h-7 px-2 bg-transparent">
                                      <MoreHorizontal className="h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    {!show.is_archived && (
                                      <DropdownMenuItem onClick={() => handleEditShow(show)}>
                                        <Edit className="h-4 w-4 mr-2" />
                                        Edit
                                      </DropdownMenuItem>
                                    )}
                                    {show.is_archived ? (
                                      <DropdownMenuItem onClick={() => handleUnarchiveShow(show)} className="text-green-600 focus:text-green-700">
                                        <RotateCcw className="h-4 w-4 mr-2" />
                                        Unarchive
                                      </DropdownMenuItem>
                                    ) : (
                                      <DropdownMenuItem onClick={() => handleArchiveShow(show)} className="text-orange-600 focus:text-orange-700">
                                        <Archive className="h-4 w-4 mr-2" />
                                        Archive
                                      </DropdownMenuItem>
                                    )}
                                    <DropdownMenuItem
                                      className="text-red-600 focus:text-red-700"
                                      onClick={() => handleDeleteShow(show)}
                                    >
                                      <Trash2 className="h-4 w-4 mr-2" />
                                      Delete
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  </div>
              }
            />
            
            {/* BOTTOM TOOLBAR: Selection (left) + Pagination (right) */}
            {filteredShows.length > 0 && (
              <ShowsBottomToolbar
                selectedShows={selectedShows}
                filteredShows={filteredShows}
                page={page}
                totalPages={totalPages}
                onGotoPrev={gotoPrev}
                onGotoNext={gotoNext}
                onSelectAll={handleSelectAll}
                onBulkArchive={handleBulkArchive}
                onBulkUnarchive={handleBulkUnarchive}
                onBulkDelete={handleBulkDelete}
                isBulkArchiving={isBulkArchiving}
                isBulkUnarchiving={isBulkUnarchiving}
                isBulkDeleting={isBulkDeleting}
                userRole={user?.role || undefined}
                isTopToolbar={false}
                pageRangeStart={pageRangeStart}
                pageRangeEnd={pageRangeEnd}
                gotoInput={gotoInput}
                setGotoInput={setGotoInput}
                handleGoto={handleGoto}
                pageSize={PAGE_SIZE}
                onPageSizeChange={handlePageSizeChange}
                pageSizeOptions={PAGE_SIZE_OPTIONS}
              />
            )}
          </CardContent>
        </Card>
      </div>

      {filteredShows.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Radio className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No shows found</h3>
            <p className="text-muted-foreground">
              {user?.role === "admin"
                ? "Try adjusting your filters or create a new show."
                : "No shows match your current filters."}
            </p>
          </CardContent>
        </Card>
      )}


      {/* Dialogs */}
      <CreateShowDialog
        open={isCreateDialogOpen}
        onOpenChange={setIsCreateDialogOpen}
        editingShow={editingShow}
        onShowUpdated={handleShowUpdated}
        createShow={createShow}
        updateShow={updateShow}
        existingShows={shows}
        onEditExistingShow={handleEditExistingShow}
      />
      <DeleteShowDialog
        open={!!deletingShow}
        onOpenChange={(open) => !open && setDeletingShow(null)}
        show={deletingShow}
        onShowDeleted={handleShowDeleted}
        deleteShow={deleteShow}
      />
      <ImportCSVDialog
        open={isImportDialogOpen}
        onOpenChange={setIsImportDialogOpen}
        onImportComplete={handleImportComplete}
      />
      <ShowViewDialog
        open={viewingShowIndex !== null}
        onOpenChange={(open) => !open && setViewingShowIndex(null)}
        show={viewingShow}
        onNavigate={handleNavigate}
        hasNext={viewingShowIndex !== null && viewingShowIndex < filteredShows.length - 1}
        hasPrevious={viewingShowIndex !== null && viewingShowIndex > 0}
        onEdit={user?.role === "admin" ? handleEditShow : undefined}
        onDelete={user?.role === "admin" ? handleDeleteShow : undefined}
        onArchive={user?.role === "admin" ? handleArchiveFromDialog : undefined}
        onUnarchive={user?.role === "admin" ? handleUnarchiveFromDialog : undefined}
        isArchived={viewingShow?.is_archived || false}
      />

      {/* Individual Archive/Unarchive Confirmation Dialog */}
      <AlertDialog open={showArchiveConfirm} onOpenChange={setShowArchiveConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className={showingArchiveShow?.is_archived ? 'text-green-600 dark:text-green-400' : 'text-orange-600 dark:text-orange-400'}>
              {showingArchiveShow?.is_archived ? (
                <>
                  <RotateCcw className="h-5 w-5 inline-block mr-2" />
                  Unarchive Show
                </>
              ) : (
                <>
                  <Archive className="h-5 w-5 inline-block mr-2" />
                  Archive Show
                </>
              )}
            </AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogDescription asChild>
            <div className="space-y-2">
              <p>Are you sure you want to {showingArchiveShow?.is_archived ? 'unarchive' : 'archive'} <strong>{showingArchiveShow?.title}</strong>?</p>
              <p>
                {showingArchiveShow?.is_archived 
                  ? 'This will move the show back to the active shows list.'
                  : 'This will move the show to the archived shows page where it can be unarchived later.'
                }
              </p>
            </div>
          </AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogAction
              onClick={showingArchiveShow?.is_archived ? handleConfirmUnarchiveShow : handleConfirmArchiveShow}
              className={showingArchiveShow?.is_archived ? "bg-green-600 hover:bg-green-700 focus:ring-green-600 text-white" : "bg-orange-600 hover:bg-orange-700 focus:ring-orange-600 text-white"}
            >
              {showingArchiveShow?.is_archived ? (
                <>
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Unarchive Show
                </>
              ) : (
                <>
                  <Archive className="h-4 w-4 mr-2" />
                  Archive Show
                </>
              )}
            </AlertDialogAction>
            <AlertDialogCancel onClick={() => setShowArchiveConfirm(false)}>
              Cancel
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Bulk Archive Confirmation Dialog */}
      <AlertDialog open={showBulkArchiveConfirm} onOpenChange={setShowBulkArchiveConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-orange-600 dark:text-orange-400">
              <Archive className="h-5 w-5 inline-block mr-2" />
              Archive Selected Shows
            </AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogDescription asChild>
            <div className="space-y-2">
              <p>Are you sure you want to archive {selectedShows.size} selected show{selectedShows.size > 1 ? 's' : ''}?</p>
              <p>This will move the shows to the archived shows page where they can be unarchived later.</p>
            </div>
          </AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogAction
              onClick={handleConfirmBulkArchive}
              disabled={isBulkArchiving}
              className="evergreen-button-orange"
            >
              {isBulkArchiving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Archiving...
                </>
              ) : (
                <>
                  <Archive className="h-4 w-4 mr-2" />
                  Archive {selectedShows.size} Show{selectedShows.size > 1 ? 's' : ''}
                </>
              )}
            </AlertDialogAction>
            <AlertDialogCancel onClick={() => setShowBulkArchiveConfirm(false)} disabled={isBulkArchiving}>
              Cancel
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Bulk Unarchive Confirmation Dialog */}
      <AlertDialog open={showBulkUnarchiveConfirm} onOpenChange={setShowBulkUnarchiveConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-green-600 dark:text-green-400">
              <RotateCcw className="h-5 w-5 inline-block mr-2" />
              Unarchive Selected Shows
            </AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogDescription asChild>
            <div className="space-y-2">
              <p>Are you sure you want to unarchive {selectedShows.size} selected show{selectedShows.size > 1 ? 's' : ''}?</p>
              <p>This will move the shows back to the active shows list.</p>
            </div>
          </AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogAction
              onClick={handleConfirmBulkUnarchive}
              disabled={isBulkUnarchiving}
              className="evergreen-button-green"
            >
              {isBulkUnarchiving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Unarchiving...
                </>
              ) : (
                <>
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Unarchive {selectedShows.size} Show{selectedShows.size > 1 ? 's' : ''}
                </>
              )}
            </AlertDialogAction>
            <AlertDialogCancel onClick={() => setShowBulkUnarchiveConfirm(false)} disabled={isBulkUnarchiving}>
              Cancel
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Bulk Delete Confirmation Dialog */}
      <AlertDialog open={showBulkDeleteConfirm} onOpenChange={setShowBulkDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-red-600 dark:text-red-400">
              <AlertTriangle className="h-5 w-5 inline-block mr-2" />
              Delete Selected Shows
            </AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogDescription asChild>
            <div className="space-y-2">
              <p>Are you sure you want to delete {selectedShows.size} selected show{selectedShows.size > 1 ? 's' : ''}?</p>
              <p>This action cannot be undone and will permanently remove:</p>
              <ul className="ml-4 list-disc space-y-1">
                <li>All show data and settings</li>
                <li>Associated revenue records</li>
                <li>Partner access permissions</li>
                <li>Historical performance data</li>
              </ul>
            </div>
          </AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogAction
              onClick={handleConfirmBulkDelete}
              disabled={isBulkDeleting}
              className="evergreen-button-red"
            >
              {isBulkDeleting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete {selectedShows.size} Show{selectedShows.size > 1 ? 's' : ''}
                </>
              )}
            </AlertDialogAction>
            <AlertDialogCancel onClick={() => setShowBulkDeleteConfirm(false)} disabled={isBulkDeleting}>
              Cancel
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}