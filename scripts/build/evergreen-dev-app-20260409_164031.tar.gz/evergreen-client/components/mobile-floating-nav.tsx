"use client"

import { useAuth } from "@/lib/auth-context"
import { useSettings } from "@/lib/settings-context"
import { usePathname, useRouter } from "next/navigation"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { Home, Radio, DollarSign, Shield, Lightbulb, Settings, LogOut } from "lucide-react"
import { useState, useEffect, useRef, useMemo } from "react"

export default function MobileFloatingNav() {
  const { user, logout } = useAuth()
  const { settings } = useSettings()
  const pathname = usePathname()
  const router = useRouter()
  const [activeIndex, setActiveIndex] = useState(0)
  const indicatorRef = useRef<HTMLDivElement>(null)
  const navRef = useRef<HTMLDivElement>(null)

  // Role-based navigation items
  // Items can be either links (href) or actions (onClick)
  const mainNavItems: { 
    href?: string; 
    label: string; 
    icon: any; 
    shortLabel: string; 
    onClick?: () => void;
    isAction?: boolean;
  }[] = useMemo(() => {
    if (user?.role === "partner") {
      return [
        { href: "/revenue-ledger", label: "Revenue Ledger", icon: DollarSign, shortLabel: "Revenue" },
        { href: "/settings", label: "Settings", icon: Settings, shortLabel: "Settings" },
        { label: "Sign Out", icon: LogOut, shortLabel: "Sign Out", onClick: () => { logout(); router.push("/login"); }, isAction: true }
      ]
    } else if (user?.role === "internal_show_access") {
      return [
        { href: "/shows-management", label: "Shows", icon: Radio, shortLabel: "Shows" },
        { href: "/add-feature-suggestion", label: "Feature Suggestion", icon: Lightbulb, shortLabel: "Feature" },
        { href: "/settings", label: "Settings", icon: Settings, shortLabel: "Settings" },
        { label: "Sign Out", icon: LogOut, shortLabel: "Sign Out", onClick: () => { logout(); router.push("/login"); }, isAction: true }
      ]
    } else if (user?.role === "internal_full_access") {
      return [
        { href: "/", label: "Dashboard", icon: Home, shortLabel: "Home" },
        { href: "/shows-management", label: "Shows", icon: Radio, shortLabel: "Shows" },
        { href: "/revenue-ledger", label: "Revenue Ledger", icon: DollarSign, shortLabel: "Revenue" },
        { href: "/add-feature-suggestion", label: "Feature Suggestion", icon: Lightbulb, shortLabel: "Feature" }
      ]
    } else if (user?.role === "admin") {
      return [
        { href: "/", label: "Dashboard", icon: Home, shortLabel: "Home" },
        { href: "/shows-management", label: "Shows", icon: Radio, shortLabel: "Shows" },
        { href: "/revenue-ledger", label: "Revenue Ledger", icon: DollarSign, shortLabel: "Revenue" },
        { href: "/administrator", label: "Administrator", icon: Shield, shortLabel: "Admin" }
      ]
    } else {
      return [
        { href: "/", label: "Dashboard", icon: Home, shortLabel: "Home" },
        { href: "/shows-management", label: "Shows", icon: Radio, shortLabel: "Shows" },
        { href: "/revenue-ledger", label: "Revenue Ledger", icon: DollarSign, shortLabel: "Revenue" }
      ]
    }
  }, [user?.role, logout, router])

  // Update active index based on pathname
  useEffect(() => {
    const currentIndex = mainNavItems.findIndex(item => item.href === pathname)
    if (currentIndex !== -1) {
      setActiveIndex(currentIndex)
    }
  }, [pathname, mainNavItems])

  // Animate indicator position with smooth spring-like animation
  useEffect(() => {
    if (indicatorRef.current && navRef.current) {
      const navItems = navRef.current.children
      const activeItem = navItems[activeIndex] as HTMLElement
      
      if (activeItem) {
        const navRect = navRef.current.getBoundingClientRect()
        const itemRect = activeItem.getBoundingClientRect()
        
        // Add horizontal spacing (4px on each side, matching top-1 bottom-1 vertical spacing)
        const horizontalSpacing = 4
        
        // Calculate position and width with spacing on all sides (not edge-to-edge)
        const left = itemRect.left - navRect.left + horizontalSpacing
        const width = itemRect.width - (horizontalSpacing * 2)
        
        // Set the background with spacing on all sides
        indicatorRef.current.style.left = `${left}px`
        indicatorRef.current.style.width = `${width}px`
        indicatorRef.current.style.opacity = '1'
        
        // Update styles based on liquid glass setting
        if (settings.liquidGlassEnabled) {
          indicatorRef.current.style.backgroundColor = 'rgba(52, 211, 153, 0.2)'
          indicatorRef.current.style.WebkitBackdropFilter = "blur(8px) saturate(200%) brightness(1.05)"
          indicatorRef.current.style.backdropFilter = "blur(8px) saturate(200%) brightness(1.05)"
          indicatorRef.current.style.boxShadow = 'inset 0 1px 2px rgba(255, 255, 255, 0.5)'
        } else {
          indicatorRef.current.style.backgroundColor = 'rgba(16, 185, 129, 0.15)'
          indicatorRef.current.style.WebkitBackdropFilter = ''
          indicatorRef.current.style.backdropFilter = ''
          indicatorRef.current.style.boxShadow = 'none'
        }
        
        // Force a reflow to ensure the positioning is applied
        indicatorRef.current.offsetHeight
      }
    }
  }, [activeIndex, settings.liquidGlassEnabled])

  const handleNavClick = (index: number) => {
    setActiveIndex(index)
  }

  return (
    <div className="lg:hidden fixed bottom-4 left-4 right-4 z-50 max-w-md mx-auto">
      {/* Liquid Glass Navbar Container - Multi-layer for authentic iOS effect */}
      <div 
        className="relative rounded-full overflow-hidden"
        style={{
          // Very subtle outer shadow for depth
          boxShadow: '0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)',
        }}
      >
        {/* Base glass layer - highly transparent with minimal blur */}
        <div
          className={cn(
            "absolute inset-0 rounded-full",
            // Very transparent background - iOS liquid glass is almost see-through
            settings.liquidGlassEnabled
              ? "bg-white/10 dark:bg-black/8"
              : "bg-background dark:bg-background"
          )}
          style={{
            ...(settings.liquidGlassEnabled
              ? {
                  WebkitBackdropFilter: "blur(12px) saturate(180%)",
                  backdropFilter: "blur(12px) saturate(180%)",
                }
              : {}),
          }}
        />
        
        {/* Secondary blur layer for very subtle depth */}
        {settings.liquidGlassEnabled && (
          <div
            className={cn(
              "absolute inset-0 rounded-full",
              "bg-white/3 dark:bg-white/2",
            )}
            style={{
              WebkitBackdropFilter: "blur(6px) saturate(200%)",
              backdropFilter: "blur(6px) saturate(200%)",
            }}
          />
        )}
        
        {/* Main container with content */}
        <div 
          className={cn(
            "relative rounded-full",
            // Ultra-subtle border - almost invisible
            "border border-white/15 dark:border-white/5",
            // Padding for the container - reduced to match original height
            "py-1 px-0"
          )}
        >
          {/* Animated active indicator with liquid glass effect */}
          <div
            ref={indicatorRef}
            className={cn(
              "absolute top-1 bottom-1 rounded-full transition-all duration-500 ease-out opacity-0",
            )}
            style={{
              willChange: 'left, width, opacity',
              transition: "left 0.5s cubic-bezier(0.34, 1.56, 0.64, 1), width 0.5s cubic-bezier(0.34, 1.56, 0.64, 1), opacity 0.4s ease-out"
            }}
          />
          
          {/* Navigation items container */}
          <div ref={navRef} className="relative flex items-center justify-evenly py-0 px-0">
            {mainNavItems.map((item, index) => {
              const isActive = activeIndex === index && !item.isAction
              const Icon = item.icon
              
              // Handle action items (like Sign Out) differently
              if (item.isAction && item.onClick) {
                return (
                  <button
                    key={`${item.label}-${index}`}
                    onClick={() => {
                      handleNavClick(index)
                      item.onClick?.()
                    }}
                    className={cn(
                      "relative flex flex-col items-center justify-center",
                      "px-0 py-2 rounded-full",
                      "transition-all flex-1 min-w-0",
                      "hover:scale-105 active:scale-95",
                      "focus:outline-none",
                      // Sign Out uses red color
                      "text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300"
                    )}
                    style={{
                      transition: "transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), color 0.3s ease"
                    }}
                  >
                    {/* Icon with enhanced animation */}
                    <Icon 
                      className="h-5 w-5 mb-1 scale-100"
                      style={{
                        transition: "transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)"
                      }}
                    />
                    {/* Label with smooth transitions */}
                    <span 
                      className="text-xs font-medium whitespace-nowrap"
                      style={{
                        transition: "all 0.3s ease"
                      }}
                    >
                      {item.shortLabel}
                    </span>
                  </button>
                )
              }
              
              // Regular navigation links
              return (
                <Link
                  key={item.href || `${item.label}-${index}`}
                  href={item.href || "#"}
                  onClick={() => handleNavClick(index)}
                  className={cn(
                    "relative flex flex-col items-center justify-center",
                    "px-0 py-2 rounded-full",
                    "transition-all flex-1 min-w-0",
                    "hover:scale-105 active:scale-95",
                    "focus:outline-none",
                    // Text color with better contrast for glass effect
                    isActive 
                      ? "text-emerald-600 dark:text-emerald-200" 
                      : "text-gray-800 dark:text-gray-200 hover:text-emerald-600 dark:hover:text-emerald-300"
                  )}
                  style={{
                    transition: "transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), color 0.3s ease"
                  }}
                >
                  {/* Icon with enhanced animation */}
                  <Icon 
                    className={cn(
                      "h-5 w-5 mb-1",
                      isActive 
                        ? "scale-110" 
                        : "scale-100"
                    )}
                    style={{
                      transition: "transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)"
                    }}
                  />
                  {/* Label with smooth transitions */}
                  <span 
                    className={cn(
                      "text-xs font-medium whitespace-nowrap",
                      isActive 
                        ? "font-semibold" 
                        : "font-medium"
                    )}
                    style={{
                      transition: "all 0.3s ease",
                      textShadow: isActive ? '0 1px 2px rgba(255, 255, 255, 0.5)' : 'none'
                    }}
                  >
                    {item.shortLabel}
                  </span>
                </Link>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}