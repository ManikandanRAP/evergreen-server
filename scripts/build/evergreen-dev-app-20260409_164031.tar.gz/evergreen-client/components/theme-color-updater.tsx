"use client"

import { useEffect } from "react"
import { useTheme } from "next-themes"
import { useSettings } from "@/lib/settings-context"

export function ThemeColorUpdater() {
  const { theme, resolvedTheme, setTheme } = useTheme()
  const { settings } = useSettings()

  // Sync theme mode from user settings when settings load from server
  useEffect(() => {
    // Only sync if we have a valid themeMode from settings
    // and it differs from the current next-themes value
    if (settings.themeMode && settings.themeMode !== theme) {
      console.log("Syncing theme from settings:", settings.themeMode)
      setTheme(settings.themeMode)
    }
  }, [settings.themeMode, setTheme]) // Don't include `theme` to avoid loops

  useEffect(() => {
    // Use resolvedTheme to get the actual theme (handles system theme)
    const currentTheme = resolvedTheme || theme
    
    // Get the theme color based on current theme
    // Light mode: white background, dark mode: very dark background
    const themeColor = currentTheme === "dark" ? "#0a0a0a" : "#ffffff"
    
    // Find or create the theme-color meta tag
    let metaThemeColor = document.querySelector('meta[name="theme-color"]')
    
    if (!metaThemeColor) {
      metaThemeColor = document.createElement("meta")
      metaThemeColor.setAttribute("name", "theme-color")
      document.head.appendChild(metaThemeColor)
    }
    
    metaThemeColor.setAttribute("content", themeColor)
    
    // Chrome on Android - also update the manifest link's theme-color dynamically
    // This helps when the page is loaded as a PWA
    const manifestLink = document.querySelector('link[rel="manifest"]') as HTMLLinkElement
    if (manifestLink) {
      // Force manifest reload by adding a timestamp (Chrome caches manifests)
      const manifestUrl = manifestLink.href.split('?')[0]
      manifestLink.href = `${manifestUrl}?v=${Date.now()}`
    }
    
    // Update color-scheme meta tag for better Chrome support
    let metaColorScheme = document.querySelector('meta[name="color-scheme"]')
    if (!metaColorScheme) {
      metaColorScheme = document.createElement("meta")
      metaColorScheme.setAttribute("name", "color-scheme")
      document.head.appendChild(metaColorScheme)
    }
    metaColorScheme.setAttribute("content", currentTheme === "dark" ? "dark" : "light")
    
    // Also update the status bar style for Android
    // This helps with contrast - dark theme uses dark content, light theme uses light content
    let metaStatusBar = document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]')
    if (!metaStatusBar) {
      metaStatusBar = document.createElement("meta")
      metaStatusBar.setAttribute("name", "apple-mobile-web-app-status-bar-style")
      document.head.appendChild(metaStatusBar)
    }
    metaStatusBar.setAttribute("content", currentTheme === "dark" ? "black-translucent" : "default")
    
    // For Chrome on Android, also try to update the document's theme via CSS
    // This ensures the browser UI reflects the theme
    if (typeof document !== 'undefined') {
      document.documentElement.style.colorScheme = currentTheme === "dark" ? "dark" : "light"
    }
  }, [theme, resolvedTheme])

  return null
}

