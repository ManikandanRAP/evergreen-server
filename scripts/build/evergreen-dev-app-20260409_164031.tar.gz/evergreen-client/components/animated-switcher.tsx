"use client"

import { useEffect, useRef } from "react"
import { cn } from "@/lib/utils"
import { useSettings } from "@/lib/settings-context"

interface AnimatedSwitcherProps {
  activeIndex: number
  onIndexChange: (index: number) => void
  options: { value: string; label: string; icon?: React.ComponentType<{ className?: string }> }[]
  className?: string
}

export default function AnimatedSwitcher({ 
  activeIndex, 
  onIndexChange, 
  options,
  className 
}: AnimatedSwitcherProps) {
  const { settings } = useSettings()
  const indicatorRef = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const updateIndicator = () => {
      if (indicatorRef.current && containerRef.current) {
        // Get only button elements, skipping the indicator (first child)
        const buttons = Array.from(containerRef.current.children).filter(
          (child) => child.tagName === 'BUTTON'
        ) as HTMLElement[]
        const activeItem = buttons[activeIndex]
        
        if (activeItem) {
          const containerRect = containerRef.current.getBoundingClientRect()
          const itemRect = activeItem.getBoundingClientRect()
          
          // Calculate position and width to cover the full element including padding
          const left = itemRect.left - containerRect.left
          const width = itemRect.width
          
          // Set the background to cover the full element
          indicatorRef.current.style.left = `${left}px`
          indicatorRef.current.style.width = `${width}px`
          indicatorRef.current.style.opacity = '1'
          indicatorRef.current.style.position = 'absolute'
          indicatorRef.current.style.top = '4px'
          indicatorRef.current.style.bottom = '4px'
          indicatorRef.current.style.borderRadius = '9999px'
          
          // Set the background with iOS 26 liquid glass effect
          // Use emerald for both states to match iOS 26 theme
          if (settings.liquidGlassEnabled) {
            indicatorRef.current.style.backgroundColor = 'rgba(52, 211, 153, 0.2)' // emerald-400 with opacity for glass effect
            indicatorRef.current.style.WebkitBackdropFilter = 'blur(8px) saturate(200%) brightness(1.05)'
            indicatorRef.current.style.backdropFilter = 'blur(8px) saturate(200%) brightness(1.05)'
            indicatorRef.current.style.boxShadow = 'inset 0 1px 2px rgba(255, 255, 255, 0.5), 0 2px 8px rgba(16, 185, 129, 0.15)'
          } else {
            indicatorRef.current.style.backgroundColor = 'rgba(16, 185, 129, 0.15)' // emerald-500 with opacity for solid background
            indicatorRef.current.style.WebkitBackdropFilter = ''
            indicatorRef.current.style.backdropFilter = ''
            indicatorRef.current.style.boxShadow = 'none'
          }
          
          // Force a reflow to ensure the positioning is applied
          indicatorRef.current.offsetHeight
        }
      }
    }

    // Small delay to ensure DOM is ready
    const timeoutId = setTimeout(updateIndicator, 10)
    
    return () => clearTimeout(timeoutId)
  }, [activeIndex, settings.liquidGlassEnabled])

  return (
    <div className={cn("relative", className)}>
      {/* Switcher container with iOS 26 liquid glass effect */}
      <div 
        ref={containerRef}
        className={cn(
          "relative flex items-center border rounded-full p-1 overflow-hidden",
          settings.liquidGlassEnabled
            ? "bg-white/10 dark:bg-black/8 border-white/15 dark:border-white/5"
            : "bg-background dark:bg-background border-border"
        )}
        style={{
          ...(settings.liquidGlassEnabled
            ? {
                WebkitBackdropFilter: 'blur(12px) saturate(180%)',
                backdropFilter: 'blur(12px) saturate(180%)',
                boxShadow: '0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)'
              }
            : {
                boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'
              })
        }}
      >
        {/* Animated background indicator - inside container so it's a sibling to buttons */}
        <div
          ref={indicatorRef}
          className="absolute inset-y-[4px] rounded-full transition-all duration-300 ease-out opacity-0 z-0"
          style={{
            willChange: 'left, width, opacity'
          }}
        />
        
        {options.map((option, index) => {
          const isActive = activeIndex === index
          const Icon = option.icon
          
          return (
            <button
              key={option.value}
              onClick={() => onIndexChange(index)}
              className={cn(
                "relative flex items-center justify-center h-8 px-3 rounded-full transition-all duration-200 ease-out z-10",
                isActive 
                  ? "text-emerald-600 dark:text-emerald-200 font-semibold" 
                  : "text-gray-800 dark:text-gray-200 hover:text-emerald-600 dark:hover:text-emerald-300"
              )}
            >
              {Icon && (
                <Icon 
                  className={cn(
                    "h-4 w-4",
                    isActive && "drop-shadow-sm"
                  )} 
                />
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}
