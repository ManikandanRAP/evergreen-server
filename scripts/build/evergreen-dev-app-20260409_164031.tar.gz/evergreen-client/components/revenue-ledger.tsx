"use client"

import React, { useEffect, useMemo, useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { useSettings, type UserSettings } from "@/lib/settings-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DollarSign,
  TrendingUp,
  CreditCard,
  Filter,
  ChevronDown,
  ChevronUp,
  ArrowUpDown,
  Loader2,
  LogIn,
  ChevronLeft,
  ChevronRight,
  ChevronsUpDown,
  Check,
  RotateCcw,
  Download,
  Radio,
  Users,
  X,
  Minimize2,
  LayoutGrid,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

type SortDirection = "asc" | "desc" | null
type SortConfig = { key: string; direction: SortDirection }

type LedgerItem = {
  show_name: string
  customer: string
  invoice_date: string | null
  invoice_description: string
  invoice_amount: number | null
  invoice_doc_number: string | null
  evergreen_percentage: number | null
  partner_percentage: number | null
  evergreen_compensation: number | null
  partner_compensation: number | null
  effective_payment_received: number | null
  outstanding_balance: number | null
  partner_comp_waiting: number | null
  evergreen_outstanding: number | null
  partner_outstanding: number | null
}

type PartnerPayout = {
  bill_number: string | null
  bill_date: string
  bill_description: string | null
  bill_amount: number | null
  payment_id: string | null
  date_of_payment: string | null
  effective_billed_amount_paid: number | null
  billed_amount_outstanding: number | null
  show_name: string
  partner_name?: string | null
  vendor_qbo_name?: string | null
}

// Helper function to get API URL (checks localStorage override for runtime config)
function getApiUrl(): string {
  if (typeof window !== 'undefined') {
    // Check for runtime override in localStorage (useful for mobile testing)
    const override = localStorage.getItem('api_url_override')
    if (override) {
      return override
    }
  }
  return process.env.NEXT_PUBLIC_API_URL || "/api"
}

const PAGE_SIZE_OPTIONS = [5, 10, 12, 15, 20, 25, 50, 100]

export default function RevenueLedger() {
  const { token, isLoading, user } = useAuth()
  const { getPageSize, getTableDensityClass, settings, updateSettings } = useSettings()
  const REVENUE_PAGE_SIZE = useMemo(() => getPageSize("revenueLedger") || 10, [getPageSize])
  const PAYMENTS_PAGE_SIZE = useMemo(() => getPageSize("partnerPayments") || 10, [getPageSize])
  
  // Determine user role for column visibility
  const isPartner = user?.role === "partner"
  const isAdminOrInternal = user?.role === "admin" || user?.role === "internal_full_access" || user?.role === "internal_show_access"
  
  // Calculate number of visible columns for revenue table
  // Show Name, Invoice Number, Invoice Date, Invoice Amount, Payments Received, Evergreen Split, Partner Split, Description
  const revenueColumnCount = useMemo(() => {
    let count = 4 // Show Name, Invoice Number, Invoice Date, Invoice Amount, Description (always visible)
    if (!isAdminOrInternal) count++ // Payments Received
    if (!isPartner) count++ // Evergreen Split
    if (!isPartner) count++ // Partner Split
    count++ // Description
    return count
  }, [isPartner, isAdminOrInternal])
  
  // Calculate minimum table width based on visible columns
  const revenueTableMinWidth = useMemo(() => {
    let width = 200 + 120 + 100 + 130 + 500 // Show Name, Invoice Number, Invoice Date, Invoice Amount, Description (always visible)
    if (!isAdminOrInternal) width += 120 // Payments Received
    if (!isPartner) width += 120 // Evergreen Split
    if (!isPartner) width += 120 // Partner Split
    return width
  }, [isPartner, isAdminOrInternal])

  const [selectedShow, setSelectedShow] = useState<string>("all")
  const [dateFrom, setDateFrom] = useState<string>("")
  const [dateTo, setDateTo] = useState<string>("")
  const [isFiltersOpen, setIsFiltersOpen] = useState(false)
  const [isSlideOutOpen, setIsSlideOutOpen] = useState(false)
  const [isSlideOutAnimating, setIsSlideOutAnimating] = useState(false)
  // Initialize isDark synchronously to prevent flicker
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      return document.documentElement.classList.contains('dark')
    }
    return false
  })

  // Check theme for glass morphism effect
  useEffect(() => {
    const checkTheme = () => {
      setIsDark(document.documentElement.classList.contains('dark'))
    }
    // Only update if different to avoid unnecessary re-renders
    const currentIsDark = document.documentElement.classList.contains('dark')
    if (currentIsDark !== isDark) {
      setIsDark(currentIsDark)
    }
    
    const observer = new MutationObserver(checkTheme)
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    })
    
    return () => observer.disconnect()
  }, [isDark])

  // Handle slide-out open/close with animation
  useEffect(() => {
    if (isSlideOutOpen) {
      setIsSlideOutAnimating(true)
      document.body.style.overflow = 'hidden'
    } else if (isSlideOutAnimating) {
      // Keep in DOM during closing animation, then remove after animation completes
      const timer = setTimeout(() => {
        setIsSlideOutAnimating(false)
        document.body.style.overflow = 'unset'
      }, 300) // Match animation duration
      return () => clearTimeout(timer)
    }
    
    // Cleanup on unmount
    return () => {
      document.body.style.overflow = 'unset'
    }
  }, [isSlideOutOpen, isSlideOutAnimating])

  // Handle escape key to close filter panel
  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isSlideOutOpen) {
        setIsSlideOutOpen(false)
      }
    }

    if (isSlideOutOpen) {
      document.addEventListener('keydown', handleEscape)
    }

    return () => {
      document.removeEventListener('keydown', handleEscape)
    }
  }, [isSlideOutOpen])

  const [ledger, setLedger] = useState<LedgerItem[]>([])
  const [payouts, setPayouts] = useState<PartnerPayout[]>([])
  // Removed static stats state - now calculated from filtered data
  const [fetching, setFetching] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)

  const [revenueReceivedSortConfig, setRevenueReceivedSortConfig] = useState<SortConfig>({ key: "", direction: null })
  const [revenueAwaitingSortConfig, setRevenueAwaitingSortConfig] = useState<SortConfig>({ key: "", direction: null })
  const [paymentsSortConfig, setPaymentsSortConfig] = useState<SortConfig>({ key: "", direction: null })

  // Pagination
  const [revenueReceivedPage, setRevenueReceivedPage] = useState<number>(1)
  const [revenueAwaitingPage, setRevenueAwaitingPage] = useState<number>(1)
  const [paymentsPage, setPaymentsPage] = useState<number>(1)
  const [revenueReceivedPageInput, setRevenueReceivedPageInput] = useState<string>("1")
  const [revenueAwaitingPageInput, setRevenueAwaitingPageInput] = useState<string>("1")
  const [paymentsPageInput, setPaymentsPageInput] = useState<string>("1")

  const handleClearFilters = () => {
    setSelectedShow("all")
    setDateFrom("")
    setDateTo("")
  }

  const currentDensity = settings.tableDensity.revenueLedger || "default"
  
  const handleDensityChange = (value: "compact" | "default") => {
    updateSettings({
      tableDensity: {
        ...settings.tableDensity,
        revenueLedger: value,
      },
    })
  }

  // unified fetch for initial load + refresh
  const fetchData = async () => {
    if (!token) {
      setLedger([])
      setPayouts([])
      return
    }
    setFetching(true)
    setError(null)
    try {
      const headers: HeadersInit = { "Content-Type": "application/json", Authorization: `Bearer ${token}` }
      const base = getApiUrl().replace(/\/$/, "")
      const [ledgerRes, payoutRes] = await Promise.all([
        fetch(`${base}/ledger`, { headers }),
        fetch(`${base}/partner_payouts`, { headers }),
      ])
      if (!ledgerRes.ok) throw new Error(await readErr(ledgerRes, "Ledger request failed"))
      if (!payoutRes.ok) throw new Error(await readErr(payoutRes, "Partner payouts request failed"))

      const ledgerJson: LedgerItem[] = await ledgerRes.json()
      const payoutsJson: PartnerPayout[] = await payoutRes.json()
      
      // Debug: Check if new fields are present
      if (ledgerJson && ledgerJson.length > 0) {
        const sample = ledgerJson[0]
        console.log('Sample ledger item keys:', Object.keys(sample))
        console.log('evergreen_outstanding:', sample.evergreen_outstanding, typeof sample.evergreen_outstanding)
        console.log('partner_outstanding:', sample.partner_outstanding, typeof sample.partner_outstanding)
      }
      
      setLedger(Array.isArray(ledgerJson) ? ledgerJson : [])
      setPayouts(Array.isArray(payoutsJson) ? payoutsJson : [])
    } catch (e: any) {
      setError(e?.message || "Failed to load ledger data")
    } finally {
      setFetching(false)
    }
  }

  const onRefresh = async () => {
    await fetchData()
  }

  useEffect(() => {
    if (isLoading) return
    if (!token) {
      setLedger([])
      setPayouts([])
      return
    }
    fetchData()
  }, [isLoading, token])

  const availableShows = useMemo(() => {
    const set = new Set<string>()
    for (const r of ledger) if (r.show_name) set.add(r.show_name)
    for (const p of payouts) if (p.show_name) set.add(p.show_name)
    return Array.from(set).sort((a, b) => a.localeCompare(b))
  }, [ledger, payouts])

  const filteredRevenueData = useMemo(() => {
    let filtered = ledger
    if (selectedShow !== "all") filtered = filtered.filter((i) => i.show_name === selectedShow)
    if (dateFrom || dateTo) {
      filtered = filtered.filter((i) => {
        const d = toDate(i.invoice_date)
        const from = dateFrom ? toDate(dateFrom) : new Date("1900-01-01")
        const to = dateTo ? toDate(dateTo, true) : new Date("2100-12-31")
        return d >= from && d <= to
      })
    }
    return filtered
  }, [ledger, selectedShow, dateFrom, dateTo])

  const filteredPartnerPayments = useMemo(() => {
    let filtered = payouts
    if (selectedShow !== "all") filtered = filtered.filter((i) => i.show_name === selectedShow)
    if (dateFrom || dateTo) {
      filtered = filtered.filter((i) => {
        const bill = toDate(i.bill_date)
        const pay = i.date_of_payment ? toDate(i.date_of_payment) : null
        const from = dateFrom ? toDate(dateFrom) : new Date("1900-01-01")
        const to = dateTo ? toDate(dateTo, true) : new Date("2100-12-31")
        const billIn = bill >= from && bill <= to
        const payIn = pay ? pay >= from && pay <= to : false
        return billIn || payIn
      })
    }
    return filtered
  }, [payouts, selectedShow, dateFrom, dateTo])

  useEffect(() => {
    setRevenueReceivedPage(1)
    setRevenueAwaitingPage(1)
  }, [selectedShow, dateFrom, dateTo, ledger])
  useEffect(() => setPaymentsPage(1), [selectedShow, dateFrom, dateTo, payouts])
  // Reset to page 1 when page size changes
  useEffect(() => {
    setRevenueReceivedPage(1)
    setRevenueAwaitingPage(1)
  }, [REVENUE_PAGE_SIZE])
  useEffect(() => setPaymentsPage(1), [PAYMENTS_PAGE_SIZE])

  const sortData = <T extends Record<string, any>>(data: T[], cfg: SortConfig): T[] => {
    if (!cfg.direction || !cfg.key) return data
    return [...data].sort((a, b) => {
      // Handle partner_name fallback to vendor_qbo_name
      let av = a[cfg.key]
      let bv = b[cfg.key]
      if (cfg.key === "partner_name") {
        av = av || a.vendor_qbo_name
        bv = bv || b.vendor_qbo_name
      }
      
      if (av == null && bv == null) return 0
      if (av == null) return cfg.direction === "asc" ? -1 : 1
      if (bv == null) return cfg.direction === "asc" ? 1 : -1

      const isDate =
        typeof av === "string" && /^\d{4}-\d{2}-\d{2}/.test(av) &&
        typeof bv === "string" && /^\d{4}-\d{2}-\d{2}/.test(bv)

      let cmp = 0
      if (typeof av === "number" && typeof bv === "number") cmp = av - bv
      else if (isDate) cmp = toDate(av).getTime() - toDate(bv).getTime()
      else if (typeof av === "string" && typeof bv === "string") cmp = av.localeCompare(bv)
      else cmp = String(av).localeCompare(String(bv))
      return cfg.direction === "asc" ? cmp : -cmp
    })
  }

  // Split revenue data into received and awaiting payments
  // Awaiting: outstanding_balance > 0
  // Received: outstanding_balance = 0 (or null/zero)
  const receivedPaymentsData = useMemo(() => {
    return filteredRevenueData.filter((item) => num(item.outstanding_balance) === 0)
  }, [filteredRevenueData])

  const awaitingPaymentsData = useMemo(() => {
    return filteredRevenueData.filter((item) => num(item.outstanding_balance) > 0)
  }, [filteredRevenueData])

  const handleSort = (key: string, tableType: "received" | "awaiting" | "payments") => {
    let cfg: SortConfig
    let setCfg: (cfg: SortConfig) => void
    
    if (tableType === "received") {
      cfg = revenueReceivedSortConfig
      setCfg = setRevenueReceivedSortConfig
    } else if (tableType === "awaiting") {
      cfg = revenueAwaitingSortConfig
      setCfg = setRevenueAwaitingSortConfig
    } else {
      cfg = paymentsSortConfig
      setCfg = setPaymentsSortConfig
    }
    
    let dir: SortDirection = "asc"
    if (cfg.key === key) dir = cfg.direction === "asc" ? "desc" : cfg.direction === "desc" ? null : "asc"
    setCfg({ key: dir ? key : "", direction: dir })
  }

  const sortedReceivedPaymentsData = useMemo(() => sortData(receivedPaymentsData, revenueReceivedSortConfig), [receivedPaymentsData, revenueReceivedSortConfig])
  const sortedAwaitingPaymentsData = useMemo(() => sortData(awaitingPaymentsData, revenueAwaitingSortConfig), [awaitingPaymentsData, revenueAwaitingSortConfig])
  const sortedPartnerPayments = useMemo(() => sortData(filteredPartnerPayments, paymentsSortConfig), [filteredPartnerPayments, paymentsSortConfig])

  useEffect(() => setRevenueReceivedPage(1), [revenueReceivedSortConfig])
  useEffect(() => setRevenueAwaitingPage(1), [revenueAwaitingSortConfig])
  useEffect(() => setPaymentsPage(1), [paymentsSortConfig])

  const receivedPaymentsTotal = sortedReceivedPaymentsData.length
  const receivedPaymentsTotalPages = useMemo(() => Math.max(1, Math.ceil(receivedPaymentsTotal / REVENUE_PAGE_SIZE)), [receivedPaymentsTotal, REVENUE_PAGE_SIZE])
  const receivedPaymentsPageSafe = useMemo(() => Math.min(Math.max(1, revenueReceivedPage), receivedPaymentsTotalPages), [revenueReceivedPage, receivedPaymentsTotalPages])
  const receivedPaymentsSlice = useMemo(() => {
    const start = (receivedPaymentsPageSafe - 1) * REVENUE_PAGE_SIZE
    return sortedReceivedPaymentsData.slice(start, start + REVENUE_PAGE_SIZE)
  }, [sortedReceivedPaymentsData, receivedPaymentsPageSafe, REVENUE_PAGE_SIZE])

  const awaitingPaymentsTotal = sortedAwaitingPaymentsData.length
  const awaitingPaymentsTotalPages = useMemo(() => Math.max(1, Math.ceil(awaitingPaymentsTotal / REVENUE_PAGE_SIZE)), [awaitingPaymentsTotal, REVENUE_PAGE_SIZE])
  const awaitingPaymentsPageSafe = useMemo(() => Math.min(Math.max(1, revenueAwaitingPage), awaitingPaymentsTotalPages), [revenueAwaitingPage, awaitingPaymentsTotalPages])
  const awaitingPaymentsSlice = useMemo(() => {
    const start = (awaitingPaymentsPageSafe - 1) * REVENUE_PAGE_SIZE
    return sortedAwaitingPaymentsData.slice(start, start + REVENUE_PAGE_SIZE)
  }, [sortedAwaitingPaymentsData, awaitingPaymentsPageSafe, REVENUE_PAGE_SIZE])

  const paymentsTotal = sortedPartnerPayments.length
  const paymentsTotalPages = useMemo(() => Math.max(1, Math.ceil(paymentsTotal / PAYMENTS_PAGE_SIZE)), [paymentsTotal, PAYMENTS_PAGE_SIZE])
  const paymentsPageSafe = useMemo(() => Math.min(Math.max(1, paymentsPage), paymentsTotalPages), [paymentsPage, paymentsTotalPages])
  const paymentsSlice = useMemo(() => {
    const start = (paymentsPageSafe - 1) * PAYMENTS_PAGE_SIZE
    return sortedPartnerPayments.slice(start, start + PAYMENTS_PAGE_SIZE)
  }, [sortedPartnerPayments, paymentsPageSafe, PAYMENTS_PAGE_SIZE])

  useEffect(() => setRevenueReceivedPageInput(String(receivedPaymentsPageSafe)), [receivedPaymentsPageSafe])
  useEffect(() => setRevenueAwaitingPageInput(String(awaitingPaymentsPageSafe)), [awaitingPaymentsPageSafe])
  useEffect(() => setPaymentsPageInput(String(paymentsPageSafe)), [paymentsPageSafe])

  const summaryData = useMemo(() => {
    const totalNetRevenue = filteredRevenueData.reduce((s, i) => s + num(i.effective_payment_received), 0)
    const totalPartnerCompensation = filteredRevenueData.reduce((s, i) => s + num(i.partner_compensation), 0)
    const seen = new Set<string>()
    const totalPaymentsMade = filteredPartnerPayments.reduce((s, i) => {
      if (i.payment_id && !seen.has(i.payment_id)) {
        seen.add(i.payment_id)
        return s + num(i.effective_billed_amount_paid)
      }
      return s
    }, 0)
    return { totalNetRevenue, totalPartnerCompensation, totalPaymentsMade }
  }, [filteredRevenueData, filteredPartnerPayments])

  // Calculate totals for received payments table
  const receivedPaymentsTotals = useMemo(() => {
    return {
      invoice_amount: receivedPaymentsData.reduce((sum, item) => sum + num(item.invoice_amount), 0),
      evergreen_compensation: receivedPaymentsData.reduce((sum, item) => sum + num(item.evergreen_compensation), 0),
      partner_compensation: receivedPaymentsData.reduce((sum, item) => sum + num(item.partner_compensation), 0),
      effective_payment_received: receivedPaymentsData.reduce((sum, item) => sum + num(item.effective_payment_received), 0),
      outstanding_balance: receivedPaymentsData.reduce((sum, item) => sum + num(item.outstanding_balance), 0),
      partner_comp_waiting: receivedPaymentsData.reduce((sum, item) => sum + num(item.partner_comp_waiting), 0),
    }
  }, [receivedPaymentsData])

  // Calculate totals for awaiting payments table
  const awaitingPaymentsTotals = useMemo(() => {
    return {
      invoice_amount: awaitingPaymentsData.reduce((sum, item) => sum + num(item.invoice_amount), 0),
      evergreen_compensation: awaitingPaymentsData.reduce((sum, item) => sum + num(item.evergreen_compensation), 0),
      partner_compensation: awaitingPaymentsData.reduce((sum, item) => sum + num(item.partner_compensation), 0),
      effective_payment_received: awaitingPaymentsData.reduce((sum, item) => sum + num(item.effective_payment_received), 0),
      outstanding_balance: awaitingPaymentsData.reduce((sum, item) => sum + num(item.outstanding_balance), 0),
      partner_comp_waiting: awaitingPaymentsData.reduce((sum, item) => sum + num(item.partner_comp_waiting), 0),
      evergreen_outstanding: awaitingPaymentsData.reduce((sum, item) => sum + num(item.evergreen_outstanding), 0),
      partner_outstanding: awaitingPaymentsData.reduce((sum, item) => sum + num(item.partner_outstanding), 0),
    }
  }, [awaitingPaymentsData])

  // Calculate totals for partner payments table
  const paymentsTotals = useMemo(() => {
    // Bill payments done - Evergreen Paid, Partner Paid
    const billPaymentsDone = filteredPartnerPayments
      .filter((item) => item.payment_id) // Only paid bills
      .reduce((sum, item) => sum + num(item.effective_billed_amount_paid), 0)
    
    // Bill Payments Outstanding - Evergreen Paid, Partner Pending
    const billPaymentsOutstanding = filteredPartnerPayments.reduce((sum, item) => 
      sum + num(item.billed_amount_outstanding), 0
    )
    
    return {
      bill_amount: filteredPartnerPayments.reduce((sum, item) => sum + num(item.bill_amount), 0),
      effective_billed_amount_paid: billPaymentsDone,
      billed_amount_outstanding: billPaymentsOutstanding,
    }
  }, [filteredPartnerPayments])

  // Calculate page totals for received payments table
  const receivedPaymentsPageTotals = useMemo(() => {
    return {
      invoice_amount: receivedPaymentsSlice.reduce((sum, item) => sum + num(item.invoice_amount), 0),
      evergreen_compensation: receivedPaymentsSlice.reduce((sum, item) => sum + num(item.evergreen_compensation), 0),
      partner_compensation: receivedPaymentsSlice.reduce((sum, item) => sum + num(item.partner_compensation), 0),
      effective_payment_received: receivedPaymentsSlice.reduce((sum, item) => sum + num(item.effective_payment_received), 0),
      outstanding_balance: receivedPaymentsSlice.reduce((sum, item) => sum + num(item.outstanding_balance), 0),
      partner_comp_waiting: receivedPaymentsSlice.reduce((sum, item) => sum + num(item.partner_comp_waiting), 0),
    }
  }, [receivedPaymentsSlice])

  // Calculate page totals for awaiting payments table
  const awaitingPaymentsPageTotals = useMemo(() => {
    return {
      invoice_amount: awaitingPaymentsSlice.reduce((sum, item) => sum + num(item.invoice_amount), 0),
      evergreen_compensation: awaitingPaymentsSlice.reduce((sum, item) => sum + num(item.evergreen_compensation), 0),
      partner_compensation: awaitingPaymentsSlice.reduce((sum, item) => sum + num(item.partner_compensation), 0),
      effective_payment_received: awaitingPaymentsSlice.reduce((sum, item) => sum + num(item.effective_payment_received), 0),
      outstanding_balance: awaitingPaymentsSlice.reduce((sum, item) => sum + num(item.outstanding_balance), 0),
      partner_comp_waiting: awaitingPaymentsSlice.reduce((sum, item) => sum + num(item.partner_comp_waiting), 0),
      evergreen_outstanding: awaitingPaymentsSlice.reduce((sum, item) => sum + num(item.evergreen_outstanding), 0),
      partner_outstanding: awaitingPaymentsSlice.reduce((sum, item) => sum + num(item.partner_outstanding), 0),
    }
  }, [awaitingPaymentsSlice])

  // Calculate page totals for partner payments table (only visible items on current page)
  const paymentsPageTotals = useMemo(() => {
    return {
      bill_amount: paymentsSlice.reduce((sum, item) => sum + num(item.bill_amount), 0),
      effective_billed_amount_paid: paymentsSlice.filter((item) => item.payment_id).reduce((sum, item) => sum + num(item.effective_billed_amount_paid), 0),
      billed_amount_outstanding: paymentsSlice.reduce((sum, item) => sum + num(item.billed_amount_outstanding), 0),
    }
  }, [paymentsSlice])

  // Calculate filtered stats based on the same logic as the database view
  const filteredStats = useMemo(() => {
    // Completed Partner Payments: Sum of all Bill Payments made for Partners
    // (Considers Bills and Bill payments) - To: Evergreen Paid, Partner Paid
    // Only count bills that have been paid (payment_id is not null)
    const total_effective_billed_paid = filteredPartnerPayments.reduce((sum, payout) => {
      // Only count if payment has been made (payment_id exists)
      if (payout.payment_id) {
        return sum + num(payout.effective_billed_amount_paid)
      }
      return sum
    }, 0)
    
    // Partner Payments to be Included in Next Payout: Sum of Bills raised – Sum of partner payments made
    // (Considers Bills and Bill payments) - To: Evergreen Paid, Partner Pending
    // This is the outstanding amount: Bills raised minus payments made
    const total_billed_outstanding = filteredPartnerPayments.reduce((sum, payout) => 
      sum + num(payout.billed_amount_outstanding), 0
    )
    
    // Pending Invoices from Customers: Partner amount expected (according to the %split) 
    // in: Sum of Invoice amounts awaiting customer payments
    // (Considers Customer Invoices, Payments received and % Split) - To: Evergreen Pending, Partner Pending
    // This is the total partner outstanding from awaiting payments table
    const total_comp_waiting = awaitingPaymentsTotals.partner_outstanding
    
    return {
      total_effective_billed_paid,
      total_billed_outstanding,
      total_comp_waiting
    }
  }, [filteredPartnerPayments, awaitingPaymentsTotals])

  const formatCurrency = (v: number | null | undefined) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(num(v))
  const formatDate = (s: string | null) => (s ? toDate(s).toLocaleDateString() : "-")
  const formatPct = (f: number | null | undefined) => (f == null ? "-" : `${Math.round(num(f) * 100)}%`)
  
  const formatPaymentId = (paymentId: string | null) => {
    if (!paymentId) return "-"
    try {
      const parsed = JSON.parse(paymentId)
      if (parsed.TxnId && Array.isArray(parsed.TxnId)) {
        return parsed.TxnId.join(", ")
      }
      return paymentId
    } catch {
      return paymentId
    }
  }
  
  const formatPaymentDates = (dates: string | null) => {
    if (!dates) return "-"
    try {
      const parsed = JSON.parse(dates)
      if (Array.isArray(parsed)) {
        return parsed.map(date => toDate(date).toLocaleDateString()).join(", ")
      }
      return toDate(dates).toLocaleDateString()
    } catch {
      return toDate(dates).toLocaleDateString()
    }
  }
  const renderSortIcon = (key: string, tableType: "received" | "awaiting" | "payments") => {
    let cfg: SortConfig
    if (tableType === "received") {
      cfg = revenueReceivedSortConfig
    } else if (tableType === "awaiting") {
      cfg = revenueAwaitingSortConfig
    } else {
      cfg = paymentsSortConfig
    }
    if (cfg.key !== key || !cfg.direction) return <ArrowUpDown className="ml-2 h-4 w-4 text-muted-foreground" />
    return cfg.direction === "asc" ? (
      <ChevronUp className="ml-2 h-4 w-4 text-primary" />
    ) : (
      <ChevronDown className="ml-2 h-4 w-4 text-primary" />
    )
  }
  const rangeLabel = (page: number, total: number, entryType?: string, pageSize?: number) => {
    if (total === 0) return "0–0 of 0"
    const size = pageSize || REVENUE_PAGE_SIZE
    const start = (page - 1) * size + 1
    const end = Math.min(page * size, total)
    return entryType ? `Showing ${start}–${end} of ${total} ${entryType}` : `${start}–${end} of ${total}`
  }
  const clamp = (val: number, min: number, max: number) => Math.max(min, Math.min(max, val || 1))
  const tryJumpReceivedPayments = () => setRevenueReceivedPage(clamp(parseInt(revenueReceivedPageInput, 10), 1, receivedPaymentsTotalPages))
  const tryJumpAwaitingPayments = () => setRevenueAwaitingPage(clamp(parseInt(revenueAwaitingPageInput, 10), 1, awaitingPaymentsTotalPages))
  const tryJumpPayments = () => setPaymentsPage(clamp(parseInt(paymentsPageInput, 10), 1, paymentsTotalPages))

  const handleRevenuePageSizeChange = (value: string) => {
    const newPageSize = parseInt(value)
    // If global page size is set, switch to individual settings
    const updates: Partial<UserSettings> = {
      pagination: {
        ...settings.pagination,
        revenueLedger: newPageSize,
      },
    }
    
    // If global page size is active, disable it and use individual settings
    if (settings.globalPageSize !== null) {
      updates.globalPageSize = null
    }
    
    updateSettings(updates)
    // Reset to page 1 when page size changes
    setRevenueReceivedPage(1)
    setRevenueAwaitingPage(1)
  }

  const handlePaymentsPageSizeChange = (value: string) => {
    const newPageSize = parseInt(value)
    // If global page size is set, switch to individual settings
    const updates: Partial<UserSettings> = {
      pagination: {
        ...settings.pagination,
        partnerPayments: newPageSize,
      },
    }
    
    // If global page size is active, disable it and use individual settings
    if (settings.globalPageSize !== null) {
      updates.globalPageSize = null
    }
    
    updateSettings(updates)
    // Reset to page 1 when page size changes
    setPaymentsPage(1)
  }

  // Export to Excel with three sheets
  const exportToExcel = async () => {
    const XLSX = await import("xlsx")

    const receivedPaymentsRows = sortedReceivedPaymentsData.map((i) => ({
      "Show Name": i.show_name,
      "Invoice Number": i.invoice_doc_number || "",
      "Invoice Date": i.invoice_date ? toDate(i.invoice_date).toISOString().slice(0, 10) : "",
      "Invoice Amount": num(i.invoice_amount),
      "Payments Received": num(i.effective_payment_received),
      "Evergreen Split": num(i.evergreen_compensation),
      "Partner Split": num(i.partner_compensation),
      "Description": i.invoice_description,
    }))

    const awaitingPaymentsRows = sortedAwaitingPaymentsData.map((i) => ({
      "Show Name": i.show_name,
      "Invoice Number": i.invoice_doc_number || "",
      "Invoice Date": i.invoice_date ? toDate(i.invoice_date).toISOString().slice(0, 10) : "",
      "Invoice Amount": num(i.invoice_amount),
      "Payments Received": num(i.effective_payment_received),
      "Evergreen Split": num(i.evergreen_outstanding),
      "Partner Split": num(i.partner_outstanding),
      "Description": i.invoice_description,
    }))

    const partnerRows = sortedPartnerPayments.map((i) => ({
      "Show Name": i.show_name,
      "Bill Number": i.bill_number || "",
      "Bill Date": i.bill_date ? toDate(i.bill_date).toISOString().slice(0, 10) : "",
      "Bill Amount": num(i.bill_amount),
      "Paid": num(i.effective_billed_amount_paid),
      "Date of Payment": formatPaymentDates(i.date_of_payment),
      "Outstanding": num(i.billed_amount_outstanding),
      "Partner Name": i.partner_name || i.vendor_qbo_name || "",
      "Description": i.bill_description || "",
    }))

    const receivedPaymentsSheet = XLSX.utils.json_to_sheet(receivedPaymentsRows)
    const awaitingPaymentsSheet = XLSX.utils.json_to_sheet(awaitingPaymentsRows)
    const partnerSheet = XLSX.utils.json_to_sheet(partnerRows)

    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, receivedPaymentsSheet, "Received Payments")
    XLSX.utils.book_append_sheet(wb, awaitingPaymentsSheet, "Awaiting Payments")
    XLSX.utils.book_append_sheet(wb, partnerSheet, "Partner Payments")

    const now = new Date()
    const pad = (n: number) => String(n).padStart(2, "0")
    const fname = `revenue_ledger_${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(
      now.getHours()
    )}${pad(now.getMinutes())}.xlsx`

    XLSX.writeFile(wb, fname)
  }

  if (isLoading) {
    return (
      <div className="p-6 flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Checking authentication…
      </div>
    )
  }
  if (!token) {
    return (
      <div className="p-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <LogIn className="h-5 w-5" />
              Not authenticated
            </CardTitle>
            <CardDescription>Please log in to view the Revenue Ledger.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
        <div className="flex-1">
          <h1 className="text-xl sm:text-3xl font-bold text-primary tracking-tight">
            Revenue Ledger
          </h1>
          <p className="text-sm text-muted-foreground md:text-base">Track revenue transactions and partner payments</p>
        </div>

        {/* Mobile Layout */}
        <div className="flex flex-col gap-4 md:hidden">
          {/* Table Density and Export - Above stats */}
          <div className="flex items-center gap-2">
            <Select value={currentDensity} onValueChange={handleDensityChange}>
              <SelectTrigger className="flex-1">
                {currentDensity === "compact" ? (
                  <Minimize2 className="h-4 w-4 mr-2" />
                ) : (
                  <LayoutGrid className="h-4 w-4 mr-2" />
                )}
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Default</SelectItem>
                <SelectItem value="compact">Compact</SelectItem>
              </SelectContent>
            </Select>
            <Button className="evergreen-button flex-1" onClick={exportToExcel}>
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
          </div>

          {/* Mobile Stats Cards - Option 3 Layout */}
          <div className="space-y-2">
            <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950/60 dark:to-emerald-900/60 border border-emerald-200 dark:border-emerald-700 rounded-lg py-2 px-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-medium text-emerald-700 dark:text-emerald-200">Evergreen Paid, Partner Paid</div>
                  <div className="text-base font-bold text-emerald-600 dark:text-emerald-300">{formatCurrency(filteredStats.total_effective_billed_paid)}</div>
                </div>
                <DollarSign className="h-3 w-3 text-emerald-600 dark:text-emerald-300" />
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/60 dark:to-blue-900/60 border border-blue-200 dark:border-blue-700 rounded-lg py-2 px-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-medium text-blue-700 dark:text-blue-200">Evergreen Paid, Partner Pending</div>
                  <div className="text-base font-bold text-blue-600 dark:text-blue-300">{formatCurrency(filteredStats.total_billed_outstanding)}</div>
                </div>
                <TrendingUp className="h-3 w-3 text-blue-600 dark:text-blue-300" />
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950/60 dark:to-red-900/60 border border-red-200 dark:border-red-700 rounded-lg py-2 px-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-medium text-red-700 dark:text-red-200">Evergreen Pending, Partner Pending</div>
                  <div className="text-base font-bold text-red-600 dark:text-red-300">{formatCurrency(filteredStats.total_comp_waiting)}</div>
                </div>
                <CreditCard className="h-3 w-3 text-red-600 dark:text-red-300" />
              </div>
            </div>
          </div>

          {/* Stats Pills - Full width on mobile */}
          <div className="flex items-center gap-2 w-full">
            <Card className="flex-1 flex flex-col justify-center">
              <div className="px-3 py-2 space-y-1 text-center">
                <div className="text-base font-bold">{filteredPartnerPayments.length}</div>
                <div className="text-xs leading-tight">Partner<br />Payments</div>
              </div>
            </Card>
            <Card className="flex-1 flex flex-col justify-center">
              <div className="px-3 py-2 space-y-1 text-center">
                <div className="text-base font-bold">{awaitingPaymentsData.length}</div>
                <div className="text-xs leading-tight">Awaiting<br />Payments</div>
              </div>
            </Card>
            <Card className="flex-1 flex flex-col justify-center">
              <div className="px-3 py-2 space-y-1 text-center">
                <div className="text-base font-bold">{receivedPaymentsData.length}</div>
                <div className="text-xs leading-tight">Received<br />Payments</div>
              </div>
            </Card>
          </div>

          {/* Filters and Clear Filters - Same line on mobile, 50/50 when both visible */}
          <div className="flex items-center">
            {/* Filter Button - 50% when clear filters is visible, 100% when not */}
            <Button 
              variant="outline" 
              onClick={() => setIsSlideOutOpen(true)}
              className={`flex items-center gap-2 ${(selectedShow !== "all" || dateFrom || dateTo) ? 'w-1/2 mr-2' : 'w-full'}`}
            >
              <Filter className="h-4 w-4" />
              Filters
            </Button>

            {/* Clear Filters Button - Only show when filters are applied, 50% width */}
            <div className={`transition-all duration-300 ease-in-out ${(selectedShow !== "all" || dateFrom || dateTo) ? 'w-1/2 opacity-100 p-0.5' : 'w-0 opacity-0 overflow-hidden'}`}>
              <Button 
                variant="outline" 
                onClick={handleClearFilters}
                className="action-button-delete w-full"
              >
                <RotateCcw className="h-4 w-4" />
                Clear Filters
              </Button>
            </div>
          </div>
        </div>

        {/* Desktop Layout */}
        <div className="hidden md:flex items-center gap-2">
          {/* Stats Pills */}
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="px-3 py-1">
              {filteredPartnerPayments.length} Partner Payments
            </Badge>
            <Badge variant="secondary" className="px-3 py-1">
              {awaitingPaymentsData.length} Awaiting Payments
            </Badge>
            <Badge variant="secondary" className="px-3 py-1">
              {receivedPaymentsData.length} Received Payments
            </Badge>
          </div>

          {/* Filter Button */}
          <Button 
            variant="outline" 
            onClick={() => setIsSlideOutOpen(true)}
            className="flex items-center gap-2"
          >
            <Filter className="h-4 w-4" />
            Filters
          </Button>

          {/* Clear Filters Button - Only show when filters are applied */}
          <div className={`transition-all duration-300 ease-in-out ${(selectedShow !== "all" || dateFrom || dateTo) ? 'max-w-36 opacity-100 p-0.5' : 'max-w-0 opacity-0 -ml-2 overflow-hidden'}`}>
            <Button 
              variant="outline" 
              onClick={handleClearFilters}
              className="action-button-delete whitespace-nowrap"
            >
              <RotateCcw className="h-4 w-4" />
              Clear Filters
            </Button>
          </div>

          {/* Table Density Dropdown */}
          <Select value={currentDensity} onValueChange={handleDensityChange}>
            <SelectTrigger className="w-[140px]">
              {currentDensity === "compact" ? (
                <Minimize2 className="h-4 w-4 mr-2" />
              ) : (
                <LayoutGrid className="h-4 w-4 mr-2" />
              )}
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="default">Default</SelectItem>
              <SelectItem value="compact">Compact</SelectItem>
            </SelectContent>
          </Select>

          <Button className="evergreen-button" onClick={exportToExcel}>
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Summary Cards - Desktop Only */}
      <div className="hidden md:grid grid-cols-3 gap-4">
        <Card className="evergreen-card bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950/60 dark:to-emerald-900/60 border-emerald-200 dark:border-emerald-700 flex flex-col justify-center">
          <div className="px-4 py-3 space-y-1">
            <div className="flex flex-row items-center justify-between">
              <CardTitle className="text-sm font-medium text-emerald-700 dark:text-emerald-200">Evergreen Paid, Partner Paid</CardTitle>
              <DollarSign className="h-4 w-4 text-emerald-600 dark:text-emerald-300" />
            </div>
            <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-300">{formatCurrency(filteredStats.total_effective_billed_paid)}</div>
          </div>
        </Card>

        <Card className="evergreen-card bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/60 dark:to-blue-900/60 border-blue-200 dark:border-blue-700 flex flex-col justify-center">
          <div className="px-4 py-3 space-y-1">
            <div className="flex flex-row items-center justify-between">
              <CardTitle className="text-sm font-medium text-blue-700 dark:text-blue-200">Evergreen Paid, Partner Pending</CardTitle>
              <TrendingUp className="h-4 w-4 text-blue-600 dark:text-blue-300" />
            </div>
            <div className="text-2xl font-bold text-blue-600 dark:text-blue-300">{formatCurrency(filteredStats.total_billed_outstanding)}</div>
          </div>
        </Card>

        <Card className="evergreen-card bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950/60 dark:to-red-900/60 border-red-200 dark:border-red-700 flex flex-col justify-center">
          <div className="px-4 py-3 space-y-1">
            <div className="flex flex-row items-center justify-between">
              <CardTitle className="text-sm font-medium text-red-700 dark:text-red-200">Evergreen Pending, Partner Pending</CardTitle>
              <CreditCard className="h-4 w-4 text-red-600 dark:text-red-300" />
            </div>
            <div className="text-2xl font-bold text-red-600 dark:text-red-300">{formatCurrency(filteredStats.total_comp_waiting)}</div>
          </div>
        </Card>
      </div>


      {/* Loading / Error banners */}
      {fetching && (
        <div className="flex items-center gap-2 text-sm">
          <Loader2 className="h-4 w-4 animate-spin text-primary" /> <span className="text-shimmer">Loading Show Revenue and Partner Payments…</span>
        </div>
      )}
      {error && <div className="text-sm text-red-600">{error}</div>}

      {/* Partner Payments */}
      <Card className={cn(fetching ? "opacity-60" : "")}>
        <CardHeader className="flex-row items-start justify-between space-y-0">
          <div>
            <CardTitle className="text-lg sm:text-xl">Partner Payments</CardTitle>
            <CardDescription className="text-sm sm:text-base">Transactions between Evergreen and Partners</CardDescription>
          </div>
          {/* Desktop Pagination */}
          <div className="hidden md:block">
            <PaginationControls
              page={paymentsPageSafe}
              totalPages={paymentsTotalPages}
              totalItems={paymentsTotal}
              pageInput={paymentsPageInput}
              setPage={setPaymentsPage}
              setPageInput={setPaymentsPageInput}
              onGo={tryJumpPayments}
              rangeText={rangeLabel(paymentsPageSafe, paymentsTotal, undefined, PAYMENTS_PAGE_SIZE)}
            />
          </div>
        </CardHeader>
        
        {/* Mobile Pagination - Next line, centered */}
        <div className="md:hidden flex justify-center w-full px-6 pb-4">
          <PaginationControls
            page={paymentsPageSafe}
            totalPages={paymentsTotalPages}
            totalItems={paymentsTotal}
            pageInput={paymentsPageInput}
            setPage={setPaymentsPage}
            setPageInput={setPaymentsPageInput}
            onGo={tryJumpPayments}
            rangeText={rangeLabel(paymentsPageSafe, paymentsTotal, undefined, PAYMENTS_PAGE_SIZE)}
            isMobile={true}
          />
        </div>

        <CardContent>
          <div 
            key={`payments-${paymentsPageSafe}`}
            className={`border border-border rounded-lg overflow-x-auto overflow-y-hidden animate-in fade-in duration-300 ${getTableDensityClass("revenueLedger")}`}
          >
            <Table className="table-fixed" style={{ width: isPartner ? '2230px' : '2430px' }}>
              <colgroup>
                <col style={{ width: '300px' }} />
                <col style={{ width: '180px' }} />
                <col style={{ width: '110px' }} />
                <col style={{ width: '150px' }} />
                <col style={{ width: '180px' }} />
                <col style={{ width: '180px' }} />
                <col style={{ width: '130px' }} />
                {!isPartner && <col style={{ width: '200px' }} />}
                <col style={{ width: '1000px' }} />
              </colgroup>
              <TableHeader>
                <TableRow>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("show_name", "payments")}
                  >
                    <div className="flex items-center gap-2">
                      Show Name {renderSortIcon("show_name", "payments")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("bill_number", "payments")}
                  >
                    <div className="flex items-center gap-2">
                      Bill Number {renderSortIcon("bill_number", "payments")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("bill_date", "payments")}
                  >
                    <div className="flex items-center gap-2">
                      Bill Date {renderSortIcon("bill_date", "payments")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-right whitespace-nowrap"
                    onClick={() => handleSort("bill_amount", "payments")}
                  >
                    <div className="flex items-center justify-end gap-2">
                      Bill Amount {renderSortIcon("bill_amount", "payments")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-emerald-50 dark:bg-emerald-950/60 text-right whitespace-nowrap"
                    onClick={() => handleSort("effective_billed_amount_paid", "payments")}
                    title="Paid Amount"
                  >
                    <div className="flex items-center justify-end gap-2">
                      Paid Amount {renderSortIcon("effective_billed_amount_paid", "payments")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("date_of_payment", "payments")}
                    title="Date of Payment"
                  >
                    <div className="flex items-center gap-2">
                      Date of Payment {renderSortIcon("date_of_payment", "payments")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-blue-50 dark:bg-blue-950/60 text-right whitespace-nowrap"
                    onClick={() => handleSort("billed_amount_outstanding", "payments")}
                    title="Billed Amount Outstanding"
                  >
                    <div className="flex items-center justify-end gap-2">
                      Outstanding {renderSortIcon("billed_amount_outstanding", "payments")}
                    </div>
                  </TableHead>
                  {!isPartner && (
                    <TableHead 
                      className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                      onClick={() => handleSort("partner_name", "payments")}
                    >
                      <div className="flex items-center gap-2">
                        Partner Name {renderSortIcon("partner_name", "payments")}
                      </div>
                    </TableHead>
                  )}
                  <TableHead 
                    className="px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("bill_description", "payments")}
                  >
                    <div className="flex items-center gap-2">
                      Description {renderSortIcon("bill_description", "payments")}
                    </div>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TooltipProvider>
                  {paymentsSlice.length > 0 ? (
                    <>
                      {paymentsSlice.map((item, index) => (
                        <TableRow key={`${item.show_name}-${item.bill_number}-${item.bill_date}-${index}`}>
                          <TableCell className="font-medium border-r px-4 py-3">
                            <TruncatedTextWithTooltip text={item.show_name} />
                          </TableCell>
                        <TableCell className="border-r px-4 py-3 whitespace-nowrap">{item.bill_number || "-"}</TableCell>
                        <TableCell className="border-r px-4 py-3 whitespace-nowrap">{formatDate(item.bill_date)}</TableCell>
                        <TableCell className="text-right border-r px-4 py-3 whitespace-nowrap">{formatCurrency(item.bill_amount)}</TableCell>
                        <TableCell className="text-right border-r px-4 py-3 bg-emerald-50 dark:bg-emerald-950/60 whitespace-nowrap">{formatCurrency(item.effective_billed_amount_paid)}</TableCell>
                        <TableCell className="border-r px-4 py-3 whitespace-nowrap">{formatPaymentDates(item.date_of_payment)}</TableCell>
                        <TableCell className="text-right border-r px-4 py-3 bg-blue-50 dark:bg-blue-950/60 whitespace-nowrap">{formatCurrency(item.billed_amount_outstanding)}</TableCell>
                        {!isPartner && (
                          <TableCell className="border-r px-4 py-3 whitespace-nowrap">
                            <TruncatedTextWithTooltip text={item.partner_name || item.vendor_qbo_name || "-"} />
                          </TableCell>
                        )}
                        <TableCell className="px-4 py-3 whitespace-nowrap">
                          <TruncatedDescriptionWithTooltip text={item.bill_description || "-"} />
                        </TableCell>
                      </TableRow>
                    ))}
                    {/* Page Totals Row */}
                    <TableRow className="border-t border-muted-foreground/10 font-semibold">
                      <TableCell className="font-bold border-r px-4 py-3 text-muted-foreground bg-muted/20 whitespace-nowrap">PAGE TOTALS</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground bg-muted/20 whitespace-nowrap">-</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground bg-muted/20 whitespace-nowrap">-</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 text-foreground font-bold bg-muted/20 whitespace-nowrap">{formatCurrency(paymentsPageTotals.bill_amount)}</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 font-bold bg-emerald-50 dark:bg-emerald-950/60 whitespace-nowrap">{formatCurrency(paymentsPageTotals.effective_billed_amount_paid)}</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground bg-muted/20 whitespace-nowrap">-</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 font-bold bg-blue-50 dark:bg-blue-950/60 whitespace-nowrap">{formatCurrency(paymentsPageTotals.billed_amount_outstanding)}</TableCell>
                      {!isPartner && (
                        <TableCell className="border-r px-4 py-3 text-muted-foreground bg-muted/20 whitespace-nowrap">-</TableCell>
                      )}
                      <TableCell className="px-4 py-3 text-muted-foreground bg-muted/20 whitespace-nowrap">-</TableCell>
                    </TableRow>
                    {/* Totals Row */}
                    <TableRow className="border-t border-muted-foreground/10 font-semibold">
                      <TableCell className="font-bold border-r px-4 py-3 text-muted-foreground bg-muted/30 whitespace-nowrap">FULL TOTALS</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground bg-muted/30 whitespace-nowrap">-</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground bg-muted/30 whitespace-nowrap">-</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 text-foreground font-bold bg-muted/30 whitespace-nowrap">{formatCurrency(paymentsTotals.bill_amount)}</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 font-bold bg-emerald-50 dark:bg-emerald-950/60 whitespace-nowrap">{formatCurrency(paymentsTotals.effective_billed_amount_paid)}</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground bg-muted/30 whitespace-nowrap">-</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 font-bold bg-blue-50 dark:bg-blue-950/60 whitespace-nowrap">{formatCurrency(paymentsTotals.billed_amount_outstanding)}</TableCell>
                      {!isPartner && (
                        <TableCell className="border-r px-4 py-3 text-muted-foreground bg-muted/30 whitespace-nowrap">-</TableCell>
                      )}
                      <TableCell className="px-4 py-3 text-muted-foreground bg-muted/30 whitespace-nowrap">-</TableCell>
                    </TableRow>
                  </>
                ) : (
                  <TableRow>
                    <TableCell colSpan={isPartner ? 8 : 9} className="h-24 text-center">
                      No partner payment data found matching your criteria.
                    </TableCell>
                  </TableRow>
                )}
                </TooltipProvider>
              </TableBody>
            </Table>
            </div>

          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mt-3">
            {/* Desktop Layout */}
            <div className="hidden md:flex md:items-center md:justify-between w-full">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <Label htmlFor="payments-page-size-bottom" className="text-xs text-muted-foreground whitespace-nowrap">
                    Items per page:
                  </Label>
                  <Select
                    value={PAYMENTS_PAGE_SIZE.toString()}
                    onValueChange={handlePaymentsPageSizeChange}
                  >
                    <SelectTrigger id="payments-page-size-bottom" className="w-20 h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PAGE_SIZE_OPTIONS.map((size) => (
                        <SelectItem key={size} value={size.toString()}>
                          {size}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <span className="text-xs text-muted-foreground">{rangeLabel(paymentsPageSafe, paymentsTotal, "Payment Entries", PAYMENTS_PAGE_SIZE)}</span>
              </div>
              <PaginationControls
                page={paymentsPageSafe}
                totalPages={paymentsTotalPages}
                totalItems={paymentsTotal}
                pageInput={paymentsPageInput}
                setPage={setPaymentsPage}
                setPageInput={setPaymentsPageInput}
                onGo={tryJumpPayments}
              />
            </div>
            {/* Mobile Layout - Centered */}
            <div className="md:hidden flex flex-col items-center gap-3">
              <div className="flex items-center gap-2">
                <Label htmlFor="payments-page-size-bottom-mobile" className="text-xs text-muted-foreground whitespace-nowrap">
                  Items per page:
                </Label>
                <Select
                  value={PAYMENTS_PAGE_SIZE.toString()}
                  onValueChange={handlePaymentsPageSizeChange}
                >
                  <SelectTrigger id="payments-page-size-bottom-mobile" className="w-20 h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PAGE_SIZE_OPTIONS.map((size) => (
                      <SelectItem key={size} value={size.toString()}>
                        {size}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <span className="text-xs text-muted-foreground text-center">{rangeLabel(paymentsPageSafe, paymentsTotal, "Payment Entries", PAYMENTS_PAGE_SIZE)}</span>
              <PaginationControls
                page={paymentsPageSafe}
                totalPages={paymentsTotalPages}
                totalItems={paymentsTotal}
                pageInput={paymentsPageInput}
                setPage={setPaymentsPage}
                setPageInput={setPaymentsPageInput}
                onGo={tryJumpPayments}
                isMobile={true}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Show Revenue - Awaiting Payments */}
      <Card className={cn(fetching ? "opacity-60" : "")}>
        <CardHeader className="flex-row items-start justify-between space-y-0">
          <div>
            <CardTitle className="text-lg sm:text-xl">Show Revenue - Awaiting Payments</CardTitle>
            <CardDescription className="text-sm sm:text-base">
              Transactions with 0 or partial payments received from customers
              <span className="block md:inline"> (Starting July 1, 2025)</span>
            </CardDescription>
          </div>
          {/* Desktop Pagination */}
          <div className="hidden md:block">
            <PaginationControls
              page={awaitingPaymentsPageSafe}
              totalPages={awaitingPaymentsTotalPages}
              totalItems={awaitingPaymentsTotal}
              pageInput={revenueAwaitingPageInput}
              setPage={setRevenueAwaitingPage}
              setPageInput={setRevenueAwaitingPageInput}
              onGo={tryJumpAwaitingPayments}
              rangeText={rangeLabel(awaitingPaymentsPageSafe, awaitingPaymentsTotal)}
            />
          </div>
        </CardHeader>
        
        {/* Mobile Pagination - Next line, centered */}
        <div className="md:hidden flex justify-center w-full px-6 pb-4">
          <PaginationControls
            page={awaitingPaymentsPageSafe}
            totalPages={awaitingPaymentsTotalPages}
            totalItems={awaitingPaymentsTotal}
            pageInput={revenueAwaitingPageInput}
            setPage={setRevenueAwaitingPage}
            setPageInput={setRevenueAwaitingPageInput}
            onGo={tryJumpAwaitingPayments}
            rangeText={rangeLabel(awaitingPaymentsPageSafe, awaitingPaymentsTotal)}
            isMobile={true}
          />
        </div>

        <CardContent>
          <div 
            key={`awaiting-${awaitingPaymentsPageSafe}`}
            className={`border border-border rounded-lg overflow-x-auto overflow-y-hidden animate-in fade-in duration-300 ${getTableDensityClass("revenueLedger")}`}
          >
            <Table className="table-fixed" style={{ width: isPartner ? '1920px' : '2230px' }}>
              <colgroup>
                <col style={{ width: '300px' }} />
                <col style={{ width: '180px' }} />
                <col style={{ width: '110px' }} />
                <col style={{ width: '150px' }} />
                <col style={{ width: '180px' }} />
                {!isPartner && <col style={{ width: '180px' }} />}
                {!isPartner && <col style={{ width: '130px' }} />}
                <col style={{ width: '1000px' }} />
              </colgroup>
              <TableHeader>
                <TableRow>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("show_name", "awaiting")}
                  >
                    <div className="flex items-center gap-2">
                      Show Name {renderSortIcon("show_name", "awaiting")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("invoice_doc_number", "awaiting")}
                    title="Invoice Number"
                  >
                    <div className="flex items-center gap-2">
                      Invoice Number {renderSortIcon("invoice_doc_number", "awaiting")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("invoice_date", "awaiting")}
                    title="Invoice Date"
                  >
                    <div className="flex items-center gap-2">
                      Invoice Date {renderSortIcon("invoice_date", "awaiting")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-right whitespace-nowrap"
                    onClick={() => handleSort("invoice_amount", "awaiting")}
                    title="Invoice Amount"
                  >
                    <div className="flex items-center justify-end gap-2">
                      Invoice Amount {renderSortIcon("invoice_amount", "awaiting")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-right whitespace-nowrap"
                    onClick={() => handleSort("effective_payment_received", "awaiting")}
                    title="Payments Received"
                  >
                    <div className="flex items-center justify-end gap-2">
                      Payments Received {renderSortIcon("effective_payment_received", "awaiting")}
                    </div>
                  </TableHead>
                  {!isPartner && (
                    <TableHead 
                      className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-right whitespace-nowrap"
                      onClick={() => handleSort("evergreen_outstanding", "awaiting")}
                      title="Evergreen Outstanding"
                    >
                      <div className="flex items-center justify-end gap-2">
                        Evergreen O/S {renderSortIcon("evergreen_outstanding", "awaiting")}
                      </div>
                    </TableHead>
                  )}
                  {!isPartner && (
                    <TableHead 
                      className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-red-50 dark:bg-red-950/60 text-right whitespace-nowrap"
                      onClick={() => handleSort("partner_outstanding", "awaiting")}
                      title="Partner Outstanding"
                    >
                      <div className="flex items-center justify-end gap-2">
                        Partner O/S {renderSortIcon("partner_outstanding", "awaiting")}
                      </div>
                    </TableHead>
                  )}
                  <TableHead 
                    className="px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("invoice_description", "awaiting")}
                  >
                    <div className="flex items-center gap-2">
                      Description {renderSortIcon("invoice_description", "awaiting")}
                    </div>
                  </TableHead>
                </TableRow>
              </TableHeader>

              <TableBody>
                <TooltipProvider>
                  {awaitingPaymentsSlice.length > 0 ? (
                    <>
                      {awaitingPaymentsSlice.map((item, index) => (
                        <TableRow key={`awaiting-${item.show_name}-${item.customer}-${item.invoice_date}-${index}`}>
                          <TableCell className="font-medium border-r px-4 py-3">
                            <TruncatedTextWithTooltip text={item.show_name} />
                          </TableCell>
                        <TableCell className="border-r px-4 py-3 whitespace-nowrap">{item.invoice_doc_number || "-"}</TableCell>
                        <TableCell className="border-r px-4 py-3 whitespace-nowrap">{formatDate(item.invoice_date)}</TableCell>
                        <TableCell className="text-right border-r px-4 py-3 whitespace-nowrap">{formatCurrency(item.invoice_amount)}</TableCell>
                        <TableCell className="text-right border-r px-4 py-3 whitespace-nowrap">{formatCurrency(item.effective_payment_received)}</TableCell>
                        {!isPartner && (
                          <TableCell className="text-right border-r px-4 py-3 whitespace-nowrap">{formatCurrency(item.evergreen_outstanding)}</TableCell>
                        )}
                        {!isPartner && (
                          <TableCell className="border-r text-right px-4 py-3 whitespace-nowrap bg-red-50 dark:bg-red-950/60">{formatCurrency(item.partner_outstanding)}</TableCell>
                        )}
                        <TableCell className="px-4 py-3 whitespace-nowrap">
                          <TruncatedDescriptionWithTooltip text={item.invoice_description} />
                        </TableCell>
                      </TableRow>
                    ))}
                    {/* Page Totals Row */}
                    <TableRow className="bg-muted/20 border-t border-muted-foreground/10 font-semibold">
                      <TableCell className="font-bold border-r px-4 py-3 text-muted-foreground whitespace-nowrap">PAGE TOTALS</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground whitespace-nowrap">-</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground whitespace-nowrap">-</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 text-foreground font-bold whitespace-nowrap">{formatCurrency(awaitingPaymentsPageTotals.invoice_amount)}</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 font-bold whitespace-nowrap">{formatCurrency(awaitingPaymentsPageTotals.effective_payment_received)}</TableCell>
                      {!isPartner && (
                        <TableCell className="text-right border-r px-4 py-3 font-bold whitespace-nowrap">{formatCurrency(awaitingPaymentsPageTotals.evergreen_outstanding)}</TableCell>
                      )}
                      {!isPartner && (
                        <TableCell className="border-r text-right px-4 py-3 font-bold whitespace-nowrap bg-red-50 dark:bg-red-950/60">{formatCurrency(awaitingPaymentsPageTotals.partner_outstanding)}</TableCell>
                      )}
                      <TableCell className="px-4 py-3 text-muted-foreground">-</TableCell>
                    </TableRow>
                    {/* Totals Row */}
                    <TableRow className="bg-muted/20 border-t border-muted-foreground/10 font-semibold">
                      <TableCell className="font-bold border-r px-4 py-3 text-muted-foreground whitespace-nowrap">FULL TOTALS</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground whitespace-nowrap">-</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground whitespace-nowrap">-</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 text-foreground font-bold whitespace-nowrap">{formatCurrency(awaitingPaymentsTotals.invoice_amount)}</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 font-bold whitespace-nowrap">{formatCurrency(awaitingPaymentsTotals.effective_payment_received)}</TableCell>
                      {!isPartner && (
                        <TableCell className="text-right border-r px-4 py-3 font-bold whitespace-nowrap">{formatCurrency(awaitingPaymentsTotals.evergreen_outstanding)}</TableCell>
                      )}
                      {!isPartner && (
                        <TableCell className="border-r text-right px-4 py-3 font-bold whitespace-nowrap bg-red-50 dark:bg-red-950/60">{formatCurrency(awaitingPaymentsTotals.partner_outstanding)}</TableCell>
                      )}
                      <TableCell className="px-4 py-3 text-muted-foreground">-</TableCell>
                    </TableRow>
                  </>
                ) : (
                  <TableRow>
                    <TableCell colSpan={revenueColumnCount} className="h-24 text-center">
                      No awaiting payments data found matching your criteria.
                    </TableCell>
                  </TableRow>
                )}
                </TooltipProvider>
              </TableBody>
            </Table>
            </div>

          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mt-3">
            {/* Desktop Layout */}
            <div className="hidden md:flex md:items-center md:justify-between w-full">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <Label htmlFor="awaiting-page-size-bottom" className="text-xs text-muted-foreground whitespace-nowrap">
                    Items per page:
                  </Label>
                  <Select
                    value={REVENUE_PAGE_SIZE.toString()}
                    onValueChange={handleRevenuePageSizeChange}
                  >
                    <SelectTrigger id="awaiting-page-size-bottom" className="w-20 h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PAGE_SIZE_OPTIONS.map((size) => (
                        <SelectItem key={size} value={size.toString()}>
                          {size}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <span className="text-xs text-muted-foreground">{rangeLabel(awaitingPaymentsPageSafe, awaitingPaymentsTotal, "Awaiting Payments")}</span>
              </div>
              <PaginationControls
                page={awaitingPaymentsPageSafe}
                totalPages={awaitingPaymentsTotalPages}
                totalItems={awaitingPaymentsTotal}
                pageInput={revenueAwaitingPageInput}
                setPage={setRevenueAwaitingPage}
                setPageInput={setRevenueAwaitingPageInput}
                onGo={tryJumpAwaitingPayments}
              />
            </div>
            {/* Mobile Layout - Centered */}
            <div className="md:hidden flex flex-col items-center gap-3">
              <div className="flex items-center gap-2">
                <Label htmlFor="awaiting-page-size-bottom-mobile" className="text-xs text-muted-foreground whitespace-nowrap">
                  Items per page:
                </Label>
                <Select
                  value={REVENUE_PAGE_SIZE.toString()}
                  onValueChange={handleRevenuePageSizeChange}
                >
                  <SelectTrigger id="awaiting-page-size-bottom-mobile" className="w-20 h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PAGE_SIZE_OPTIONS.map((size) => (
                      <SelectItem key={size} value={size.toString()}>
                        {size}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <span className="text-xs text-muted-foreground text-center">{rangeLabel(awaitingPaymentsPageSafe, awaitingPaymentsTotal, "Awaiting Payments")}</span>
              <PaginationControls
                page={awaitingPaymentsPageSafe}
                totalPages={awaitingPaymentsTotalPages}
                totalItems={awaitingPaymentsTotal}
                pageInput={revenueAwaitingPageInput}
                setPage={setRevenueAwaitingPage}
                setPageInput={setRevenueAwaitingPageInput}
                onGo={tryJumpAwaitingPayments}
                isMobile={true}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Show Revenue - Received Payments */}
      <Card className={cn(fetching ? "opacity-60" : "")}>
        <CardHeader className="flex-row items-start justify-between space-y-0">
          <div>
            <CardTitle className="text-lg sm:text-xl">Show Revenue - Received Payments</CardTitle>
            <CardDescription className="text-sm sm:text-base">
              Transactions where payments have been received from customers
              <span className="block md:inline"> (Starting July 1, 2025)</span>
            </CardDescription>
          </div>
          {/* Desktop Pagination */}
          <div className="hidden md:block">
            <PaginationControls
              page={receivedPaymentsPageSafe}
              totalPages={receivedPaymentsTotalPages}
              totalItems={receivedPaymentsTotal}
              pageInput={revenueReceivedPageInput}
              setPage={setRevenueReceivedPage}
              setPageInput={setRevenueReceivedPageInput}
              onGo={tryJumpReceivedPayments}
              rangeText={rangeLabel(receivedPaymentsPageSafe, receivedPaymentsTotal)}
            />
          </div>
        </CardHeader>
        
        {/* Mobile Pagination - Next line, centered */}
        <div className="md:hidden flex justify-center w-full px-6 pb-4">
          <PaginationControls
            page={receivedPaymentsPageSafe}
            totalPages={receivedPaymentsTotalPages}
            totalItems={receivedPaymentsTotal}
            pageInput={revenueReceivedPageInput}
            setPage={setRevenueReceivedPage}
            setPageInput={setRevenueReceivedPageInput}
            onGo={tryJumpReceivedPayments}
            rangeText={rangeLabel(receivedPaymentsPageSafe, receivedPaymentsTotal)}
            isMobile={true}
          />
        </div>

        <CardContent>
          <div 
            key={`received-${receivedPaymentsPageSafe}`}
            className={`border border-border rounded-lg overflow-x-auto overflow-y-hidden animate-in fade-in duration-300 ${getTableDensityClass("revenueLedger")}`}
          >
            <Table className="table-fixed" style={{ width: isPartner ? '1920px' : '2230px' }}>
              <colgroup>
                <col style={{ width: '300px' }} />
                <col style={{ width: '180px' }} />
                <col style={{ width: '110px' }} />
                <col style={{ width: '150px' }} />
                <col style={{ width: '180px' }} />
                {!isPartner && <col style={{ width: '180px' }} />}
                {!isPartner && <col style={{ width: '130px' }} />}
                <col style={{ width: '1000px' }} />
              </colgroup>
              <TableHeader>
                <TableRow>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("show_name", "received")}
                  >
                    <div className="flex items-center gap-2">
                      Show Name {renderSortIcon("show_name", "received")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("invoice_doc_number", "received")}
                    title="Invoice Number"
                  >
                    <div className="flex items-center gap-2">
                      Invoice Number {renderSortIcon("invoice_doc_number", "received")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("invoice_date", "received")}
                    title="Invoice Date"
                  >
                    <div className="flex items-center gap-2">
                      Invoice Date {renderSortIcon("invoice_date", "received")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-right whitespace-nowrap"
                    onClick={() => handleSort("invoice_amount", "received")}
                    title="Invoice Amount"
                  >
                    <div className="flex items-center justify-end gap-2">
                      Invoice Amount {renderSortIcon("invoice_amount", "received")}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-right whitespace-nowrap"
                    onClick={() => handleSort("effective_payment_received", "received")}
                    title="Payments Received"
                  >
                    <div className="flex items-center justify-end gap-2">
                      Payments Received {renderSortIcon("effective_payment_received", "received")}
                    </div>
                  </TableHead>
                  {!isPartner && (
                    <TableHead 
                      className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-right whitespace-nowrap"
                      onClick={() => handleSort("evergreen_compensation", "received")}
                      title="Evergreen Split"
                    >
                      <div className="flex items-center justify-end gap-2">
                        Evergreen Split {renderSortIcon("evergreen_compensation", "received")}
                      </div>
                    </TableHead>
                  )}
                  {!isPartner && (
                    <TableHead 
                      className="border-r px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-right whitespace-nowrap"
                      onClick={() => handleSort("partner_compensation", "received")}
                      title="Partner Split"
                    >
                      <div className="flex items-center justify-end gap-2">
                        Partner Split {renderSortIcon("partner_compensation", "received")}
                      </div>
                    </TableHead>
                  )}
                  <TableHead 
                    className="px-4 py-4 font-semibold cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 text-left whitespace-nowrap"
                    onClick={() => handleSort("invoice_description", "received")}
                  >
                    <div className="flex items-center gap-2">
                      Description {renderSortIcon("invoice_description", "received")}
                    </div>
                  </TableHead>
                </TableRow>
              </TableHeader>

              <TableBody>
                <TooltipProvider>
                  {receivedPaymentsSlice.length > 0 ? (
                    <>
                      {receivedPaymentsSlice.map((item, index) => (
                        <TableRow key={`${item.show_name}-${item.customer}-${item.invoice_date}-${index}`}>
                          <TableCell className="font-medium border-r px-4 py-3">
                            <TruncatedTextWithTooltip text={item.show_name} />
                          </TableCell>
                        <TableCell className="border-r px-4 py-3 whitespace-nowrap">{item.invoice_doc_number || "-"}</TableCell>
                        <TableCell className="border-r px-4 py-3 whitespace-nowrap">{formatDate(item.invoice_date)}</TableCell>
                        <TableCell className="text-right border-r px-4 py-3 whitespace-nowrap">{formatCurrency(item.invoice_amount)}</TableCell>
                        <TableCell className="text-right border-r px-4 py-3 whitespace-nowrap">{formatCurrency(item.effective_payment_received)}</TableCell>
                        {!isPartner && (
                          <TableCell className="text-right border-r px-4 py-3 whitespace-nowrap">{formatCurrency(item.evergreen_compensation)}</TableCell>
                        )}
                        {!isPartner && (
                          <TableCell className="border-r text-right px-4 py-3 whitespace-nowrap">{formatCurrency(item.partner_compensation)}</TableCell>
                        )}
                        <TableCell className="px-4 py-3 whitespace-nowrap">
                          <TruncatedDescriptionWithTooltip text={item.invoice_description} />
                        </TableCell>
                      </TableRow>
                    ))}
                    {/* Page Totals Row */}
                    <TableRow className="bg-muted/20 border-t border-muted-foreground/10 font-semibold">
                      <TableCell className="font-bold border-r px-4 py-3 text-muted-foreground whitespace-nowrap">PAGE TOTALS</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground whitespace-nowrap">-</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground whitespace-nowrap">-</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 text-foreground font-bold whitespace-nowrap">{formatCurrency(receivedPaymentsPageTotals.invoice_amount)}</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 font-bold whitespace-nowrap">{formatCurrency(receivedPaymentsPageTotals.effective_payment_received)}</TableCell>
                      {!isPartner && (
                        <TableCell className="text-right border-r px-4 py-3 font-bold whitespace-nowrap">{formatCurrency(receivedPaymentsPageTotals.evergreen_compensation)}</TableCell>
                      )}
                      {!isPartner && (
                        <TableCell className="border-r text-right px-4 py-3 font-bold whitespace-nowrap">{formatCurrency(receivedPaymentsPageTotals.partner_compensation)}</TableCell>
                      )}
                      <TableCell className="px-4 py-3 text-muted-foreground">-</TableCell>
                    </TableRow>
                    {/* Totals Row */}
                    <TableRow className="bg-muted/20 border-t border-muted-foreground/10 font-semibold">
                      <TableCell className="font-bold border-r px-4 py-3 text-muted-foreground whitespace-nowrap">FULL TOTALS</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground whitespace-nowrap">-</TableCell>
                      <TableCell className="border-r px-4 py-3 text-muted-foreground whitespace-nowrap">-</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 text-foreground font-bold whitespace-nowrap">{formatCurrency(receivedPaymentsTotals.invoice_amount)}</TableCell>
                      <TableCell className="text-right border-r px-4 py-3 font-bold whitespace-nowrap">{formatCurrency(receivedPaymentsTotals.effective_payment_received)}</TableCell>
                      {!isPartner && (
                        <TableCell className="text-right border-r px-4 py-3 font-bold whitespace-nowrap">{formatCurrency(receivedPaymentsTotals.evergreen_compensation)}</TableCell>
                      )}
                      {!isPartner && (
                        <TableCell className="border-r text-right px-4 py-3 font-bold whitespace-nowrap">{formatCurrency(receivedPaymentsTotals.partner_compensation)}</TableCell>
                      )}
                      <TableCell className="px-4 py-3 text-muted-foreground">-</TableCell>
                    </TableRow>
                  </>
                ) : (
                  <TableRow>
                    <TableCell colSpan={revenueColumnCount} className="h-24 text-center">
                      No revenue data found matching your criteria.
                    </TableCell>
                  </TableRow>
                )}
                </TooltipProvider>
              </TableBody>
            </Table>
            </div>

          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mt-3">
            {/* Desktop Layout */}
            <div className="hidden md:flex md:items-center md:justify-between w-full">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <Label htmlFor="revenue-page-size-bottom" className="text-xs text-muted-foreground whitespace-nowrap">
                    Items per page:
                  </Label>
                  <Select
                    value={REVENUE_PAGE_SIZE.toString()}
                    onValueChange={handleRevenuePageSizeChange}
                  >
                    <SelectTrigger id="revenue-page-size-bottom" className="w-20 h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PAGE_SIZE_OPTIONS.map((size) => (
                        <SelectItem key={size} value={size.toString()}>
                          {size}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <span className="text-xs text-muted-foreground">{rangeLabel(receivedPaymentsPageSafe, receivedPaymentsTotal, "Received Payments")}</span>
              </div>
              <PaginationControls
                page={receivedPaymentsPageSafe}
                totalPages={receivedPaymentsTotalPages}
                totalItems={receivedPaymentsTotal}
                pageInput={revenueReceivedPageInput}
                setPage={setRevenueReceivedPage}
                setPageInput={setRevenueReceivedPageInput}
                onGo={tryJumpReceivedPayments}
              />
            </div>
            {/* Mobile Layout - Centered */}
            <div className="md:hidden flex flex-col items-center gap-3">
              <div className="flex items-center gap-2">
                <Label htmlFor="revenue-page-size-bottom-mobile" className="text-xs text-muted-foreground whitespace-nowrap">
                  Items per page:
                </Label>
                <Select
                  value={REVENUE_PAGE_SIZE.toString()}
                  onValueChange={handleRevenuePageSizeChange}
                >
                  <SelectTrigger id="revenue-page-size-bottom-mobile" className="w-20 h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PAGE_SIZE_OPTIONS.map((size) => (
                      <SelectItem key={size} value={size.toString()}>
                        {size}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <span className="text-xs text-muted-foreground text-center">{rangeLabel(receivedPaymentsPageSafe, receivedPaymentsTotal, "Received Payments")}</span>
              <PaginationControls
                page={receivedPaymentsPageSafe}
                totalPages={receivedPaymentsTotalPages}
                totalItems={receivedPaymentsTotal}
                pageInput={revenueReceivedPageInput}
                setPage={setRevenueReceivedPage}
                setPageInput={setRevenueReceivedPageInput}
                onGo={tryJumpReceivedPayments}
                isMobile={true}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Slide-out Filter Panel */}
      {isSlideOutAnimating && (
        <div 
          className="fixed inset-0 z-50" 
          style={{ margin: 0, padding: 0 }}
          data-state={isSlideOutOpen ? "open" : "closed"}
        >
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/30 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:duration-300 data-[state=open]:duration-300"
            data-state={isSlideOutOpen ? "open" : "closed"}
            onClick={() => setIsSlideOutOpen(false)}
          />
          
          {/* Slide-out Panel */}
          <div 
            className="absolute top-0 right-0 w-96 h-screen shadow-2xl border-l border-border overflow-y-auto data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right data-[state=closed]:duration-300 data-[state=open]:duration-300 transition ease-in-out"
            data-state={isSlideOutOpen ? "open" : "closed"}
            style={{ 
              margin: 0, 
              padding: 0, 
              top: 0,
              backgroundColor: isDark 
                ? "rgb(20, 20, 20)" 
                : "rgb(255, 255, 255)",
              boxShadow: isDark 
                ? "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)"
                : "0 4px 24px rgba(0, 0, 0, 0.12), 0 2px 6px rgba(0, 0, 0, 0.08)",
              // Ensure solid background on mobile - no backdrop filter or blur
              WebkitBackdropFilter: "none",
              backdropFilter: "none",
              willChange: "transform",
            }}
          >
            <div className="flex items-center justify-between px-6 py-3 border-b border-border">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Filters
              </h2>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsSlideOutOpen(false)}
                className="h-9 w-9 rounded-full p-0 flex items-center justify-center"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="p-6">
              {/* Filter Stats */}
              <div className="flex gap-2 justify-center">
                <Card className="flex-1 flex flex-col justify-center">
                  <div className="px-3 py-2 space-y-1 text-center">
                    <div className="text-base font-bold">{filteredPartnerPayments.length}</div>
                    <div className="text-xs leading-tight">Partner<br />Payments</div>
                  </div>
                </Card>
                <Card className="flex-1 flex flex-col justify-center">
                  <div className="px-3 py-2 space-y-1 text-center">
                    <div className="text-base font-bold">{awaitingPaymentsData.length}</div>
                    <div className="text-xs leading-tight">Awaiting<br />Payments</div>
                  </div>
                </Card>
                <Card className="flex-1 flex flex-col justify-center">
                  <div className="px-3 py-2 space-y-1 text-center">
                    <div className="text-base font-bold">{receivedPaymentsData.length}</div>
                    <div className="text-xs leading-tight">Received<br />Payments</div>
                  </div>
                </Card>
              </div>

              {/* Filter Controls */}
              <div className="mt-6 space-y-4">
                <div className="space-y-2">
                  <Label>Show Name</Label>
                  <ShowCombobox
                    value={selectedShow}
                    onChange={(val) => setSelectedShow(val)}
                    options={["all", ...availableShows]}
                    placeholder="Search shows…"
                  />
                </div>

                <div className="space-y-2">
                  <Label>From Date</Label>
                  <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
                </div>

                <div className="space-y-2">
                  <Label>To Date</Label>
                  <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 mt-6">
                <Button onClick={() => setIsSlideOutOpen(false)} className="w-full">
                  Apply Filters
                </Button>
                <Button variant="outline" onClick={handleClearFilters} className="action-button-delete w-full">
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Clear Filters
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setIsSlideOutOpen(false)} 
                  className="w-full"
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function PaginationControls({
  page,
  totalPages,
  totalItems,
  pageInput,
  setPage,
  setPageInput,
  onGo,
  rangeText,
  isMobile = false,
}: {
  page: number
  totalPages: number
  totalItems: number
  pageInput: string
  setPage: (n: number) => void
  setPageInput: (s: string) => void
  onGo: () => void
  rangeText?: string
  isMobile?: boolean
}) {
  if (isMobile) {
    return (
      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => setPage(Math.max(1, page - 1))} disabled={page <= 1}>
          <ChevronLeft className="h-4 w-4" />
          Prev
        </Button>
        <span className="text-xs text-muted-foreground">
          Page {page} / {totalPages}
        </span>
        <Button variant="outline" size="sm" onClick={() => setPage(Math.min(totalPages, page + 1))} disabled={page >= totalPages}>
          Next
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    )
  }

  return (
    <div className="flex items-center gap-2">
      {rangeText ? <span className="hidden sm:inline text-xs text-muted-foreground">{rangeText}</span> : null}
      <Button variant="outline" size="sm" onClick={() => setPage(Math.max(1, page - 1))} disabled={page <= 1}>
        <ChevronLeft className="h-4 w-4" />
        Prev
      </Button>
      <span className="text-xs text-muted-foreground">
        Page {page} / {totalPages}
      </span>
      <Button variant="outline" size="sm" onClick={() => setPage(Math.min(totalPages, page + 1))} disabled={page >= totalPages}>
        Next
        <ChevronRight className="h-4 w-4" />
      </Button>
      <div className="flex items-center gap-2 ml-2">
        <Label htmlFor={`page-input-${rangeText ?? ""}`} className="text-xs text-muted-foreground whitespace-nowrap">Go to</Label>
        <Input
          id={`page-input-${rangeText ?? ""}`}
          type="number"
          min={1}
          max={totalPages}
          value={pageInput}
          onChange={(e) => setPageInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") onGo()
          }}
          className="h-8 w-16 pr-1"
          wrapperClassName="h-9 w-16"
        />
        <Button variant="outline" size="sm" onClick={onGo} className="h-9 w-12 rounded-full">Go</Button>
      </div>
    </div>
  )
}

function TruncatedTextWithTooltip({ text }: { text: string }) {
  const textRef = React.useRef<HTMLDivElement>(null)
  const [isTruncated, setIsTruncated] = React.useState(false)

  React.useEffect(() => {
    const checkTruncation = () => {
      if (textRef.current) {
        const isOverflowing = textRef.current.scrollWidth > textRef.current.clientWidth
        setIsTruncated(isOverflowing)
      }
    }
    
    // Use requestAnimationFrame to ensure DOM is fully rendered
    const timeoutId = setTimeout(() => {
      checkTruncation()
    }, 0)
    
    // Recheck on window resize
    window.addEventListener('resize', checkTruncation)
    
    return () => {
      clearTimeout(timeoutId)
      window.removeEventListener('resize', checkTruncation)
    }
  }, [text])

  const content = (
    <div ref={textRef} className="truncate max-w-[300px]">
      {text}
    </div>
  )

  if (isTruncated) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          {content}
        </TooltipTrigger>
        <TooltipContent>
          <p>{text}</p>
        </TooltipContent>
      </Tooltip>
    )
  }

  return content
}

function TruncatedDescriptionWithTooltip({ text }: { text: string }) {
  const textRef = React.useRef<HTMLDivElement>(null)
  const [isTruncated, setIsTruncated] = React.useState(false)

  React.useEffect(() => {
    const checkTruncation = () => {
      if (textRef.current) {
        const isOverflowing = textRef.current.scrollWidth > textRef.current.clientWidth
        setIsTruncated(isOverflowing)
      }
    }
    
    // Use requestAnimationFrame to ensure DOM is fully rendered
    const timeoutId = setTimeout(() => {
      checkTruncation()
    }, 0)
    
    // Recheck on window resize
    window.addEventListener('resize', checkTruncation)
    
    return () => {
      clearTimeout(timeoutId)
      window.removeEventListener('resize', checkTruncation)
    }
  }, [text])

  const content = (
    <div ref={textRef} className="truncate" style={{ maxWidth: '1000px' }}>
      {text}
    </div>
  )

  if (isTruncated) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          {content}
        </TooltipTrigger>
        <TooltipContent className="max-w-[500px]">
          <p className="break-words whitespace-normal">{text}</p>
        </TooltipContent>
      </Tooltip>
    )
  }

  return content
}

function ShowCombobox({
  value,
  onChange,
  options,
  placeholder = "Search…"
}: {
  value: string
  onChange: (v: string) => void
  options: string[]
  placeholder?: string
}) {
  const [open, setOpen] = useState(false)

  const labelFor = (v: string) => (v === "all" ? "All Shows" : v)

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" role="combobox" aria-expanded={open} className="w-full justify-between">
          {value ? labelFor(value) : "Select show"}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
        <Command>
          <CommandInput placeholder={placeholder} />
          <CommandList>
            <CommandEmpty>No shows found.</CommandEmpty>
            <CommandGroup>
              {options.map((opt) => (
                <CommandItem
                  key={opt}
                  value={opt}
                  onSelect={(currentValue) => {
                    onChange(currentValue)
                    setOpen(false)
                  }}
                >
                  <Check className={cn("mr-2 h-4 w-4", value === opt ? "opacity-100" : "opacity-0")} />
                  {labelFor(opt)}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  )
}

function num(v: any): number {
  if (typeof v === "number") return v
  const n = Number(v)
  return Number.isFinite(n) ? n : 0
}

function toDate(dateStr: string | null, endOfDay = false): Date {
  if (!dateStr) return new Date("1900-01-01T00:00:00Z")
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    const [y, m, d] = dateStr.split("-").map((x) => parseInt(x, 10))
    return endOfDay ? new Date(y, m - 1, d, 23, 59, 59, 999) : new Date(y, m - 1, d)
  }
  const d = new Date(dateStr)
  if (endOfDay) d.setHours(23, 59, 59, 999)
  return d
}

async function readErr(res: Response, prefix = "Request failed") {
  try {
    const text = await res.text()
    return `${prefix}: ${res.status} ${res.statusText}${text ? ` - ${text}` : ""}`
  } catch {
    return `${prefix}: ${res.status} ${res.statusText}`
  }
}