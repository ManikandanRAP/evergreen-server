"use client"

import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Collapsible, CollapsibleTrigger, CollapsibleContent } from "@/components/ui/collapsible"
import {
  DollarSign,
  Calendar,
  Users,
  Radio,
  TrendingUp,
  Phone,
  Mail,
  MapPin,
  Info,
  BarChart3,
  Target,
  GraduationCap,
  Briefcase,
  Percent,
  Hash,
  Flag,
  X,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Archive,
  RotateCcw,
  User,
  Edit,
  Trash2,
  BookOpenCheck,
} from "lucide-react"
import type { Show } from "@/lib/api-client"
import { getRankingInfo } from "@/lib/ranking-utils"
import { useUserMapping } from "@/hooks/use-user-mapping"
import React, { useEffect, useLayoutEffect, useState } from "react"

// --- Reusable Sub-components for Cleaner Layout ---

// A generic component to display a piece of detail with a label and value
const DetailItem = ({
  label,
  value,
  icon,
  isBadge = false,
  badgeVariant = "outline",
}: {
  label: string
  value: React.ReactNode
  icon?: React.ElementType
  isBadge?: boolean
  badgeVariant?: "default" | "secondary" | "destructive" | "outline"
}) => {
  const Icon = icon
  
  // Check if the value is a React element (like a Badge component)
  const isReactElement = React.isValidElement(value)
  
  return (
    <div>
      <label className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
        {Icon && <Icon className="h-3.5 w-3.5" />}
        {label}
      </label>
      {isBadge || isReactElement ? (
        <div className="mt-1">
          {isBadge ? (
            <Badge variant={badgeVariant} className="text-xs md:text-sm">
              {value}
            </Badge>
          ) : (
            value
          )}
        </div>
      ) : (
        <p className="text-sm md:text-base font-semibold">{value || "N/A"}</p>
      )}
    </div>
  )
}

// A dedicated component for displaying contact information cleanly
const ContactCard = ({
  title,
  contactString,
}: {
  title: string
  contactString: string
}) => {
  const parseContact = (str: string) => {
    if (!str || str === "Internal" || str === "-") {
      return { name: str || "Not specified", address: "", phone: "", email: "" }
    }
    const parts = str.split(", ")
    return {
      name: parts[0] || "",
      address: parts.slice(1, -2).join(", ") || "",
      phone: parts[parts.length - 2] || "",
      email: parts[parts.length - 1] || "",
    }
  }

  const contact = parseContact(contactString)

  return (
    <div className="space-y-2">
      <h5 className="font-semibold text-sm text-muted-foreground">{title}</h5>
      <div className="space-y-2 text-sm">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
          <span>{contact.name}</span>
        </div>
        {contact.address && (
          <div className="flex items-start gap-2">
            <MapPin className="h-4 w-4 flex-shrink-0 text-muted-foreground mt-0.5" />
            <span>{contact.address}</span>
          </div>
        )}
        {contact.phone && (
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
            <span>{contact.phone}</span>
          </div>
        )}
        {contact.email && (
          <div className="flex items-center gap-2">
            <Mail className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
            <span className="truncate">{contact.email}</span>
          </div>
        )}
      </div>
    </div>
  )
}

// --- Main Dialog Component ---

interface ShowViewDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  show: Show | null
  onNavigate: (direction: "next" | "previous") => void
  hasNext: boolean
  hasPrevious: boolean
  onEdit?: (show: Show) => void
  onDelete?: (show: Show) => void
  onArchive?: (show: Show) => void
  onUnarchive?: (show: Show) => void
  isArchived?: boolean
}

export default function ShowViewDialog({
  open,
  onOpenChange,
  show,
  onNavigate,
  hasNext,
  hasPrevious,
  onEdit,
  onDelete,
  onArchive,
  onUnarchive,
  isArchived = false,
}: ShowViewDialogProps) {
  const { getUserName, fetchUser } = useUserMapping()
  const [animationDirection, setAnimationDirection] = useState<"next" | "previous" | null>(null)
  const [isContactOpen, setIsContactOpen] = useState(false)
  const [isDark, setIsDark] = useState(false)
  
  // Touch navigation state
  const [touchStart, setTouchStart] = useState<{ x: number; y: number } | null>(null)
  const [touchEnd, setTouchEnd] = useState<{ x: number; y: number } | null>(null)
  const [isSwipeActive, setIsSwipeActive] = useState(false)
  
  // Check theme
  useEffect(() => {
    const checkTheme = () => {
      setIsDark(document.documentElement.classList.contains('dark'))
    }
    checkTheme()
    
    const observer = new MutationObserver(checkTheme)
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    })
    
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (!open) {
      // Reset animation direction when dialog closes
      setAnimationDirection(null)
      return
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" && hasNext) {
        setAnimationDirection("next")
        onNavigate("next")
      } else if (e.key === "ArrowLeft" && hasPrevious) {
        setAnimationDirection("previous")
        onNavigate("previous")
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    return () => {
      document.removeEventListener("keydown", handleKeyDown)
    }
  }, [open, hasNext, hasPrevious, onNavigate])

  // Touch navigation handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0]
    setTouchStart({ x: touch.clientX, y: touch.clientY })
    setTouchEnd(null)
    setIsSwipeActive(false)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    const touch = e.touches[0]
    setTouchEnd({ x: touch.clientX, y: touch.clientY })
    
    // Provide visual feedback during swipe
    if (touchStart) {
      const deltaX = touchStart.x - touch.clientX
      const deltaY = touchStart.y - touch.clientY
      const minSwipeDistance = 30 // Start showing feedback earlier
      const maxVerticalDistance = 100
      
      if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaY) < maxVerticalDistance && Math.abs(deltaX) > minSwipeDistance) {
        setIsSwipeActive(true)
      }
    }
  }

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return

    const deltaX = touchStart.x - touchEnd.x
    const deltaY = touchStart.y - touchEnd.y
    const minSwipeDistance = 50 // Minimum distance for a swipe
    const maxVerticalDistance = 100 // Maximum vertical movement to still count as horizontal swipe

    // Check if it's a horizontal swipe (not vertical scroll)
    if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaY) < maxVerticalDistance) {
      if (Math.abs(deltaX) > minSwipeDistance) {
        if (deltaX > 0 && hasNext) {
          // Swipe left - go to next
          setAnimationDirection("next")
          onNavigate("next")
        } else if (deltaX < 0 && hasPrevious) {
          // Swipe right - go to previous
          setAnimationDirection("previous")
          onNavigate("previous")
        }
      }
    }

    // Reset touch state
    setTouchStart(null)
    setTouchEnd(null)
    setIsSwipeActive(false)
  }

  // Fetch user data when dialog opens
  useEffect(() => {
    if (open && show) {
      if (show.created_by_id) {
        fetchUser(show.created_by_id)
      }
      if (show.archived_by_id) {
        fetchUser(show.archived_by_id)
      }
    }
  }, [open, show, fetchUser])

  // Force layout recalculation on mobile when dialog opens
  // This fixes the issue where content appears empty until scrolling
  useLayoutEffect(() => {
    if (open) {
      // Force a reflow to ensure proper height calculation
      // Use requestAnimationFrame to ensure DOM is ready
      requestAnimationFrame(() => {
        // Force a reflow by accessing layout properties
        const dialogContent = document.querySelector('[data-radix-dialog-content]')
        if (dialogContent) {
          // Accessing getBoundingClientRect forces a layout recalculation
          void dialogContent.getBoundingClientRect()
          // Also trigger a resize event for ScrollArea to recalculate
          window.dispatchEvent(new Event('resize'))
        }
      })
    }
  }, [open])

  if (!show) return null

  const handleNavigationClick = (direction: "next" | "previous") => {
    setAnimationDirection(direction)
    onNavigate(direction)
  }

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount)

  const formatPercentage = (amount: number | null | undefined) =>
    amount === null || typeof amount === "undefined" ? "N/A" : `${amount}%`

  const revenueFlags = [
    { label: "Branded Revenue", value: show.has_branded_revenue },
    { label: "Marketing Revenue", value: show.has_marketing_revenue },
    { label: "Web Management Revenue", value: show.has_web_mgmt_revenue },
    { label: "Minimum Guarantee", value: show.minimum_guarantee },
    { label: "Sponsorship Revenue", value: show.has_sponsorship_revenue },
    { label: "Non Evergreen Revenue", value: show.has_non_evergreen_revenue },
    { label: "Partner Ledger Access", value: show.requires_partner_access },
  ]

  const statusFlags = [
    { label: "Rate Card", value: show.rate_card },
    { label: "Original", value: show.is_original },
    { label: "Active", value: show.is_active },
    { label: "Undersized", value: show.is_undersized },
  ]

  const contractSplits = [
    { label: "Side Bonus", value: formatPercentage(show.side_bonus_percent) },
    { label: "YouTube Ads", value: formatPercentage(show.youtube_ads_percent) },
    { label: "Subscriptions", value: formatPercentage(show.subscriptions_percent) },
    { label: "Standard Ads", value: formatPercentage(show.standard_ads_percent) },
    { label: "Sponsorship (FP Lead)", value: formatPercentage(show.sponsorship_ad_fp_lead_percent) },
    {
      label: "Sponsorship (Partner Lead)",
      value: formatPercentage(show.sponsorship_ad_partner_lead_percent),
    },
    {
      label: "Sponsorship (Partner Sold)",
      value: formatPercentage(show.sponsorship_ad_partner_sold_percent),
    },
    { label: "Programmatic Ads", value: formatPercentage(show.programmatic_ads_span_percent) },
    { label: "Merchandise", value: formatPercentage(show.merchandise_percent) },
    { label: "Branded Revenue", value: formatPercentage(show.branded_revenue_percent) },
    {
      label: "Marketing Services",
      value: formatPercentage(show.marketing_services_revenue_percent),
    },
  ]

  const handsOffSplits = [
    { label: "Direct Customer", value: formatPercentage(show.direct_customer_hands_off_percent) },
    { label: "YouTube", value: formatPercentage(show.youtube_hands_off_percent) },
    { label: "Subscriptions", value: formatPercentage(show.subscription_hands_off_percent) },
  ]

  const animationClass =
    animationDirection === "next"
      ? "animate-in slide-in-from-right-8 fade-in-0 duration-300"
      : animationDirection === "previous"
      ? "animate-in slide-in-from-left-8 fade-in-0 duration-300"
      : "" // No slide animation on initial open

  const paginationButtonStyles = "variant-outline size-sm"

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className="max-w-none w-full sm:w-[90%] h-screen sm:max-h-[90vh] mobile-fullscreen flex flex-col p-0 overflow-hidden border-0 sm:overflow-y-auto"
        style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          maxHeight: '90vh',
          backgroundColor: isDark 
            ? "rgb(20, 20, 20)" 
            : "rgb(255, 255, 255)",
        }}
      >
        <DialogHeader className="flex flex-row items-center justify-between px-6 py-4 bg-muted/30 border-b">
          {/* Mobile: Title left, Close right */}
          <div className="flex sm:hidden w-full items-center justify-between gap-3">
            <DialogTitle className="text-lg font-semibold text-left truncate flex-1">
              {show.title}
            </DialogTitle>
            <DialogClose asChild>
              <Button variant="ghost" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 !gap-0 relative">
                <X className="h-4 w-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                <span className="sr-only">Close</span>
              </Button>
            </DialogClose>
          </div>

          {/* Desktop: Navigation, Title, Actions in one row */}
          <div className="hidden sm:flex flex-row items-center w-full relative">
          <div className="flex flex-none items-center gap-3 w-auto min-w-[140px]">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleNavigationClick("previous")}
                disabled={!hasPrevious}
                className="h-9 px-4 whitespace-nowrap"
              >
                <ChevronLeft className="h-4 w-4 mr-1.5" />
                Prev
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleNavigationClick("next")}
                disabled={!hasNext}
                className="h-9 px-4 whitespace-nowrap"
              >
                Next
                <ChevronRight className="h-4 w-4 ml-1.5" />
              </Button>
          </div>

          <DialogTitle className="absolute left-1/2 -translate-x-1/2 text-2xl font-semibold text-center truncate max-w-[60%] px-4">
            {show.title}
          </DialogTitle>

          <div className="flex flex-none justify-end items-center gap-3 w-auto ml-auto">
            {onEdit && show && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onEdit(show)}
                className="h-9 px-4 text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 border-blue-200 hover:border-blue-300 dark:border-blue-800 dark:hover:border-blue-700 dark:[&_svg]:text-blue-400 dark:hover:[&_svg]:text-blue-300"
              >
                <Edit className="h-4 w-4 mr-1.5" />
                Edit
              </Button>
            )}
            {onDelete && show && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onDelete(show)}
                className="h-9 px-4 action-button-delete"
              >
                <Trash2 className="h-4 w-4 mr-1.5" />
                Delete
              </Button>
            )}
            {onArchive && show && !isArchived && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onArchive(show)}
                className="h-9 px-4 action-button-archive"
              >
                <Archive className="h-4 w-4 mr-1.5" />
                Archive
              </Button>
            )}
            {onUnarchive && show && isArchived && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onUnarchive(show)}
                className="h-9 px-4 action-button-unarchive"
              >
                <RotateCcw className="h-4 w-4 mr-1.5" />
                Unarchive
              </Button>
            )}
            <DialogClose asChild>
              <Button variant="ghost" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 !gap-0 relative">
                <X className="h-4 w-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                <span className="sr-only">Close</span>
              </Button>
            </DialogClose>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea 
          className="flex-1 min-h-0"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          <div 
            key={show.id} 
            className={`grid grid-cols-1 lg:grid-cols-3 gap-6 p-6 transition-opacity duration-200 ${animationClass} ${isSwipeActive ? 'opacity-90' : 'opacity-100'}`}
          >
            {/* Column 1 */}
            <div className="space-y-6">
              <Card className="bg-white/90 dark:bg-[#1a1a1a]">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Info className="h-5 w-5 text-emerald-500" /> Basic Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Desktop Grid View */}
                  <div className="hidden sm:grid grid-cols-3 gap-x-6 gap-y-6">
                    <DetailItem label="Show Type" value={show.show_type} />
                    <DetailItem label="Format" value={show.media_type ? show.media_type.charAt(0).toUpperCase() + show.media_type.slice(1) : "N/A"} />
                    <DetailItem label="Relationship" value={show.relationship_level ? show.relationship_level.charAt(0).toUpperCase() + show.relationship_level.slice(1) : "N/A"} />
                    <DetailItem 
                      label="Ranking Category" 
                      value={(() => {
                        const rankingInfo = getRankingInfo(show.ranking_category);
                        return rankingInfo.hasRanking ? (
                          <Badge variant="secondary" className={rankingInfo.badgeClasses}>
                            {rankingInfo.displayText}
                          </Badge>
                        ) : "N/A";
                      })()} 
                    />
                    <DetailItem
                      label="Created Date"
                      value={show.start_date ? new Date(show.start_date).toLocaleDateString() : "N/A"}
                    />
                    <DetailItem label="Age" value={show.start_date ? `${Math.floor((new Date().getTime() - new Date(show.start_date).getTime()) / (1000 * 60 * 60 * 24 * 30))} months` : "N/A"} />
                    <div className="col-span-3">
                      <DetailItem label="Subnetwork" value={<span className="whitespace-nowrap">{show.subnetwork_id || "N/A"}</span>} />
                    </div>
                  </div>

                  {/* Mobile List View */}
                  <div className="sm:hidden space-y-2">
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Show Type</span>
                      <span className="text-sm">{show.show_type || "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Format</span>
                      <span className="text-sm">{show.media_type ? show.media_type.charAt(0).toUpperCase() + show.media_type.slice(1) : "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Relationship</span>
                      <span className="text-sm">{show.relationship_level ? show.relationship_level.charAt(0).toUpperCase() + show.relationship_level.slice(1) : "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Ranking Category</span>
                      <span className="text-sm">{(() => {
                        const rankingInfo = getRankingInfo(show.ranking_category);
                        return rankingInfo.hasRanking ? rankingInfo.displayText : "N/A";
                      })()}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Created Date</span>
                      <span className="text-sm">{show.start_date ? new Date(show.start_date).toLocaleDateString() : "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Age</span>
                      <span className="text-sm">{show.start_date ? `${Math.floor((new Date().getTime() - new Date(show.start_date).getTime()) / (1000 * 60 * 60 * 24 * 30))} months` : "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2">
                      <span className="text-sm font-medium text-muted-foreground">Subnetwork</span>
                      <span className="text-sm">{show.subnetwork_id || "N/A"}</span>
                    </div>
                  </div>

                  {/* Mobile Separator */}
                  <div className="sm:hidden border-t border-black/10 dark:border-white/10 my-3"></div>

                  <Separator className="my-4 dark:bg-slate-700" />

                  <div className="col-span-3">
                    <h4 className="font-semibold flex items-center gap-2 mb-3 text-base">
                      <Flag className="h-4 w-4" /> Status Flags
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {statusFlags.map((flag) => (
                        <Badge
                          key={flag.label}
                          className={`text-xs border pointer-events-none ${
                            flag.value
                              ? "bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/50 dark:text-emerald-300 dark:border-emerald-700"
                              : "bg-red-100 text-red-800 border-red-300 dark:bg-red-900/50 dark:text-red-300 dark:border-red-700"
                          }`}
                        >
                          {flag.label} - {flag.value ? "Yes" : "No"}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
              {/* Contact Information — collapsible with smooth slide - Desktop only */}
              <Card className="bg-white/90 dark:bg-[#1a1a1a] hidden lg:block">
                <Collapsible open={isContactOpen} onOpenChange={setIsContactOpen}>
                  {/* Clickable header (keeps your exact title style) */}
                  <CollapsibleTrigger asChild>
                    <CardHeader className="cursor-pointer">
                      <div className="flex items-center justify-between">
                        <CardTitle className="flex items-center gap-2 text-lg">
                          <Users className="h-5 w-5 text-emerald-500" />
                          Contact Information
                        </CardTitle>
                        <ChevronDown
                          className={`h-4 w-4 transition-transform duration-300 ${isContactOpen ? "rotate-180" : ""}`}
                          aria-hidden="true"
                        />
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>

                  {/* Slide down/up with grid-rows trick (no height:auto jank) */}
                  <CollapsibleContent asChild forceMount>
                    <div
                      className={`grid transition-all duration-300 ease-out ${
                        isContactOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
                      }`}
                    >
                      <div
                        className={`overflow-hidden min-h-0 transition-all duration-300 ease-out ${
                          isContactOpen ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-1"
                        }`}
                      >
                        <CardContent className="space-y-4">
                          <ContactCard title="Host Contact" contactString={show.show_host_contact} />
                          <Separator className="dark:bg-white/10" />
                          <ContactCard title="Show Primary Contact" contactString={show.show_primary_contact} />
                          <Separator className="dark:bg-white/10" />
                          <div>
                            <h5 className="font-semibold text-sm text-muted-foreground">Evergreen Production Staff</h5>
                            <div className="flex items-center gap-2 mt-1 text-sm">
                              <Users className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
                              <span>{show.evergreen_production_staff_name || "None"}</span>
                            </div>
                          </div>
                        </CardContent>
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              </Card>

            </div>

            {/* Column 2 */}
            <div className="space-y-6">
              <Card className="bg-white/90 dark:bg-[#1a1a1a]">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <DollarSign className="h-5 w-5 text-emerald-500" /> Financial Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Desktop Grid View */}
                  <div className="hidden sm:grid grid-cols-3 gap-6 mb-6">
                    <DetailItem label="EVG Ownership %" value={show.evergreen_ownership_pct ? `${show.evergreen_ownership_pct}%` : "N/A"} />
                    <DetailItem label="Span CPM" value={show.span_cpm_usd ? `$${show.span_cpm_usd}` : "N/A"} />
                    <DetailItem label="Latest CPM" value={show.latest_cpm_usd ? `$${show.latest_cpm_usd}` : "N/A"} />
                  </div>

                  {/* Mobile List View */}
                  <div className="sm:hidden space-y-2 mb-6">
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">EVG Ownership %</span>
                      <span className="text-sm">{show.evergreen_ownership_pct ? `${show.evergreen_ownership_pct}%` : "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Span CPM</span>
                      <span className="text-sm">{show.span_cpm_usd ? `$${show.span_cpm_usd}` : "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2">
                      <span className="text-sm font-medium text-muted-foreground">Latest CPM</span>
                      <span className="text-sm">{show.latest_cpm_usd ? `$${show.latest_cpm_usd}` : "N/A"}</span>
                    </div>
                  </div>
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-semibold flex items-center gap-2 mb-3 text-base">
                        <BarChart3 className="h-4 w-4" /> Revenue by Year
                      </h4>
                      {/* Desktop Grid View */}
                      <div className="hidden sm:grid grid-cols-3 gap-3">
                        <div className="text-center p-3 bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950/60 dark:to-emerald-900/60 rounded-lg border border-emerald-200 dark:border-emerald-700">
                          <p className="text-xs text-emerald-700 dark:text-emerald-200">2023</p>
                          <p className="text-base font-bold text-emerald-600 dark:text-emerald-300">
                            {formatCurrency(show.revenue_2023)}
                          </p>
                        </div>
                        <div className="text-center p-3 bg-gradient-to-br from-cyan-50 to-cyan-100 dark:from-cyan-950/60 dark:to-cyan-900/60 rounded-lg border border-cyan-200 dark:border-cyan-700">
                          <p className="text-xs text-cyan-700 dark:text-cyan-200">2024</p>
                          <p className="text-base font-bold text-cyan-600 dark:text-cyan-300">
                            {formatCurrency(show.revenue_2024)}
                          </p>
                        </div>
                        <div className="text-center p-3 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/60 dark:to-green-900/60 rounded-lg border border-green-200 dark:border-green-700">
                          <p className="text-xs text-green-700 dark:text-green-200">2025</p>
                          <p className="text-base font-bold text-green-600 dark:text-green-300">
                            {formatCurrency(show.revenue_2025)}
                          </p>
                        </div>
                      </div>

                      {/* Mobile List View */}
                      <div className="sm:hidden space-y-2">
                        <div className="flex justify-between items-center p-3 bg-gradient-to-r from-emerald-50 to-emerald-100 dark:from-emerald-950/60 dark:to-emerald-900/60 rounded-lg border border-emerald-200 dark:border-emerald-700">
                          <span className="text-sm font-medium text-emerald-700 dark:text-emerald-200">2023</span>
                          <span className="text-sm font-bold text-emerald-600 dark:text-emerald-300">{formatCurrency(show.revenue_2023)}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-gradient-to-r from-cyan-50 to-cyan-100 dark:from-cyan-950/60 dark:to-cyan-900/60 rounded-lg border border-cyan-200 dark:border-cyan-700">
                          <span className="text-sm font-medium text-cyan-700 dark:text-cyan-200">2024</span>
                          <span className="text-sm font-bold text-cyan-600 dark:text-cyan-300">{formatCurrency(show.revenue_2024)}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-gradient-to-r from-green-50 to-green-100 dark:from-green-950/60 dark:to-green-900/60 rounded-lg border border-green-200 dark:border-green-700">
                          <span className="text-sm font-medium text-green-700 dark:text-green-200">2025</span>
                          <span className="text-sm font-bold text-green-600 dark:text-green-300">{formatCurrency(show.revenue_2025)}</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold flex items-center gap-2 mb-3 text-base">
                        <Percent className="h-4 w-4" /> Revenue Split to Partner
                      </h4>
                      {/* Desktop Grid View */}
                      <div className="hidden sm:grid grid-cols-2 gap-3">
                        <div className="text-center p-3 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/60 dark:to-blue-900/60 rounded-lg border border-blue-200 dark:border-blue-700">
                          <p className="text-xs text-blue-700 dark:text-blue-200">Standard Ads</p>
                          <p className="text-base font-bold text-blue-600 dark:text-blue-300">
                            {show.standard_ads_percent ? `${show.standard_ads_percent}%` : "N/A"}
                          </p>
                        </div>
                        <div className="text-center p-3 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/60 dark:to-purple-900/60 rounded-lg border border-purple-200 dark:border-purple-700">
                          <p className="text-xs text-purple-700 dark:text-purple-200">Programmatic Ads</p>
                          <p className="text-base font-bold text-purple-600 dark:text-purple-300">
                            {show.programmatic_ads_span_percent ? `${show.programmatic_ads_span_percent}%` : "N/A"}
                          </p>
                        </div>
                      </div>

                      {/* Mobile List View */}
                      <div className="sm:hidden space-y-2">
                        <div className="flex justify-between items-center p-3 bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-950/60 dark:to-blue-900/60 rounded-lg border border-blue-200 dark:border-blue-700">
                          <span className="text-sm font-medium text-blue-700 dark:text-blue-200">Standard Ads</span>
                          <span className="text-sm font-bold text-blue-600 dark:text-blue-300">
                            {show.standard_ads_percent ? `${show.standard_ads_percent}%` : "N/A"}
                          </span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-gradient-to-r from-purple-50 to-purple-100 dark:from-purple-950/60 dark:to-purple-900/60 rounded-lg border border-purple-200 dark:border-purple-700">
                          <span className="text-sm font-medium text-purple-700 dark:text-purple-200">Programmatic Ads</span>
                          <span className="text-sm font-bold text-purple-600 dark:text-purple-300">
                            {show.programmatic_ads_span_percent ? `${show.programmatic_ads_span_percent}%` : "N/A"}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Separator className="my-4 dark:bg-slate-700" />

                  <div>
                    <h4 className="font-semibold flex items-center gap-2 mb-3 text-base">
                      <TrendingUp className="h-4 w-4" /> Revenue Flags
                    </h4>
                    {/* Only show flags that are true */}
                    <div className="flex flex-wrap gap-2">
                      {revenueFlags.filter((flag) => !!flag.value).length > 0 ? (
                        revenueFlags
                          .filter((flag) => !!flag.value)
                          .map((flag) => (
                            <Badge
                              key={flag.label}
                              className={`text-xs border pointer-events-none ${
                                flag.value
                                  ? "bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/50 dark:text-emerald-300 dark:border-emerald-700"
                                  : "bg-red-100 text-red-800 border-red-300 dark:bg-red-900/50 dark:text-red-300 dark:border-red-700"
                              }`}
                            >
                              {flag.label}
                            </Badge>
                          ))
                      ) : (
                        <p className="text-sm text-muted-foreground italic">
                          No Revenue Flags Available for this Show
                        </p>
                      )}
                    </div>

                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Column 3 */}
            <div className="space-y-6">
              {/* <Card className="dark:bg-[#262626]">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Percent className="h-5 w-5 text-gray-500" /> Financial Splits
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-sm text-muted-foreground mb-2">
                      Contract Splits
                    </h4>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                      {contractSplits.map((split) => (
                        <DetailItem key={split.label} label={split.label} value={split.value} />
                      ))}
                    </div>
                  </div>
                  <Separator className="dark:bg-slate-700" />
                  <div>
                    <h4 className="font-semibold text-sm text-muted-foreground mb-2">
                      Hands-Off Splits
                    </h4>
                    <div className="grid grid-cols-3 gap-x-4 gap-y-2">
                      {handsOffSplits.map((split) => (
                        <DetailItem key={split.label} label={split.label} value={split.value} />
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card> */}
              <Card className="bg-white/90 dark:bg-[#1a1a1a]">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Radio className="h-5 w-5 text-emerald-500" /> Content Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Desktop Grid View */}
                  <div className="hidden sm:grid grid-cols-2 gap-6">
                    <DetailItem label="Genre" value={show.genre_name} />
                    <DetailItem label="Cadence" value={show.cadence} />
                    <DetailItem label="Ad Slots" value={show.ad_slots} />
                    <DetailItem label="Average Length" value={show.avg_show_length_mins ? `${show.avg_show_length_mins} min` : "N/A"} />
                  </div>

                  {/* Mobile List View */}
                  <div className="sm:hidden space-y-2">
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Genre</span>
                      <span className="text-sm">{show.genre_name || "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Cadence</span>
                      <span className="text-sm">{show.cadence || "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Ad Slots</span>
                      <span className="text-sm">{show.ad_slots || "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2">
                      <span className="text-sm font-medium text-muted-foreground">Average Length</span>
                      <span className="text-sm">{show.avg_show_length_mins ? `${show.avg_show_length_mins} min` : "N/A"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white/90 dark:bg-[#1a1a1a]">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Target className="h-5 w-5 text-emerald-500" /> Demographics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Desktop Grid View */}
                  <div className="hidden sm:grid grid-cols-3 gap-4">
                    <DetailItem label="Age" value={show.age_demographic} />
                    <DetailItem label="Gender (M/F)" value={show.gender} />
                    <DetailItem label="Region" value={show.region} />
                    <DetailItem label="Primary Education" value={show.primary_education} />
                    <DetailItem label="Secondary Education" value={show.secondary_education} />
                  </div>

                  {/* Mobile List View */}
                  <div className="sm:hidden space-y-2">
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Age</span>
                      <span className="text-sm">{show.age_demographic || "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Gender (M/F)</span>
                      <span className="text-sm">{show.gender || "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Region</span>
                      <span className="text-sm">{show.region || "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">Primary Education</span>
                      <span className="text-sm">{show.primary_education || "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2">
                      <span className="text-sm font-medium text-muted-foreground">Secondary Education</span>
                      <span className="text-sm">{show.secondary_education || "N/A"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white/90 dark:bg-[#1a1a1a]">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <BookOpenCheck className="h-5 w-5 text-emerald-500" /> QuickBooks Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="hidden sm:grid grid-cols-2 gap-4">
                    <DetailItem label="QBO Show Name" value={show.qbo_show_name ?? "N/A"} />
                    <DetailItem label="QBO Show ID" value={show.qbo_show_id != null ? String(show.qbo_show_id) : "N/A"} />
                  </div>
                  <div className="sm:hidden space-y-2">
                    <div className="flex justify-between items-center p-2 border-b border-black/10 dark:border-white/10">
                      <span className="text-sm font-medium text-muted-foreground">QBO Show Name</span>
                      <span className="text-sm">{show.qbo_show_name || "N/A"}</span>
                    </div>
                    <div className="flex justify-between items-center p-2">
                      <span className="text-sm font-medium text-muted-foreground">QBO Show ID</span>
                      <span className="text-sm">{show.qbo_show_id != null ? String(show.qbo_show_id) : "N/A"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Contact Information - moved to bottom for mobile only */}
            <div className="lg:col-span-3 lg:hidden">
              <Card className="bg-white/90 dark:bg-[#1a1a1a]">
                <Collapsible open={isContactOpen} onOpenChange={setIsContactOpen}>
                  {/* Clickable header (keeps your exact title style) */}
                  <CollapsibleTrigger asChild>
                    <CardHeader className="cursor-pointer">
                      <div className="flex items-center justify-between">
                        <CardTitle className="flex items-center gap-2 text-lg">
                          <Users className="h-5 w-5 text-emerald-500" />
                          Contact Information
                        </CardTitle>
                        <ChevronDown
                          className={`h-4 w-4 transition-transform duration-300 ${isContactOpen ? "rotate-180" : ""}`}
                          aria-hidden="true"
                        />
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>

                  {/* Slide down/up with grid-rows trick (no height:auto jank) */}
                  <CollapsibleContent asChild forceMount>
                    <div
                      className={`grid transition-all duration-300 ease-out ${
                        isContactOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
                      }`}
                    >
                      <div
                        className={`overflow-hidden min-h-0 transition-all duration-300 ease-out ${
                          isContactOpen ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-1"
                        }`}
                      >
                        <CardContent className="space-y-4">
                          <ContactCard title="Host Contact" contactString={show.show_host_contact} />
                          <Separator className="dark:bg-white/10" />
                          <ContactCard title="Show Primary Contact" contactString={show.show_primary_contact} />
                          <Separator className="dark:bg-white/10" />
                          <div>
                            <h5 className="font-semibold text-sm text-muted-foreground">Evergreen Production Staff</h5>
                            <div className="flex items-center gap-2 mt-1 text-sm">
                              <Users className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
                              <span>{show.evergreen_production_staff_name || "None"}</span>
                            </div>
                          </div>
                        </CardContent>
                      </div>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              </Card>
            </div>
          </div>
        </ScrollArea>
        
        {/* Mobile Footer - Navigation and Actions */}
        <div className="sm:hidden border-t bg-muted/30 px-6 py-3">
          {/* First line: Navigation and Action buttons */}
          <div className="flex items-center justify-between gap-3">
            {/* Left: Arrow buttons - Circular */}
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleNavigationClick("previous")}
                disabled={!hasPrevious}
                className="h-9 w-9 rounded-full p-0"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleNavigationClick("next")}
                disabled={!hasNext}
                className="h-9 w-9 rounded-full p-0"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>

            {/* Right: Action buttons */}
            <div className="flex items-center gap-2">
              {onEdit && show && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onEdit(show)}
                  className="h-9 px-3 text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 border-blue-200 hover:border-blue-300 dark:border-blue-800 dark:hover:border-blue-700"
                >
                  Edit
                </Button>
              )}
              {onDelete && show && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onDelete(show)}
                  className="h-9 px-3 action-button-delete"
                >
                  Delete
                </Button>
              )}
              {onArchive && show && !isArchived && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onArchive(show)}
                  className="h-9 px-3 text-orange-600 dark:text-orange-400 hover:text-orange-700 dark:hover:text-orange-300 hover:bg-orange-50 dark:hover:bg-orange-900/20 border-orange-200 hover:border-orange-300 dark:border-orange-800 dark:hover:border-orange-700"
                >
                  Archive
                </Button>
              )}
              {onUnarchive && show && isArchived && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onUnarchive(show)}
                  className="h-9 px-3 action-button-unarchive"
                >
                  Unarchive
                </Button>
              )}
            </div>
          </div>

          {/* Separator line */}
          <div className="border-t border-muted-foreground/20 my-3"></div>

          {/* Second line: Created by and Archived by info */}
        {show && (
            <div className="flex flex-col gap-2 text-sm text-muted-foreground items-center">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span>
                  Created by <span className="font-medium">{getUserName(show.created_by_id, show.created_by)}</span> on{' '}
                  <span className="font-medium">
                    {show.created_at ? `${new Date(show.created_at).toLocaleDateString()}, ${new Date(show.created_at).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' })}` : 'Unknown date'}
                  </span>
                </span>
              </div>
              {isArchived && (
                <>
                  <div className="border-t border-muted-foreground/20 w-full my-1"></div>
                  <div className="flex items-center gap-2">
                    <Archive className="h-4 w-4" />
                    <span>
                      Archived by <span className="font-medium">{getUserName(show.archived_by_id, show.archived_by)}</span> on{' '}
                      <span className="font-medium">
                        {show.archived_at ? `${new Date(show.archived_at).toLocaleDateString()}, ${new Date(show.archived_at).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' })}` : 'Unknown date'}
                      </span>
                    </span>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {/* Desktop Footer - Show creation and archive info */}
        {show && (
          <div className="hidden sm:block border-t bg-muted/30 px-6 py-3">
            <div className="flex items-center justify-center">
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <span>
                    Created by <span className="font-medium">{getUserName(show.created_by_id, show.created_by)}</span> on{' '}
                    <span className="font-medium">
                      {show.created_at ? `${new Date(show.created_at).toLocaleDateString()}, ${new Date(show.created_at).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' })}` : 'Unknown date'}
                    </span>
                  </span>
                </div>
                {isArchived && (
                  <>
                    <span className="text-muted-foreground/50">|</span>
                    <div className="flex items-center gap-2">
                      <Archive className="h-4 w-4" />
                      <span>
                        Archived by <span className="font-medium">{getUserName(show.archived_by_id, show.archived_by)}</span> on{' '}
                        <span className="font-medium">
                          {show.archived_at ? `${new Date(show.archived_at).toLocaleDateString()}, ${new Date(show.archived_at).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' })}` : 'Unknown date'}
                        </span>
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>

    </>
  )
}