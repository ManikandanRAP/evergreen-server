"use client"

import type React from "react"
import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription, DialogClose } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Download, Upload, Loader2, FileText, AlertCircle, BookOpen, CheckCircle, Eye, ArrowLeft, ChevronUp, ChevronDown, ArrowUpDown, X } from "lucide-react"
import Papa from "papaparse"
import { apiClient, ShowCreate, DuplicateCheckResult, DuplicateAction } from "@/lib/api-client"

// Map lowercased CSV show_type to canonical values
const SHOW_TYPE_MAP: Record<string, "Original" | "Branded" | "Partner" | "Hybrid"> = {
  original: "Original",
  branded: "Branded",
  partner: "Partner",
  hybrid: "Hybrid",
};

// Map lowercased CSV cadence to canonical values
const CADENCE_MAP: Record<string, "Daily" | "Weekly" | "Biweekly" | "Monthly" | "Ad hoc"> = {
  daily: "Daily",
  weekly: "Weekly",
  biweekly: "Biweekly",
  monthly: "Monthly",
  "ad hoc": "Ad hoc",
  adhoc: "Ad hoc",
};

// Map lowercased CSV region to canonical values
const REGION_MAP: Record<string, "Urban" | "Rural" | "Both"> = {
  urban: "Urban",
  rural: "Rural",
  both: "Both",
};

// Map user-friendly CSV headers to database column names
const CSV_HEADER_MAPPING: Record<string, string> = {
  // 1. Core Show Information (Most Important)
  "Show Name": "title",
  "Show Type": "show_type", 
  "Format": "media_type",
  "Ranking Category": "ranking_category",
  "Is Original Content": "is_original",
  "Is Rate Card Show": "rate_card",
  
  // 2. Business & Relationship Details
  "Relationship": "relationship_level",
  "Start Date": "start_date", 
  "Minimum Guarantee": "minimum_guarantee",
  "Ownership by Evergreen (%)": "evergreen_ownership_pct",
  "Cadence": "cadence",
  
  // 3. Content & Audience
  "Genre": "genre_name",
  "Age Demographic": "age_demographic",
  "Gender Demographic (M/F)": "gender",
  "Region Demographic": "region",
  "Average Length (Minutes)": "avg_show_length_mins",
  "Ad Slots": "ad_slots",
  
  // 4. Financial Data
  "Span CPM": "span_cpm_usd",
  "Latest CPM": "latest_cpm_usd",
  "Revenue 2023": "revenue_2023",
  "Revenue 2024": "revenue_2024", 
  "Revenue 2025": "revenue_2025",
  
  // 5. Revenue Distribution Percentages (with standard_ads_percent and programmatic_ads_span_percent first)
  "Standard Ads (%)": "standard_ads_percent",
  "Programmatic Ads/Span (%)": "programmatic_ads_span_percent",
  "Side Bonus (%)": "side_bonus_percent",
  "YouTube Ads (%)": "youtube_ads_percent",
  "Subscriptions (%)": "subscriptions_percent",
  "Sponsorship Ad FP - Lead (%)": "sponsorship_ad_fp_lead_percent",
  "Sponsorship Ad - Partner Lead (%)": "sponsorship_ad_partner_lead_percent",
  "Sponsorship Ad - Partner Sold (%)": "sponsorship_ad_partner_sold_percent",
  "Merchandise (%)": "merchandise_percent",
  "Branded Revenue (%)": "branded_revenue_percent",
  "Marketing Services Revenue (%)": "marketing_services_revenue_percent",
  
  // 6. Hands-off Percentages
  "Direct Customer - Hands Off (%)": "direct_customer_hands_off_percent",
  "YouTube - Hands Off (%)": "youtube_hands_off_percent",
  "Subscription - Hands Off (%)": "subscription_hands_off_percent",
  
  // 7. Contact Information
  "Primary Contact (Show)": "show_primary_contact",
  "Primary Contact (Host)": "show_host_contact",
  "Evergreen Production Staff Name": "evergreen_production_staff_name",
  
  // 8. System & Operational
  "Subnetwork Name": "subnetwork_id",
  "Is Active": "is_active",
  "Is Undersized": "is_undersized",
  "Primary Education Demographic": "primary_education",
  "Secondary Education Demographic": "secondary_education",
  
  // 9. Revenue Flags
  "Has Sponsorship Revenue": "has_sponsorship_revenue",
  "Has Non Evergreen Revenue": "has_non_evergreen_revenue",
  "Has Partner Ledger Access": "requires_partner_access",
  "Has Branded Revenue": "has_branded_revenue",
  "Has Marketing Revenue": "has_marketing_revenue",
  "Has Web Management Revenue": "has_web_mgmt_revenue",
  
  // 10. Integration Data
  "QBO Show Name": "qbo_show_name",
  "QBO Show ID": "qbo_show_id"
};


interface ImportCSVDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onImportComplete: (result: { success: boolean, message: string, errors?: string[], warnings?: string[] }) => void
}

interface ImportPreviewRow {
  title: string
  action: "create" | "update" | "skip"
  isDuplicate: boolean
  existingShow?: any
  showData: ShowCreate
}

/** Structured validation error for table display */
interface ValidationErrorTable {
  summary: string
  rows: Array<{ rowNum: number; showTitle: string; invalidValue: string; suggestion: string | null }>
  allowedGenres: string
  tip: string
}

// User-friendly CSV headers for the template
const CSV_HEADERS = [
  // 1. Core Show Information (Most Important)
  "Show Name", "Show Type", "Format", "Ranking Category", "Is Original Content", "Is Rate Card Show",
  
  // 2. Business & Relationship Details
  "Relationship", "Start Date", "Minimum Guarantee", "Ownership by Evergreen (%)", "Cadence",
  
  // 3. Content & Audience
  "Genre", "Age Demographic", "Gender Demographic (M/F)", "Region Demographic", "Average Length (Minutes)", "Ad Slots",
  
  // 4. Financial Data
  "Span CPM", "Latest CPM", "Revenue 2023", "Revenue 2024", "Revenue 2025",
  
  // 5. Revenue Distribution Percentages (with standard_ads_percent and programmatic_ads_span_percent first)
  "Standard Ads (%)", "Programmatic Ads/Span (%)", "Side Bonus (%)", "YouTube Ads (%)",
  "Subscriptions (%)", "Sponsorship Ad FP - Lead (%)", "Sponsorship Ad - Partner Lead (%)", 
  "Sponsorship Ad - Partner Sold (%)", "Merchandise (%)", "Branded Revenue (%)",
  "Marketing Services Revenue (%)",
  
  // 6. Hands-off Percentages
  "Direct Customer - Hands Off (%)", "YouTube - Hands Off (%)", "Subscription - Hands Off (%)",
  
  // 7. Contact Information
  "Primary Contact (Show)", "Primary Contact (Host)", "Evergreen Production Staff Name",
  
  // 8. System & Operational
  "Subnetwork Name", "Is Active", "Is Undersized", "Primary Education Demographic", "Secondary Education Demographic",
  
  // 9. Revenue Flags
  "Has Sponsorship Revenue", "Has Non Evergreen Revenue", "Has Partner Ledger Access",
  "Has Branded Revenue", "Has Marketing Revenue", "Has Web Management Revenue",
  
  // 10. Integration Data
  "QBO Show Name", "QBO Show ID"
];

// Allowed Genre values (must match server GENRE_MAP). "Arts" in CSV maps to "Arts & Culture".
const ALLOWED_GENRES = [
  "History", "Human Resources", "Human Interest", "Fun & Nostalgia", "True Crime", "Financial",
  "News & Politics", "Movies", "Music", "Religious", "Health & Wellness", "Parenting", "Lifestyle",
  "Storytelling", "Literature", "Sports", "Pop Culture", "Arts & Culture", "Business", "Philosophy",
  "Self-Help", "Marketing", "Law",
];

/** Get suggested allowed genre for an invalid value via universal partial match (e.g. "Health" → "Health & Wellness", "Movie" → "Movies", "finance" → "Financial"). */
function getGenreSuggestion(invalidValue: string): string | null {
  const normalized = invalidValue.trim().toLowerCase().replace(/\s+/g, " ")
  for (const allowed of ALLOWED_GENRES) {
    const allowedNorm = allowed.toLowerCase().replace(/\s+/g, " ")
    if (allowedNorm === normalized) return allowed
    if (allowedNorm.startsWith(normalized) || normalized.startsWith(allowedNorm)) return allowed
    if (allowedNorm.includes(normalized) || normalized.includes(allowedNorm)) return allowed
  }
  return null
}

export default function ImportCSVDialog({ open, onOpenChange, onImportComplete }: ImportCSVDialogProps) {
  const router = useRouter()
  const [file, setFile] = useState<File | null>(null)
  const [isImporting, setIsImporting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [dragActive, setDragActive] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  // New state for enhanced import flow
  const [showsToImport, setShowsToImport] = useState<ShowCreate[]>([])
  const [duplicateCheckResults, setDuplicateCheckResults] = useState<DuplicateCheckResult[]>([])
  const [importPreview, setImportPreview] = useState<ImportPreviewRow[]>([])
  
  // Sorting state - using same pattern as revenue ledger
  type SortDirection = "asc" | "desc" | null
  type SortConfig = { key: string; direction: SortDirection }
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: "", direction: null })
  const [showPreview, setShowPreview] = useState(false)
  const [validationError, setValidationError] = useState<ValidationErrorTable | null>(null)

  /** Build structured validation error for table display. Supports both loc shapes. */
  const buildValidationErrorTable = (
    validationDetails: Array<{ loc?: unknown[]; msg?: string }>,
    showsList: ShowCreate[],
    summary: string
  ): ValidationErrorTable => {
    const rows: ValidationErrorTable["rows"] = []
    const fieldLabel: Record<string, string> = { genre_name: "Genre", start_date: "Start date", ranking_category: "Ranking category" }
    for (const item of validationDetails) {
      const loc = item?.loc
      if (!Array.isArray(loc) || loc.length < 3) continue
      const isNested = loc[1] === "shows_data" && loc.length >= 4
      const bodyIndex = isNested ? loc[2] : loc[1]
      const field = isNested ? loc[3] : loc[2]
      const rowNum = typeof bodyIndex === "number" ? bodyIndex + 1 : Number(bodyIndex)
      const fieldName = typeof field === "string" ? field : ""
      const show = typeof bodyIndex === "number" ? showsList[bodyIndex] : undefined
      const showTitle = show?.title ?? ""
      const value = show && fieldName && fieldName in show ? (show as unknown as Record<string, unknown>)[fieldName] : undefined
      const invalidValue = value !== undefined && value !== null && value !== "" ? String(value) : "invalid value"
      let suggestion: string | null = null
      if (fieldName === "genre_name" && value !== undefined && value !== null && String(value).trim()) {
        suggestion = getGenreSuggestion(String(value))
      }
      rows.push({ rowNum, showTitle, invalidValue, suggestion })
    }
    return {
      summary,
      rows,
      allowedGenres: ALLOWED_GENRES.join(", "),
      tip: "Use one of the allowed values above, or see the Import Guide / template for more details. If you need to add a new genre, please contact support.",
    }
  }

  /** Build a user-friendly validation error string (fallback when not using table). */
  const formatValidationErrorForImport = (
    validationDetails: Array<{ loc?: unknown[]; msg?: string }>,
    showsList: ShowCreate[]
  ): string => {
    const lines: string[] = []
    const fieldLabel: Record<string, string> = { genre_name: "Genre", start_date: "Start date", ranking_category: "Ranking category" }
    for (const item of validationDetails) {
      const loc = item?.loc
      const msg = item?.msg ?? ""
      if (!Array.isArray(loc) || loc.length < 3) {
        lines.push(msg || "Validation error")
        continue
      }
      // loc can be ["body", index, field] or ["body", "shows_data", index, field]
      const isNested = loc[1] === "shows_data" && loc.length >= 4
      const bodyIndex = isNested ? loc[2] : loc[1]
      const field = isNested ? loc[3] : loc[2]
      const rowNum = typeof bodyIndex === "number" ? bodyIndex + 1 : bodyIndex
      const fieldName = typeof field === "string" ? field : ""
      const show = typeof bodyIndex === "number" ? showsList[bodyIndex] : undefined
      const showTitle = show?.title ? ` – ${show.title}` : ""
      const fieldLabelName = fieldLabel[fieldName] || fieldName
      const value = show && fieldName && fieldName in show ? (show as unknown as Record<string, unknown>)[fieldName] : undefined
      const valueStr = value !== undefined && value !== null && value !== "" ? `'${String(value)}'` : "invalid value"
      let line = `Row ${rowNum}${showTitle} – ${fieldLabelName} ${valueStr} is not in the allowed list.`
      if (fieldName === "genre_name" && value !== undefined && value !== null && String(value).trim()) {
        const suggestion = getGenreSuggestion(String(value))
        if (suggestion) line += ` (Did you mean: ${suggestion}?)`
      }
      lines.push(line)
    }
    lines.push("")
    lines.push("Allowed genres: " + ALLOWED_GENRES.join(", "))
    lines.push("")
    lines.push("Tip: Use one of the allowed values above, or see the Import Guide / template for more details. If you need to add a new genre, please contact support.")
    return lines.join("\n")
  }

  // Reset dialog state when closed
  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      // Reset all state when dialog is closed
      setFile(null)
      setError(null)
      setValidationError(null)
      setShowsToImport([])
      setDuplicateCheckResults([])
      setImportPreview([])
      setShowPreview(false)
      setSortConfig({ key: "", direction: null })
      setIsImporting(false)
      setIsCheckingDuplicates(false)
    }
    onOpenChange(newOpen)
  }
  
  // Handle sorting - same pattern as revenue ledger
  const handleSort = (key: string) => {
    let dir: SortDirection = "asc"
    if (sortConfig.key === key) {
      dir = sortConfig.direction === "asc" ? "desc" : sortConfig.direction === "desc" ? null : "asc"
    }
    setSortConfig({ key: dir ? key : "", direction: dir })
  }
  
  // Sort data function - same pattern as revenue ledger
  const sortData = <T extends Record<string, any>>(data: T[], cfg: SortConfig): T[] => {
    if (!cfg.direction || !cfg.key) return data
    return [...data].sort((a, b) => {
      let aValue: any
      let bValue: any
      
      if (cfg.key === 'title') {
        aValue = a.title?.toLowerCase() || ''
        bValue = b.title?.toLowerCase() || ''
      } else if (cfg.key === 'status') {
        aValue = a.isDuplicate ? 'duplicate' : 'new'
        bValue = b.isDuplicate ? 'duplicate' : 'new'
      } else {
        return 0
      }
      
      if (aValue < bValue) return cfg.direction === "asc" ? -1 : 1
      if (aValue > bValue) return cfg.direction === "asc" ? 1 : -1
      return 0
    })
  }
  
  // Get sorted preview data
  const getSortedPreview = () => sortData(importPreview, sortConfig)
  
  // Render sort icon - same pattern as revenue ledger
  const renderSortIcon = (key: string) => {
    if (sortConfig.key !== key || !sortConfig.direction) {
      return <ArrowUpDown className="ml-2 h-4 w-4 text-muted-foreground" />
    }
    return sortConfig.direction === "asc" ? (
      <ChevronUp className="ml-2 h-4 w-4 text-primary" />
    ) : (
      <ChevronDown className="ml-2 h-4 w-4 text-primary" />
    )
  }
  
  const [isCheckingDuplicates, setIsCheckingDuplicates] = useState(false)

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const processFile = (droppedFile: File) => {
    if (droppedFile && (droppedFile.type === "text/csv" || droppedFile.name.endsWith(".csv"))) {
      setFile(droppedFile)
      setError(null)
      // Reset enhanced import state
      setShowsToImport([])
      setDuplicateCheckResults([])
      setImportPreview([])
      setShowPreview(false)
    } else {
      setValidationError(null)
      setError("Invalid file type. Please upload a CSV file.")
      setFile(null)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0])
    }
  }
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0])
    }
  }

  const handleDownloadTemplate = () => {
    const csv = Papa.unparse([CSV_HEADERS]);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", "shows_import_template.csv")
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }
  

  // Helper function to map user-friendly headers to database column names
  const mapHeadersToDbColumns = (row: any): any => {
    const mappedRow: any = {};
    for (const [userFriendlyHeader, dbColumn] of Object.entries(CSV_HEADER_MAPPING)) {
      if (row[userFriendlyHeader] !== undefined) {
        mappedRow[dbColumn] = row[userFriendlyHeader];
      }
    }
    return mappedRow;
  };

  const parseCSVData = (data: any[]): { shows: ShowCreate[], errors: string[] } => {
    const shows: ShowCreate[] = [];
    const errors: string[] = [];

    // Normalize numeric strings: remove commas (e.g. "8,800.00" -> 8800, "47,000.00" -> 47000)
    const normalizeNumericString = (v: unknown): string => {
      if (v === undefined || v === null) return "";
      return String(v).trim().replace(/,/g, "");
    };
    const safeFloat = (v: unknown): number | undefined => {
      const s = normalizeNumericString(v);
      if (s === "") return undefined;
      const n = parseFloat(s);
      return !isNaN(n) && isFinite(n) ? n : undefined;
    };
    const safeInt = (v: unknown): number | undefined => {
      const s = normalizeNumericString(v);
      if (s === "") return undefined;
      const n = parseInt(s, 10);
      return !isNaN(n) && Number.isInteger(n) ? n : undefined;
    };

    for (let i = 0; i < data.length; i++) {
      const row = data[i];
      const rowNum = i + 2;

      // Map user-friendly headers to database column names
      const mappedRow = mapHeadersToDbColumns(row);

      if (!mappedRow.title || mappedRow.title.trim() === "") {
        errors.push(`Row ${rowNum}: Missing required field 'Show Name'.`);
        continue;
      }

      // Case-insensitive enum validation
      const mediaVal = mappedRow.media_type !== undefined
        ? String(mappedRow.media_type).trim().toLowerCase()
        : undefined;

      const relVal = mappedRow.relationship_level !== undefined
        ? String(mappedRow.relationship_level).trim().toLowerCase()
        : undefined;

      const showTypeKey = mappedRow.show_type !== undefined
        ? String(mappedRow.show_type).trim().toLowerCase()
        : undefined;

      const cadenceKey = mappedRow.cadence !== undefined
        ? String(mappedRow.cadence).trim().toLowerCase()
        : undefined;

      const regionKey = mappedRow.region !== undefined
        ? String(mappedRow.region).trim().toLowerCase()
        : undefined;

      if (mappedRow.media_type) {
        if (!["video", "audio", "both"].includes(mediaVal as string)) {
          errors.push(`Row ${rowNum}: Invalid value for 'Format'. Must be one of: Video, Audio, Both.`);
        }
      }
      if (mappedRow.relationship_level) {
        if (!["strong", "medium", "weak"].includes(relVal as string)) {
          errors.push(`Row ${rowNum}: Invalid value for 'Relationship'. Must be one of: Strong, Medium, Weak.`);
        }
      }
      if (mappedRow.show_type) {
        if (!showTypeKey || !["original", "branded", "partner", "hybrid"].includes(showTypeKey)) {
          errors.push(`Row ${rowNum}: Invalid value for 'Show Type'. Must be one of: Original, Branded, Partner, Hybrid.`);
        }
      }

      // Validate ranking_category
      if (mappedRow.ranking_category) {
        const rankingVal = String(mappedRow.ranking_category).trim().toLowerCase();
        // Extract number from various formats: "1", "Level 1", "level 1", etc.
        const rankingMatch = rankingVal.match(/(?:level\s*)?(\d+)/);
        const rankingNumber = rankingMatch ? rankingMatch[1] : rankingVal;
        
        if (!["1", "2", "3", "4", "5"].includes(rankingNumber)) {
          errors.push(`Row ${rowNum}: Invalid value for 'Ranking Category'. Must be one of: 1, 2, 3, 4, 5, Level 1, Level 2, etc.`);
        }
      }

      // Validate cadence
      if (mappedRow.cadence) {
        if (!cadenceKey || !["daily", "weekly", "biweekly", "monthly", "ad hoc", "adhoc"].includes(cadenceKey)) {
          errors.push(`Row ${rowNum}: Invalid value for 'Cadence'. Must be one of: Daily, Weekly, Biweekly, Monthly, Ad hoc.`);
        }
      }

      // Validate region
      if (mappedRow.region) {
        if (!regionKey || !["urban", "rural", "both"].includes(regionKey)) {
          errors.push(`Row ${rowNum}: Invalid value for 'Region Demographic'. Must be one of: Urban, Rural, Both.`);
        }
      }

      const numericFields = [
        "evergreen_ownership_pct", "span_cpm_usd", "latest_cpm_usd", "revenue_2023", "revenue_2024", "revenue_2025",
        "ad_slots", "avg_show_length_mins", "side_bonus_percent", "youtube_ads_percent",
        "subscriptions_percent", "standard_ads_percent", "sponsorship_ad_fp_lead_percent",
        "sponsorship_ad_partner_lead_percent", "sponsorship_ad_partner_sold_percent",
        "programmatic_ads_span_percent", "merchandise_percent", "branded_revenue_percent",
        "marketing_services_revenue_percent", "direct_customer_hands_off_percent",
        "youtube_hands_off_percent", "subscription_hands_off_percent"
      ];

      for (const field of numericFields) {
        if (mappedRow[field] && isNaN(parseFloat(mappedRow[field]))) {
          // Find the user-friendly header name for this field
          const userFriendlyName = Object.entries(CSV_HEADER_MAPPING).find(([_, dbCol]) => dbCol === field)?.[0] || field;
          errors.push(`Row ${rowNum}: Invalid number for '${userFriendlyName}'.`);
        }
        if (field.includes('_percent') || field === 'evergreen_ownership_pct') {
          const val = parseFloat(mappedRow[field]);
          if (!isNaN(val) && (val < 0 || val > 100)) {
            const userFriendlyName = Object.entries(CSV_HEADER_MAPPING).find(([_, dbCol]) => dbCol === field)?.[0] || field;
            errors.push(`Row ${rowNum}: Value for '${userFriendlyName}' must be between 0 and 100.`);
          }
        }
      }

      if (errors.length > 0) continue;

      // Create ShowCreate object
      const show: ShowCreate = {
        title: mappedRow.title,
        show_type: showTypeKey ? SHOW_TYPE_MAP[showTypeKey] : undefined,
        media_type: mediaVal ? (mediaVal as "video" | "audio" | "both") : undefined,
        relationship_level: relVal ? (relVal as "strong" | "medium" | "weak") : undefined,
        start_date: (mappedRow.start_date && String(mappedRow.start_date).trim()) ? String(mappedRow.start_date).trim() : undefined,
        minimum_guarantee: mappedRow.minimum_guarantee?.toLowerCase() === 'yes' || mappedRow.minimum_guarantee?.toLowerCase() === 'true' || false,
        evergreen_ownership_pct: safeFloat(mappedRow.evergreen_ownership_pct),
        genre_name: mappedRow.genre_name || undefined,
        cadence: cadenceKey ? CADENCE_MAP[cadenceKey] : undefined,
        show_primary_contact: mappedRow.show_primary_contact || undefined,
        age_demographic: mappedRow.age_demographic || undefined,
        subnetwork_id: mappedRow.subnetwork_id || undefined,
        rate_card: mappedRow.rate_card?.toLowerCase() === 'yes' || mappedRow.rate_card?.toLowerCase() === 'true' || false,
        is_original: mappedRow.is_original?.toLowerCase() === 'yes' || mappedRow.is_original?.toLowerCase() === 'true' || false,
        ranking_category: mappedRow.ranking_category ? (() => {
          const rankingVal = String(mappedRow.ranking_category).trim().toLowerCase();
          const rankingMatch = rankingVal.match(/(?:level\s*)?(\d+)/);
          const rankingNumber = rankingMatch ? rankingMatch[1] : rankingVal;
          return rankingNumber as "1" | "2" | "3" | "4" | "5";
        })() : undefined,
        span_cpm_usd: safeFloat(mappedRow.span_cpm_usd),
        latest_cpm_usd: safeFloat(mappedRow.latest_cpm_usd),
        revenue_2023: safeFloat(mappedRow.revenue_2023),
        revenue_2024: safeFloat(mappedRow.revenue_2024),
        revenue_2025: safeFloat(mappedRow.revenue_2025),
        ad_slots: safeInt(mappedRow.ad_slots),
        avg_show_length_mins: safeInt(mappedRow.avg_show_length_mins),
        gender: mappedRow.gender || undefined,
        region: regionKey ? REGION_MAP[regionKey] : undefined,
        is_active: mappedRow.is_active ? mappedRow.is_active.toLowerCase() !== 'no' && mappedRow.is_active.toLowerCase() !== 'false' : true,
        is_undersized: mappedRow.is_undersized?.toLowerCase() === 'yes' || mappedRow.is_undersized?.toLowerCase() === 'true' || false,
        show_host_contact: mappedRow.show_host_contact || undefined,
        evergreen_production_staff_name: mappedRow.evergreen_production_staff_name || undefined,
        side_bonus_percent: safeFloat(mappedRow.side_bonus_percent),
        youtube_ads_percent: safeFloat(mappedRow.youtube_ads_percent),
        subscriptions_percent: safeFloat(mappedRow.subscriptions_percent),
        standard_ads_percent: safeFloat(mappedRow.standard_ads_percent),
        sponsorship_ad_fp_lead_percent: safeFloat(mappedRow.sponsorship_ad_fp_lead_percent),
        sponsorship_ad_partner_lead_percent: safeFloat(mappedRow.sponsorship_ad_partner_lead_percent),
        sponsorship_ad_partner_sold_percent: safeFloat(mappedRow.sponsorship_ad_partner_sold_percent),
        programmatic_ads_span_percent: safeFloat(mappedRow.programmatic_ads_span_percent),
        merchandise_percent: safeFloat(mappedRow.merchandise_percent),
        branded_revenue_percent: safeFloat(mappedRow.branded_revenue_percent),
        marketing_services_revenue_percent: safeFloat(mappedRow.marketing_services_revenue_percent),
        direct_customer_hands_off_percent: safeFloat(mappedRow.direct_customer_hands_off_percent),
        youtube_hands_off_percent: safeFloat(mappedRow.youtube_hands_off_percent),
        subscription_hands_off_percent: safeFloat(mappedRow.subscription_hands_off_percent),
        has_sponsorship_revenue: mappedRow.has_sponsorship_revenue?.toLowerCase() === 'yes' || mappedRow.has_sponsorship_revenue?.toLowerCase() === 'true' || false,
        has_non_evergreen_revenue: mappedRow.has_non_evergreen_revenue?.toLowerCase() === 'yes' || mappedRow.has_non_evergreen_revenue?.toLowerCase() === 'true' || false,
        requires_partner_access: mappedRow.requires_partner_access?.toLowerCase() === 'yes' || mappedRow.requires_partner_access?.toLowerCase() === 'true' || false,
        has_branded_revenue: mappedRow.has_branded_revenue?.toLowerCase() === 'yes' || mappedRow.has_branded_revenue?.toLowerCase() === 'true' || false,
        has_marketing_revenue: mappedRow.has_marketing_revenue?.toLowerCase() === 'yes' || mappedRow.has_marketing_revenue?.toLowerCase() === 'true' || false,
        has_web_mgmt_revenue: mappedRow.has_web_mgmt_revenue?.toLowerCase() === 'yes' || mappedRow.has_web_mgmt_revenue?.toLowerCase() === 'true' || false,
        primary_education: mappedRow.primary_education || undefined,
        secondary_education: mappedRow.secondary_education || undefined,
        qbo_show_name: mappedRow.qbo_show_name || undefined,
        qbo_show_id: safeInt(mappedRow.qbo_show_id),
      };
      shows.push(show);
    }

    return { shows, errors };
  };

  const handleImport = async () => {
    if (!file) {
      setValidationError(null)
      setError("Please select a file to import.")
      return
    }

    setIsImporting(true)
    setError(null)

    Papa.parse<any>(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results: Papa.ParseResult<any>) => {
        const { data, errors: parsingErrors } = results;

        if (parsingErrors.length > 0) {
          setValidationError(null)
          setError(`Error parsing CSV: ${parsingErrors[0].message}`);
          setIsImporting(false);
          return;
        }

        // Parse CSV data
        const { shows, errors: validationErrors } = parseCSVData(data);

        if (validationErrors.length > 0) {
          onImportComplete({ success: false, message: "Import failed due to validation errors.", errors: validationErrors });
          setIsImporting(false);
          onOpenChange(false);
          return;
        }

        if (shows.length === 0) {
          setValidationError(null)
          setError("No valid shows found in CSV file.");
          setIsImporting(false);
          return;
        }

        // Store shows and check for duplicates
        setShowsToImport(shows);
        await checkForDuplicates(shows);
      },
      error: (err: Error) => {
        setValidationError(null)
        setError(err.message);
        setIsImporting(false);
      }
    });
  };

  const checkForDuplicates = async (shows: ShowCreate[]) => {
    setIsCheckingDuplicates(true);
    try {
      const duplicateResults = await apiClient.checkDuplicates(shows);
      setDuplicateCheckResults(duplicateResults.duplicates);
      
      // Create preview rows
      const previewRows: ImportPreviewRow[] = shows.map((show, index) => {
        const duplicateResult = duplicateResults.duplicates[index];
        return {
          title: show.title,
          action: duplicateResult.exists ? "update" : "create",
          isDuplicate: duplicateResult.exists,
          existingShow: duplicateResult.existing_show,
          showData: show
        };
      });
      
      setImportPreview(previewRows);
      setShowPreview(true);
    } catch (error: unknown) {
      const err = error as Error & { validationDetails?: Array<{ loc?: unknown[]; msg?: string }> };
      if (err?.validationDetails && Array.isArray(err.validationDetails) && shows.length > 0) {
        const table = buildValidationErrorTable(err.validationDetails, shows, "Failed to check for duplicates:");
        setValidationError(table);
        setError(table.summary);
      } else {
        setValidationError(null);
        const fallback = err instanceof Error ? err.message : (err && typeof (err as { message?: string }).message === "string" ? (err as { message: string }).message : "An unexpected error occurred");
        setError(`Failed to check for duplicates: ${fallback}`);
      }
    } finally {
      setIsCheckingDuplicates(false);
      setIsImporting(false);
    }
  };

  const handlePreviewActionChange = (title: string, action: "create" | "update" | "skip") => {
    setImportPreview(prev => 
      prev.map(row => 
        row.title === title ? { ...row, action } : row
      )
    );
  };

  const handleFinalImport = async () => {
    setIsImporting(true);
    try {
      const actions: DuplicateAction[] = importPreview.map(row => ({
        title: row.title,
        action: row.action
      }));

      const response = await apiClient.bulkCreatePodcastsWithActions(showsToImport, actions);
      
      onImportComplete({
        success: response.failed === 0,
        message: response.message,
        errors: response.errors,
        warnings: response.warnings,
      });
      
      onOpenChange(false);
    } catch (error: unknown) {
      const err = error as Error & { validationDetails?: Array<{ loc?: unknown[]; msg?: string }> };
      if (err?.validationDetails && Array.isArray(err.validationDetails) && showsToImport.length > 0) {
        const table = buildValidationErrorTable(err.validationDetails, showsToImport, "Import failed:");
        setValidationError(table);
        setError(table.summary);
      } else {
        setValidationError(null);
        const fallback = err instanceof Error ? err.message : (err && typeof (err as { message?: string }).message === "string" ? (err as { message: string }).message : "An unexpected error occurred");
        setError(`Import failed: ${fallback}`);
      }
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-none w-full sm:max-w-[1200px] md:max-w-[1200px] h-screen sm:h-[800px] md:h-[800px] md:max-h-[90vh] mobile-fullscreen flex flex-col p-0 sm:p-0 overflow-hidden border-0 [&>button:not(.navigation-button)]:hidden">
        <DialogDescription className="sr-only">
          Upload a CSV file to import or update shows. You can create new shows, update existing ones, or skip duplicates.
        </DialogDescription>
        {/* Mobile Header - full width with title left, close right */}
        {!showPreview && (
          <DialogHeader className="flex sm:hidden flex-row items-center justify-between px-6 py-4">
            <div className="flex w-full items-center justify-between gap-3">
              <DialogTitle className="text-lg font-semibold text-left truncate flex-1">
                Import Shows from CSV
              </DialogTitle>
              <DialogClose asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 !gap-0 relative">
                  <X className="h-4 w-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                  <span className="sr-only">Close</span>
                </Button>
              </DialogClose>
            </div>
          </DialogHeader>
        )}

        {/* Mobile Header for Preview - full width with title left, close right */}
        {showPreview && (
          <DialogHeader className="flex sm:hidden flex-row items-center justify-between px-6 py-4">
            <div className="flex w-full items-center justify-between gap-3">
              <DialogTitle className="text-lg font-semibold text-left truncate flex-1 flex items-center gap-2">
                <Eye className="h-5 w-5 text-emerald-600" />
                Import Preview
              </DialogTitle>
              <DialogClose asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 !gap-0 relative">
                  <X className="h-4 w-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                  <span className="sr-only">Close</span>
                </Button>
              </DialogClose>
            </div>
          </DialogHeader>
        )}

        {/* Desktop Header - title and close button */}
        {!showPreview && (
          <DialogHeader className="hidden sm:flex flex-row items-center justify-between px-6 py-4">
            <DialogTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5 text-emerald-600" />
              Import Shows from CSV
            </DialogTitle>
            <DialogClose asChild>
              <Button variant="outline" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 flex items-center justify-center !gap-0 relative">
                <X className="h-4 w-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                <span className="sr-only">Close</span>
              </Button>
            </DialogClose>
          </DialogHeader>
        )}

        {/* Desktop Header for Preview - title and close button */}
        {showPreview && (
          <DialogHeader className="hidden sm:flex flex-row items-center justify-between px-6 py-4">
            <DialogTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-emerald-600" />
              Import Preview
            </DialogTitle>
            <DialogClose asChild>
              <Button variant="outline" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 flex items-center justify-center !gap-0 relative">
                <X className="h-4 w-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                <span className="sr-only">Close</span>
              </Button>
            </DialogClose>
          </DialogHeader>
        )}
        
        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto px-6 py-4 sm:px-6 sm:py-4">
          {!showPreview ? (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                    <CardTitle className="text-lg">How it Works</CardTitle>
                    <CardDescription className="hidden sm:block">Follow these steps to bulk import your shows.</CardDescription>
                    <CardDescription className="sm:hidden">Bulk import your shows in 3 simple steps.</CardDescription>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                    <p className="hidden sm:block"><strong>Step 1: Download Resources.</strong> Get the CSV template and view the import guide. The guide explains what each column means.</p>
                    <p className="sm:hidden"><strong>Step 1:</strong> Download the CSV template and import guide.</p>
                    <p className="hidden sm:block"><strong>Step 2: Fill Out the Template.</strong> Add your show data to the CSV file. Only the 'title' column is required for each show.</p>
                    <p className="sm:hidden"><strong>Step 2:</strong> Fill out the CSV file with your show data.</p>
                    <p className="hidden sm:block"><strong>Step 3: Upload the File.</strong> Drag and drop your completed CSV file into the area below and click 'Import'.</p>
                    <p className="sm:hidden"><strong>Step 3:</strong> Upload your CSV file below and click 'Import'.</p>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button variant="outline" onClick={handleDownloadTemplate}>
                    <Download className="mr-2 h-4 w-4" />
                    Download Template (.csv)
                  </Button>
                  <Button variant="outline" onClick={() => router.push('/import-shows-guide')}>
                    <BookOpen className="mr-2 h-4 w-4" />
                    View Import Guide
                  </Button>
              </div>

              <Separator />
              
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive
                    ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20"
                    : "border-gray-300 hover:border-gray-400"
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv"
                  onChange={handleFileChange}
                  className="hidden"
                />
                {file ? (
                  <div className="space-y-2 flex flex-col items-center">
                    <CheckCircle className="h-12 w-12 text-emerald-600 mx-auto" />
                    <p className="font-medium">{file.name}</p>
                    <p className="text-sm text-muted-foreground">{(file.size / 1024).toFixed(1)} KB</p>
                    <Button variant="ghost" size="sm" onClick={() => setFile(null)} className="mt-2 text-red-500 hover:text-red-600">
                      Remove File
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4 flex flex-col items-center">
                    <Upload className="h-12 w-12 text-gray-400 mx-auto" />
                    <div>
                      <p className="font-medium">Drag & drop your CSV file here</p>
                      <p className="text-sm text-muted-foreground">or</p>
                    </div>
                    <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                      Browse for File
                    </Button>
                  </div>
                )}
              </div>

              {(error || validationError) && (
                <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>
                      <div className="text-sm space-y-3">
                        {validationError && validationError.rows.length > 0 ? (
                          <>
                            <p>{validationError.summary}</p>
                            <div className="table-density-compact bg-background border border-border rounded-lg overflow-x-auto overflow-y-hidden [&_th:last-child]:border-r-0 [&_td:last-child]:border-r-0">
                              <Table className="w-full text-sm table-fixed">
                                <TableHeader>
                                  <TableRow className="hover:bg-transparent border-b">
                                    <TableHead className="border-r px-4 py-3 font-semibold bg-muted/50 text-left whitespace-nowrap w-14">Row</TableHead>
                                    <TableHead className="border-r px-4 py-3 font-semibold bg-muted/50 text-left whitespace-nowrap">Show name</TableHead>
                                    <TableHead className="border-r px-4 py-3 font-semibold bg-muted/50 text-left whitespace-nowrap">Invalid genre</TableHead>
                                    <TableHead className="border-r px-4 py-3 font-semibold bg-muted/50 text-left whitespace-nowrap">Suggested</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {validationError.rows.map((r, i) => (
                                    <TableRow key={i} className="border-b border-border">
                                      <TableCell className="border-r px-4 py-3 font-medium">{r.rowNum}</TableCell>
                                      <TableCell className="border-r px-4 py-3">{r.showTitle || "—"}</TableCell>
                                      <TableCell className="border-r px-4 py-3">{r.invalidValue}</TableCell>
                                      <TableCell className="border-r px-4 py-3">{r.suggestion ?? "—"}</TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </div>
                            <p className="font-medium">Allowed genres:</p>
                            <p className="text-muted-foreground">{validationError.allowedGenres}</p>
                            <p className="pt-1">{validationError.tip}</p>
                          </>
                        ) : error ? (
                          <p className="whitespace-pre-line">{error}</p>
                        ) : null}
                      </div>
                    </AlertDescription>
                </Alert>
              )}
            </div>
          ) : (
            <div>
              {/* Description for Preview - Desktop only */}
              <DialogDescription className="hidden sm:block text-sm text-muted-foreground text-left mb-4">
                Review and configure how each show will be imported. Duplicates are highlighted.
              </DialogDescription>

              {/* Desktop Table View */}
              <div className="hidden md:block border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm table-fixed">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="p-3 text-left font-medium w-1/3 border-r">
                          <button
                            onClick={() => handleSort('title')}
                            className="flex items-center hover:bg-muted/50 rounded px-2 py-1 -mx-2 -my-1 transition-colors"
                          >
                            Show Title
                            {renderSortIcon('title')}
                          </button>
                        </th>
                        <th className="p-3 text-left font-medium w-1/6 border-r">
                          <button
                            onClick={() => handleSort('status')}
                            className="flex items-center hover:bg-muted/50 rounded px-2 py-1 -mx-2 -my-1 transition-colors"
                          >
                            Status
                            {renderSortIcon('status')}
                          </button>
                        </th>
                        <th className="p-3 text-left font-medium w-1/4 border-r">Action</th>
                        <th className="p-3 text-left font-medium w-1/4">Details</th>
                      </tr>
                    </thead>
                    <tbody>
                      {getSortedPreview().map((row, index) => (
                        <tr key={index} className="border-t border-border">
                          <td className="p-3 font-medium border-r">{row.title}</td>
                          <td className="p-3 border-r">
                            {row.isDuplicate ? (
                              <Badge variant="destructive" className="text-xs">
                                Duplicate Found
                              </Badge>
                            ) : (
                              <Badge variant="secondary" className="text-xs">
                                New Show
                              </Badge>
                            )}
                          </td>
                          <td className="p-3 border-r">
                            <Select
                              value={row.action}
                              onValueChange={(value: "create" | "update" | "skip") => 
                                handlePreviewActionChange(row.title, value)
                              }
                            >
                              <SelectTrigger className="w-48 min-w-[180px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="create">Create New</SelectItem>
                                <SelectItem value="update" disabled={!row.isDuplicate}>
                                  Update Existing
                                </SelectItem>
                                <SelectItem value="skip">Skip</SelectItem>
                              </SelectContent>
                            </Select>
                          </td>
                          <td className="p-3 text-xs text-muted-foreground">
                            {row.isDuplicate && row.existingShow ? (
                              <div>
                                <p>Existing: {row.existingShow.title}</p>
                              </div>
                            ) : (
                              <p>Will create new show</p>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Mobile Table View - same as desktop */}
              <div className="md:hidden border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="p-2 text-left font-medium border-r whitespace-nowrap">
                          <button
                            onClick={() => handleSort('title')}
                            className="flex items-center hover:bg-muted/50 rounded px-2 py-1 -mx-2 -my-1 transition-colors"
                          >
                            Show Title
                            {renderSortIcon('title')}
                          </button>
                        </th>
                        <th className="p-2 text-left font-medium border-r whitespace-nowrap">
                          <button
                            onClick={() => handleSort('status')}
                            className="flex items-center hover:bg-muted/50 rounded px-2 py-1 -mx-2 -my-1 transition-colors"
                          >
                            Status
                            {renderSortIcon('status')}
                          </button>
                        </th>
                        <th className="p-2 text-left font-medium border-r whitespace-nowrap">Action</th>
                        <th className="p-2 text-left font-medium whitespace-nowrap">Details</th>
                      </tr>
                    </thead>
                    <tbody>
                      {getSortedPreview().map((row, index) => (
                        <tr key={index} className="border-t border-border">
                          <td className="p-2 font-medium border-r text-xs whitespace-nowrap">{row.title}</td>
                          <td className="p-2 border-r whitespace-nowrap">
                            {row.isDuplicate ? (
                              <Badge variant="destructive" className="text-xs">
                                Duplicate Found
                              </Badge>
                            ) : (
                              <Badge variant="secondary" className="text-xs">
                                New Show
                              </Badge>
                            )}
                          </td>
                          <td className="p-2 border-r whitespace-nowrap">
                            <Select
                              value={row.action}
                              onValueChange={(value: "create" | "update" | "skip") => 
                                handlePreviewActionChange(row.title, value)
                              }
                            >
                              <SelectTrigger className="w-full text-xs h-8">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="create">Create New</SelectItem>
                                <SelectItem value="update" disabled={!row.isDuplicate}>
                                  Update Existing
                                </SelectItem>
                                <SelectItem value="skip">Skip</SelectItem>
                              </SelectContent>
                            </Select>
                          </td>
                          <td className="p-2 text-xs text-muted-foreground whitespace-nowrap">
                            {row.isDuplicate && row.existingShow ? (
                              <div>
                                <p className="truncate">Existing: {row.existingShow.title}</p>
                              </div>
                            ) : (
                              <p>Will create new show</p>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {(error || validationError) && (
                <Alert variant="destructive" className="mt-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>
                      <div className="text-sm space-y-3">
                        {validationError && validationError.rows.length > 0 ? (
                          <>
                            <p>{validationError.summary}</p>
                            <div className="table-density-compact bg-background border border-border rounded-lg overflow-x-auto overflow-y-hidden [&_th:last-child]:border-r-0 [&_td:last-child]:border-r-0">
                              <Table className="w-full text-sm table-fixed">
                                <TableHeader>
                                  <TableRow className="hover:bg-transparent border-b">
                                    <TableHead className="border-r px-4 py-3 font-semibold bg-muted/50 text-left whitespace-nowrap w-14">Row</TableHead>
                                    <TableHead className="border-r px-4 py-3 font-semibold bg-muted/50 text-left whitespace-nowrap">Show name</TableHead>
                                    <TableHead className="border-r px-4 py-3 font-semibold bg-muted/50 text-left whitespace-nowrap">Invalid genre</TableHead>
                                    <TableHead className="border-r px-4 py-3 font-semibold bg-muted/50 text-left whitespace-nowrap">Suggested</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {validationError.rows.map((r, i) => (
                                    <TableRow key={i} className="border-b border-border">
                                      <TableCell className="border-r px-4 py-3 font-medium">{r.rowNum}</TableCell>
                                      <TableCell className="border-r px-4 py-3">{r.showTitle || "—"}</TableCell>
                                      <TableCell className="border-r px-4 py-3">{r.invalidValue}</TableCell>
                                      <TableCell className="border-r px-4 py-3">{r.suggestion ?? "—"}</TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </div>
                            <p className="font-medium">Allowed genres:</p>
                            <p className="text-muted-foreground">{validationError.allowedGenres}</p>
                            <p className="pt-1">{validationError.tip}</p>
                          </>
                        ) : error ? (
                          <p className="whitespace-pre-line">{error}</p>
                        ) : null}
                      </div>
                    </AlertDescription>
                </Alert>
              )}
            </div>
          )}
        </div>

        {/* Desktop Footer - buttons */}
        {showPreview ? (
          <div className="hidden sm:flex items-center justify-between gap-2 px-6 py-4 border-t border-border bg-muted/30">
            {/* Stats pills on left */}
            <div className="flex items-center gap-2">
              <div className="px-2 flex flex-col items-center justify-center min-w-[60px] gap-1 border border-input bg-background rounded-full h-10">
                <span className="text-sm font-bold leading-none">{importPreview.length}</span>
                <span className="text-xs text-muted-foreground leading-none">Total</span>
              </div>
              <div className="px-2 flex flex-col items-center justify-center min-w-[60px] gap-1 border border-input bg-background rounded-full h-10">
                <span className="text-sm font-bold leading-none">{importPreview.filter(r => r.action === 'create').length}</span>
                <span className="text-xs text-muted-foreground leading-none">Create</span>
              </div>
              <div className="px-2 flex flex-col items-center justify-center min-w-[60px] gap-1 border border-input bg-background rounded-full h-10">
                <span className="text-sm font-bold leading-none">{importPreview.filter(r => r.action === 'update').length}</span>
                <span className="text-xs text-muted-foreground leading-none">Update</span>
              </div>
              <div className="px-2 flex flex-col items-center justify-center min-w-[60px] gap-1 border border-input bg-background rounded-full h-10">
                <span className="text-sm font-bold leading-none">{importPreview.filter(r => r.action === 'skip').length}</span>
                <span className="text-xs text-muted-foreground leading-none">Skip</span>
              </div>
            </div>
            {/* Buttons on right */}
            <div className="flex items-center gap-2">
              <Button onClick={handleFinalImport} disabled={isImporting} className="evergreen-button">
                {isImporting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Importing...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Import Selected
                  </>
                )}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowPreview(false)}
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
              <Button variant="outline" onClick={() => handleOpenChange(false)}>Cancel</Button>
            </div>
          </div>
        ) : (
          <div className="hidden sm:flex items-center justify-end gap-2 px-6 py-4 border-t border-border bg-muted/30">
            <Button onClick={handleImport} disabled={!file || isImporting || isCheckingDuplicates} className="evergreen-button">
              {isImporting || isCheckingDuplicates ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {isCheckingDuplicates ? "Checking..." : "Importing..."}
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Import
                </>
              )}
            </Button>
            <Button variant="outline" onClick={() => handleOpenChange(false)}>Cancel</Button>
          </div>
        )}

        {/* Mobile Footer - Sticky footer for mobile only */}
        {showPreview ? (
          <div className="sticky bottom-0 bg-background border-t border-border p-6 sm:hidden">
            {/* Stats pills in single line */}
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="px-2 flex flex-col items-center justify-center min-w-[60px] gap-1 border border-input bg-background rounded-full h-10">
                <span className="text-sm font-bold leading-none">{importPreview.length}</span>
                <span className="text-xs text-muted-foreground leading-none">Total</span>
              </div>
              <div className="px-2 flex flex-col items-center justify-center min-w-[60px] gap-1 border border-input bg-background rounded-full h-10">
                <span className="text-sm font-bold leading-none">{importPreview.filter(r => r.action === 'create').length}</span>
                <span className="text-xs text-muted-foreground leading-none">Create</span>
              </div>
              <div className="px-2 flex flex-col items-center justify-center min-w-[60px] gap-1 border border-input bg-background rounded-full h-10">
                <span className="text-sm font-bold leading-none">{importPreview.filter(r => r.action === 'update').length}</span>
                <span className="text-xs text-muted-foreground leading-none">Update</span>
              </div>
              <div className="px-2 flex flex-col items-center justify-center min-w-[60px] gap-1 border border-input bg-background rounded-full h-10">
                <span className="text-sm font-bold leading-none">{importPreview.filter(r => r.action === 'skip').length}</span>
                <span className="text-xs text-muted-foreground leading-none">Skip</span>
              </div>
            </div>
            {/* Buttons layout */}
            <div className="space-y-3">
              <Button onClick={handleFinalImport} disabled={isImporting} className="evergreen-button w-full whitespace-nowrap">
                {isImporting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Importing...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Import Selected
                  </>
                )}
              </Button>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => setShowPreview(false)}
                  className="flex-1 gap-2"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Back
                </Button>
                <Button variant="outline" onClick={() => handleOpenChange(false)} className="flex-1">Cancel</Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="sticky bottom-0 bg-background border-t border-border p-6 sm:hidden">
            <div className="space-y-3">
              <Button onClick={handleImport} disabled={!file || isImporting || isCheckingDuplicates} className="evergreen-button w-full">
                {isImporting || isCheckingDuplicates ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {isCheckingDuplicates ? "Checking..." : "Importing..."}
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Import
                  </>
                )}
              </Button>
              <Button variant="outline" onClick={() => handleOpenChange(false)} className="w-full">Cancel</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}