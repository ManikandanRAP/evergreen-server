"use client"

import { useState, useEffect, useRef } from "react"
import { useAuth } from "@/lib/auth-context"
import { useSettings } from "@/lib/settings-context"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { AlertTriangle } from "lucide-react"

const CLICK_COUNT_REQUIRED = 7
const CLICK_TIMEOUT_MS = 2000 // Reset if no click within 2 seconds

export default function DeveloperOptionsFooter() {
  const { user } = useAuth()
  const { updateSettings, addDeveloperLog } = useSettings()
  const [clickCount, setClickCount] = useState(0)
  const [showDialog, setShowDialog] = useState(false)
  const [isDark, setIsDark] = useState(false)
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Check if user is admin
  const isAdmin = user?.role === "admin"

  // Check theme
  useEffect(() => {
    const checkTheme = () => {
      setIsDark(document.documentElement.classList.contains("dark"))
    }
    checkTheme()

    const observer = new MutationObserver(checkTheme)
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    })

    return () => observer.disconnect()
  }, [])

  // Reset click count if timeout expires
  useEffect(() => {
    if (clickCount > 0) {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
      timeoutRef.current = setTimeout(() => {
        setClickCount(0)
      }, CLICK_TIMEOUT_MS)
    }

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [clickCount])

  const handleLogoClick = () => {
    if (!isAdmin) return

    const newCount = clickCount + 1
    setClickCount(newCount)

    if (newCount >= CLICK_COUNT_REQUIRED) {
      setClickCount(0)
      setShowDialog(true)
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }

  const handleConfirm = () => {
    updateSettings({ developerOptionsEnabled: true })
    setShowDialog(false)
    addDeveloperLog("success", "Developer options enabled via footer logo")
  }

  const handleCancel = () => {
    setShowDialog(false)
  }

  // Only show for admin users
  if (!isAdmin) {
    return null
  }

  return (
    <>
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          variant="outline"
          onClick={handleLogoClick}
          className="h-8 px-2"
          aria-label="Developer options"
        >
          <Image
            src={isDark ? "/myco-beta-footer-logo-light.png" : "/myco-beta-footer-logo.png"}
            alt="Myco"
            width={24}
            height={24}
            className="object-contain"
          />
        </Button>
      </div>

      {/* Developer Options Confirmation Dialog */}
      <AlertDialog open={showDialog} onOpenChange={setShowDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-amber-600 dark:text-amber-400">
              <AlertTriangle className="h-5 w-5 inline-block mr-2" />
              Enable Developer Options
            </AlertDialogTitle>
          </AlertDialogHeader>
          <div className="text-sm text-muted-foreground px-6 py-4">
            <p className="mb-4">
              Are you sure you want to enable developer options? These settings are intended for advanced users and developers.
            </p>
            <div className="relative w-full rounded-2xl border border-amber-500/30 dark:border-amber-400/20 p-4 bg-amber-50/50 dark:bg-amber-950/20">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                <div className="flex-1 text-sm text-foreground">
                  <p className="font-medium text-amber-900 dark:text-amber-100 mb-2">
                    Enabling developer options will give you access to:
                  </p>
                  <ul className="mt-2 ml-4 list-disc space-y-1 text-amber-800 dark:text-amber-200">
                    <li>Debug mode with additional console logging</li>
                    <li>API endpoint override capabilities</li>
                    <li>API response time monitoring</li>
                    <li>Database export/import (Admin only)</li>
                    <li>Developer console with logs</li>
                  </ul>
                  <p className="mt-3 font-medium text-amber-900 dark:text-amber-100">
                    <strong>Warning:</strong> These features may affect application stability and should only be used by experienced developers.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <AlertDialogFooter>
            <AlertDialogAction
              onClick={handleConfirm}
              className="evergreen-button-amber"
            >
              Enable Developer Options
            </AlertDialogAction>
            <AlertDialogCancel onClick={handleCancel}>
              Cancel
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}

