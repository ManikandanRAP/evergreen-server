"use client"

import { useState } from "react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Trash2, AlertTriangle, Loader2 } from "lucide-react"
import type { Show } from "@/lib/api-client"

interface DeleteShowDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  show: Show | null
  onShowDeleted?: () => void
  deleteShow: (showId: string) => Promise<boolean>
}

export default function DeleteShowDialog({
  open,
  onOpenChange,
  show,
  onShowDeleted,
  deleteShow,
}: DeleteShowDialogProps) {
  const [isDeleting, setIsDeleting] = useState(false)
  const handleConfirmDelete = async () => {
    if (!show) return

    setIsDeleting(true)
    try {
      const success = await deleteShow(show.id)
      if (success) {
        onShowDeleted?.()
        onOpenChange(false)
      }
    } catch (error) {
      console.error("Failed to delete show:", error)
    } finally {
      setIsDeleting(false)
    }
  }

  const handleCancel = () => {
    onOpenChange(false)
  }

  if (!show) return null

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="text-red-600 dark:text-red-400">
            <Trash2 className="h-5 w-5 inline-block mr-2" />
            Delete Show
          </AlertDialogTitle>
        </AlertDialogHeader>
        
        <AlertDialogDescription asChild>
          <div className="space-y-4">
            <p>Are you sure you want to delete this show? This action cannot be undone.</p>
            
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Warning:</strong> Deleting "{show.title}" will permanently remove:
                <ul className="mt-2 ml-4 list-disc space-y-1">
                  <li>All show data and settings</li>
                  <li>Associated revenue records</li>
                  <li>Partner access permissions</li>
                  <li>Historical performance data</li>
                </ul>
              </AlertDescription>
            </Alert>

            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-medium mb-2">Show Details:</h4>
              <div className="space-y-1 text-sm">
                <p>
                  <strong>Name:</strong> {show.title}
                </p>
                <p>
                  <strong>Type:</strong> {show.show_type || "N/A"}
                </p>
                <p>
                  <strong>Ranking:</strong> {show.ranking_category ? `Level ${show.ranking_category}` : "N/A"}
                </p>
                <p>
                  <strong>Standard Ads:</strong> {show.standard_ads_percent != null ? `${show.standard_ads_percent}%` : "N/A"}
                </p>
                <p>
                  <strong>Programmatic Ads:</strong> {show.programmatic_ads_span_percent != null ? `${show.programmatic_ads_span_percent}%` : "N/A"}
                </p>
              </div>
            </div>
          </div>
        </AlertDialogDescription>

        <AlertDialogFooter>
          <AlertDialogAction
            onClick={handleConfirmDelete}
            disabled={isDeleting}
            className="evergreen-button-red"
          >
            {isDeleting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Deleting...
              </>
            ) : (
              <>
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Show
              </>
            )}
          </AlertDialogAction>
          <AlertDialogCancel onClick={handleCancel} disabled={isDeleting}>
            Cancel
          </AlertDialogCancel>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
