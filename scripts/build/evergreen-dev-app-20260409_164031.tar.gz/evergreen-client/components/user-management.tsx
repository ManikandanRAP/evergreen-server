"use client"

import React, { useEffect, useMemo, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command"
import { Popover, PopoverTrigger } from "@/components/ui/popover"
import { CustomPopoverContent } from "@/components/ui/custom-popover-content"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Check, ChevronsUpDown, Loader2, Pencil, Trash2, ArrowLeft, Eye, EyeOff, Search, ChevronLeft, ChevronRight, ArrowUpDown, ArrowUp, ArrowDown, Plus, Download, Users, UserCheck, UserX, MoreHorizontal, User as UserIcon, Building, Calendar, MoreVertical, Settings, UserPlus, X } from "lucide-react"
import clsx from "clsx"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/lib/auth-context"
import { useSettings } from "@/lib/settings-context"
import CreateUserDialog from "@/components/create-user-dialog"

type UserManagementProps = {
  onBack: () => void
}

type UserRow = {
  id: string
  name: string | null
  email: string
  role?: string | null
  created_at?: string | null
  mapped_vendor_qbo_id?: number | null
  mapped_vendor_name?: string | null
}

type Vendor = {
  vendor_qbo_id: number
  vendor_name: string
}

type SortField = keyof UserRow | null
type SortDirection = "asc" | "desc" | "original"

// const API_URL = "http://127.0.0.1:8000"
const API_URL = process.env.NEXT_PUBLIC_API_URL
// PAGE_SIZE is now dynamic from settings

export default function UserManagement({ onBack }: UserManagementProps) {
  const { user: currentUser, token } = useAuth()
  const { toast } = useToast()
  const { getPageSize, settings, updateSettings } = useSettings()
  const PAGE_SIZE = useMemo(() => getPageSize("userManagement") || 10, [getPageSize])
  
  const PAGE_SIZE_OPTIONS = [5, 10, 12, 15, 20, 25, 50, 100]
  
  const handlePageSizeChange = (value: string) => {
    const newPageSize = parseInt(value)
    const updates: any = {
      pagination: {
        ...settings.pagination,
        userManagement: newPageSize,
      },
    }
    
    if (settings.globalPageSize !== null) {
      updates.globalPageSize = null
    }
    
    updateSettings(updates)
    setPage(1)
  }
  
  useEffect(() => setPage(1), [PAGE_SIZE])

  const [loading, setLoading] = useState(false)
  const [users, setUsers] = useState<UserRow[]>([])
  const [vendors, setVendors] = useState<Vendor[]>([])

  // Search, sorting, and pagination state
  const [searchTerm, setSearchTerm] = useState("")
  const [page, setPage] = useState(1)
  const [sortField, setSortField] = useState<SortField>(null)
  const [sortDirection, setSortDirection] = useState<SortDirection>("original")
  const [originalOrder, setOriginalOrder] = useState<UserRow[]>([])

  // Filter state
  const [roleFilter, setRoleFilter] = useState<string>("all")

  // Create user state
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)

  // User profile view state
  const [viewingUser, setViewingUser] = useState<UserRow | null>(null)
  const [isProfileDialogOpen, setIsProfileDialogOpen] = useState(false)

  const [editing, setEditing] = useState<UserRow | null>(null)
  const [form, setForm] = useState<{ name: string; email: string; role: string; password: string; confirmPassword: string; mapped_vendor_qbo_id: number | null }>({
    name: "",
    email: "",
    role: "",
    password: "",
    confirmPassword: "",
    mapped_vendor_qbo_id: null,
  })
  const [saving, setSaving] = useState(false)
  const [vendorPopoverOpen, setVendorPopoverOpen] = useState(false)

  const [confirmOpen, setConfirmOpen] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [toDelete, setToDelete] = useState<UserRow | null>(null)

  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [realTimeErrors, setRealTimeErrors] = useState<Record<string, string>>({})
  const [isCheckingUsername, setIsCheckingUsername] = useState(false)
  const [emailError, setEmailError] = useState<string>("")

  const isPartner = useMemo(() => (form.role || "").toLowerCase() === "partner", [form.role])

  // Helper function to format role names for display
  const formatRoleName = (role: string | null | undefined) => {
    switch (role) {
      case 'admin': return 'Admin'
      case 'partner': return 'Partner'
      case 'internal_full_access': return 'Internal - Full Access'
      case 'internal_show_access': return 'Internal - Show Access'
      default: return role || '—'
    }
  }

  // Real-time password validation for edit dialog
  useEffect(() => {
    setRealTimeErrors(prev => {
      const newErrors = { ...prev }
      
      if (form.password && form.confirmPassword) {
        if (form.password !== form.confirmPassword) {
          newErrors.confirmPassword = "Passwords do not match"
        } else {
          // Clear password error if passwords match
          delete newErrors.confirmPassword
        }
      } else {
        // Clear password error if either field is empty
        delete newErrors.confirmPassword
      }
      
      return newErrors
    })
  }, [form.password, form.confirmPassword])

  // Real-time username availability check for edit dialog
  useEffect(() => {
    const checkUsernameAvailability = async () => {
      if (!form.email || !token || !editing) return
      
      // Don't check if email hasn't changed from original
      if (form.email === editing.email) {
        setEmailError("")
        return
      }
      
      // Basic email validation first
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
        setEmailError("")
        return
      }

      setIsCheckingUsername(true)
      
      try {
        const response = await fetch(`${API_URL}/users/check-username`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
          body: JSON.stringify({ username: form.email }),
        })

        if (response.ok) {
          const data = await response.json()
          if (data.available) {
            setEmailError("")
          } else {
            setEmailError("Username already exists")
          }
        } else {
          console.error('Failed to check username availability')
        }
      } catch (error) {
        console.error('Error checking username availability:', error)
      } finally {
        setIsCheckingUsername(false)
      }
    }

    // Debounce the API call
    const timeoutId = setTimeout(checkUsernameAvailability, 500)
    return () => clearTimeout(timeoutId)
  }, [form.email, token, editing])

  // Filter and sort users
  const filteredAndSortedUsers = useMemo(() => {
    const filtered = users.filter((user) => {
      // Search filter
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase()
        const name = (user.name || "").toLowerCase()
        const email = user.email.toLowerCase()
        const role = (user.role || "").toLowerCase()
        
        if (!name.includes(searchLower) && 
            !email.includes(searchLower) && 
            !role.includes(searchLower)) {
          return false
        }
      }

      // Role filter
      if (roleFilter !== "all" && user.role !== roleFilter) {
        return false
      }

      return true
    })

    if (sortDirection === "original") {
      // We need to filter the original order as well to match search terms
      const originalIds = new Set(filtered.map((u) => u.id))
      return originalOrder.filter((u) => originalIds.has(u.id))
    }

    if (sortField) {
      filtered.sort((a, b) => {
        const aValue = String(a[sortField] ?? "").toLowerCase()
        const bValue = String(b[sortField] ?? "").toLowerCase()

        if (aValue < bValue) return sortDirection === "asc" ? -1 : 1
        if (aValue > bValue) return sortDirection === "asc" ? 1 : -1
        return 0
      })
    }

    return filtered
  }, [users, originalOrder, searchTerm, sortField, sortDirection, roleFilter])

  const totalPages = useMemo(() => Math.max(1, Math.ceil(filteredAndSortedUsers.length / PAGE_SIZE)), [filteredAndSortedUsers.length, PAGE_SIZE])

  const paginatedUsers = useMemo(() => {
    const start = (page - 1) * PAGE_SIZE
    return filteredAndSortedUsers.slice(start, start + PAGE_SIZE)
  }, [filteredAndSortedUsers, page, PAGE_SIZE])

  // Reset page when search or filters change
  useEffect(() => {
    setPage(1)
  }, [searchTerm, roleFilter])

  // User statistics
  const userStats = useMemo(() => {
    const total = users.length
    const admins = users.filter(u => u.role === "admin").length
    const partners = users.filter(u => u.role === "partner").length
    const internalFullAccess = users.filter(u => u.role === "internal_full_access").length
    const internalShowAccess = users.filter(u => u.role === "internal_show_access").length
    
    return { total, admins, partners, internalFullAccess, internalShowAccess }
  }, [users])

  // Function to load users
  const loadUsers = async () => {
    if (!token) return
    setLoading(true)
    try {
      const res = await fetch(`${API_URL}/users`, { headers: { Authorization: `Bearer ${token}` } })
      if (!res.ok) throw new Error("Failed to fetch users")
      const data = (await res.json()) as UserRow[]
      setUsers(data)
      setOriginalOrder(data)
    } catch (e: any) {
      toast({ title: "Failed to load users", description: e?.message ?? String(e), variant: "destructive" })
    } finally {
      setLoading(false)
    }
  }

  // Load users & vendors on mount
  useEffect(() => {
    const run = async () => {
      await loadUsers()
      // preload vendors for combobox
      try {
        const resp = await fetch(`${API_URL}/vendors`, { headers: { Authorization: `Bearer ${token}` } })
        if (resp.ok) {
          const v = (await resp.json()) as Vendor[]
          setVendors(v || [])
        }
      } catch {}
    }
    run()
  }, [token]) // run once when token ready

  function openEditor(u: UserRow) {
    setEditing(u)
    setForm({
      name: u.name ?? "",
      email: u.email,
      role: u.role ?? "",
      password: "",
      confirmPassword: "",
      mapped_vendor_qbo_id: u.mapped_vendor_qbo_id ?? null,
    })
    setShowPassword(false)
    setShowConfirmPassword(false)
    setRealTimeErrors({})
    setIsCheckingUsername(false)
    setEmailError("")
  }

  async function saveEdits() {
    if (!editing || !token) return
    
    // Validate password confirmation if password is provided
    if (form.password && form.password.trim().length > 0) {
      if (!form.confirmPassword) {
        toast({ title: "Validation Error", description: "Please confirm the password", variant: "destructive" })
        return
      }
      if (form.password !== form.confirmPassword) {
        toast({ title: "Validation Error", description: "Passwords do not match", variant: "destructive" })
        return
      }
      if (form.password.length < 8) {
        toast({ title: "Validation Error", description: "Password must be at least 8 characters", variant: "destructive" })
        return
      }
    }

    // Check for real-time username validation errors
    if (emailError) {
      toast({ title: "Validation Error", description: emailError, variant: "destructive" })
      return
    }
    
    setSaving(true)
    try {
      // only send changed fields
      const payload: any = {}
      const changed: string[] = []

      if (form.name !== (editing.name ?? "")) {
        payload.name = form.name
        changed.push(`name → "${form.name || "—"}"`)
      }
      if (form.email !== editing.email) {
        payload.email = form.email
        changed.push(`email → ${form.email}`)
      }
      if (form.password && form.password.trim().length > 0) {
        payload.password = form.password
        changed.push("password updated")
      }
      // vendor mapping (only for partner; allow clearing)
      if (isPartner) {
        if ((form.mapped_vendor_qbo_id ?? null) !== (editing.mapped_vendor_qbo_id ?? null)) {
          payload.mapped_vendor_qbo_id = form.mapped_vendor_qbo_id
          const fromName =
            editing.mapped_vendor_qbo_id != null
              ? `${editing.mapped_vendor_name ?? "Unknown"} · ID ${editing.mapped_vendor_qbo_id}`
              : "—"
          const toName =
            form.mapped_vendor_qbo_id != null
              ? `${vendors.find((v) => v.vendor_qbo_id === form.mapped_vendor_qbo_id)?.vendor_name ?? "Unknown"} · ID ${
                  form.mapped_vendor_qbo_id
                }`
              : "—"
          changed.push(`vendor: ${fromName} → ${toName}`)
        }
      } else if (editing.mapped_vendor_qbo_id != null) {
        payload.mapped_vendor_qbo_id = null
        changed.push("vendor: cleared (non-partner)")
      }

      if (Object.keys(payload).length === 0) {
        toast({ title: "No changes", description: "There are no changes to save." })
        return
      }

      const resp = await fetch(`${API_URL}/users/${editing.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      })

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({}))
        throw new Error(err?.detail || "Failed to update user")
      }
      const updated = (await resp.json()) as UserRow

      // update list
      setUsers((prev) => prev.map((u) => (u.id === updated.id ? { ...u, ...updated } : u)))

      // success toast (with changed fields)
      toast({
        title: "User updated",
        description:
          `${updated.name ?? updated.email} has been saved.` +
          (changed.length ? ` Changes: ${changed.join("; ")}.` : ""),
      })

      // close editor
      setEditing(null)
    } catch (e: any) {
      toast({ title: "Update failed", description: e?.message ?? String(e), variant: "destructive" })
    } finally {
      setSaving(false)
    }
  }

  function requestDelete(u: UserRow) {
    setToDelete(u)
    setConfirmOpen(true)
  }

  async function confirmDelete() {
    if (!toDelete || !token) return
    setDeleting(true)
    try {
      const resp = await fetch(`${API_URL}/users/${toDelete.id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      })
      if (!resp.ok && resp.status !== 204) {
        const err = await resp.json().catch(() => ({}))
        throw new Error(err?.detail || "Failed to delete user")
      }
      setUsers((prev) => prev.filter((u) => u.id !== toDelete.id))
      toast({
        title: "User deleted",
        description: `${toDelete.name ?? toDelete.email} has been removed.`,
      })
      setToDelete(null)
      setConfirmOpen(false)
    } catch (e: any) {
      toast({ title: "Delete failed", description: e?.message ?? String(e), variant: "destructive" })
    } finally {
      setDeleting(false)
    }
  }

  const canDelete = (u: UserRow) => currentUser?.id && u?.id && currentUser.id !== u.id

  // Export users function
  const handleExportUsers = () => {
    const csvContent = [
      // CSV headers
      ["Name", "Email", "Role", "Created At", "Mapped Vendor"].join(","),
      // CSV data
      ...filteredAndSortedUsers.map((user) =>
        [
          `"${(user.name || "").replace(/"/g, '""')}"`,
          `"${user.email}"`,
          `"${user.role || ""}"`,
          user.created_at ? new Date(user.created_at).toISOString() : "",
          user.mapped_vendor_name ? `"${user.mapped_vendor_name} (ID: ${user.mapped_vendor_qbo_id})"` : "",
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `users-export-${new Date().toISOString().split("T")[0]}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Export completed",
      description: `${filteredAndSortedUsers.length} users exported successfully.`,
    })
  }

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      // Cycle through: asc -> desc -> original
      if (sortDirection === "asc") {
        setSortDirection("desc")
      } else if (sortDirection === "desc") {
        setSortDirection("original")
        setSortField(null)
      } else {
        setSortDirection("asc")
      }
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
    }

    switch (sortDirection) {
      case "asc":
        return <ArrowUp className="h-4 w-4 text-blue-600" />
      case "desc":
        return <ArrowDown className="h-4 w-4 text-blue-600" />
      case "original":
        return <ArrowUpDown className="h-4 w-4 text-blue-600" />
      default:
        return <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
    }
  }

  const SortableHeader = ({ field, children }: { field: SortField; children: React.ReactNode }) => (
    <TableHead className="px-4 py-2 font-semibold border-r cursor-pointer hover:bg-accent/50 transition-colors bg-muted/50 select-none" onClick={() => handleSort(field)}>
      <div className="flex items-center gap-2">
        <span>{children}</span>
        {getSortIcon(field)}
      </div>
    </TableHead>
  )

  return (
    <div className="space-y-6">
      {/* Header with back button - Mobile: below title, Desktop: back button before title */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Desktop: back button before title, Mobile: title first */}
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          {/* Back button - Desktop: show before title, Mobile: hide here */}
          <Button variant="outline" onClick={onBack} className="gap-2 w-fit hidden md:flex">
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <h1 className="text-xl sm:text-3xl font-bold text-primary tracking-tight">User Management</h1>
        </div>
        <div className="flex items-center justify-between md:justify-end gap-2">
          {/* Back button - Mobile: show here, Desktop: hide */}
          <Button variant="outline" onClick={onBack} className="gap-2 w-fit md:hidden">
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <Button className="evergreen-button" onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add User
          </Button>
        </div>
      </div>

      {/* User Statistics - Hidden on mobile, visible on desktop */}
      <div className="hidden md:grid grid-cols-2 lg:grid-cols-5 gap-3 md:gap-4">
        <Card className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950/60 dark:to-slate-900/60 border-slate-200 dark:border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-slate-600 dark:text-slate-300" />
              <div>
                <p className="text-sm font-medium text-slate-700 dark:text-slate-200">Total Users</p>
                <p className="text-2xl font-bold text-slate-600 dark:text-slate-300">{userStats.total}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950/60 dark:to-emerald-900/60 border-emerald-200 dark:border-emerald-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <UserIcon className="h-4 w-4 text-emerald-600 dark:text-emerald-300" />
              <div>
                <p className="text-sm font-medium text-emerald-700 dark:text-emerald-200">Admins</p>
                <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-300">{userStats.admins}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/60 dark:to-purple-900/60 border-purple-200 dark:border-purple-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <UserCheck className="h-4 w-4 text-purple-600 dark:text-purple-300" />
              <div>
                <p className="text-sm font-medium text-purple-700 dark:text-purple-200">Partners</p>
                <p className="text-2xl font-bold text-purple-600 dark:text-purple-300">{userStats.partners}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950/60 dark:to-orange-900/60 border-orange-200 dark:border-orange-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-orange-600 dark:text-orange-300" />
              <div>
                <p className="text-sm font-medium text-orange-700 dark:text-orange-200">Full Access Internals</p>
                <p className="text-2xl font-bold text-orange-600 dark:text-orange-300">{userStats.internalFullAccess}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/60 dark:to-blue-900/60 border-blue-200 dark:border-blue-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-blue-600 dark:text-blue-300" />
              <div>
                <p className="text-sm font-medium text-blue-700 dark:text-blue-200">Show Access Internals</p>
                <p className="text-2xl font-bold text-blue-600 dark:text-blue-300">{userStats.internalShowAccess}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          {/* Mobile: Stack controls vertically, Desktop: Keep horizontal */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex flex-col md:flex-row md:items-center gap-4 w-full md:w-auto">
              <div className="flex flex-row md:flex-row md:items-center gap-3 w-full md:w-auto">
                <div className="relative flex-1 md:w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground z-10 pointer-events-none" />
                  <Input
                    key={`search-${editing ? 'editing' : 'normal'}`}
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-full"
                  />
                </div>
                {/* Mobile: Non-clickable user count on same line, Desktop: Regular text */}
                <div className="md:hidden flex-shrink-0">
                  <div className="h-10 px-2 flex flex-col items-center justify-center min-w-[60px] gap-0 border border-border rounded-full bg-background">
                    <span className="text-sm font-bold leading-none">{filteredAndSortedUsers.length}</span>
                    <span className="text-xs text-muted-foreground leading-none">Users</span>
                  </div>
                </div>
              </div>
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="w-full md:w-64">
                  <SelectValue placeholder="Role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="partner">Partner</SelectItem>
                  <SelectItem value="internal_full_access">Internal - Full Access</SelectItem>
                  <SelectItem value="internal_show_access">Internal - Show Access</SelectItem>
                </SelectContent>
              </Select>
              <div className="hidden md:block">
                <Badge variant="outline" className="text-xs font-normal">
                  {filteredAndSortedUsers.length} User{filteredAndSortedUsers.length !== 1 ? "s" : ""}
                </Badge>
              </div>
            </div>
            <div className="flex items-center justify-end w-full md:w-auto">
              <Button variant="outline" onClick={handleExportUsers} disabled={filteredAndSortedUsers.length === 0} className="w-full md:w-auto">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              Loading users…
            </div>
          ) : (
            <>
              {/* Mobile Table View - Simplified columns */}
                <div className="md:hidden rounded-md border border-border overflow-hidden">
                  <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="px-3 py-2 font-semibold bg-muted/50 w-1/3 border-r">Name</TableHead>
                      <TableHead className="px-3 py-2 font-semibold bg-muted/50 w-1/6 border-r">Email</TableHead>
                      <TableHead className="px-3 py-2 font-semibold bg-muted/50 w-1/3 border-r">Role</TableHead>
                      <TableHead className="px-3 py-2 font-semibold bg-muted/50 w-1/6">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedUsers.map((u) => (
                      <TableRow key={u.id}>
                        <TableCell 
                          className="font-medium px-3 py-2 cursor-pointer hover:bg-accent/30 transition-colors w-1/3 border-r"
                          onClick={() => { setViewingUser(u); setIsProfileDialogOpen(true); }}
                        >
                          <span className="hover:underline hover:text-emerald-600 transition-colors text-sm whitespace-nowrap">
                            {u.name || "—"}
                          </span>
                        </TableCell>
                        <TableCell className="font-mono px-3 py-2 text-sm truncate w-1/6 whitespace-nowrap border-r">{u.email}</TableCell>
                        <TableCell className="px-3 py-2 w-1/3 border-r">
                          <Badge 
                            className={`text-xs border pointer-events-none uppercase font-semibold whitespace-nowrap ${
                              u.role === 'admin' 
                                ? "bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/50 dark:text-emerald-300 dark:border-emerald-700"
                                : u.role === 'internal_full_access'
                                ? "bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/50 dark:text-orange-300 dark:border-orange-700"
                                : u.role === 'internal_show_access'
                                ? "bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/50 dark:text-blue-300 dark:border-blue-700"
                                : u.role === 'partner'
                                ? "bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/50 dark:text-purple-300 dark:border-purple-700"
                                : "bg-gray-100 text-gray-800 border-gray-300 dark:bg-gray-900/50 dark:text-gray-300 dark:border-gray-700"
                            }`}
                          >
                            {formatRoleName(u.role)}
                          </Badge>
                        </TableCell>
                        <TableCell className="px-3 py-2 w-1/6">
                          <div className="flex items-center gap-1">
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-6 px-2 text-xs"
                              onClick={() => { setViewingUser(u); setIsProfileDialogOpen(true); }}
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              View
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="outline" size="sm" className="h-6 px-2">
                                  <MoreHorizontal className="h-3 w-3" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => openEditor(u)}>
                                  <Pencil className="h-4 w-4 mr-2" />
                                  Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  onClick={() => requestDelete(u)}
                                  disabled={!canDelete(u)}
                                  className="text-red-600 focus:text-red-600"
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                  </Table>
                </div>

              {/* Desktop Table View - Full columns */}
                <div className="hidden md:block rounded-md border border-border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <SortableHeader field="name">Name</SortableHeader>
                      <SortableHeader field="email">Email</SortableHeader>
                      <SortableHeader field="role">Role</SortableHeader>
                      <SortableHeader field="created_at">Created At</SortableHeader>
                      <TableHead className="px-4 py-2 font-semibold border-r bg-muted/50">Mapped Vendor</TableHead>
                      <TableHead className="px-4 py-2 font-semibold bg-muted/50">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedUsers.map((u) => (
                      <TableRow key={u.id}>
                        <TableCell 
                          className="font-medium border-r px-4 py-2 cursor-pointer hover:bg-accent/30 transition-colors"
                          onClick={() => { setViewingUser(u); setIsProfileDialogOpen(true); }}
                        >
                          <span className="hover:underline hover:text-emerald-600 transition-colors">
                            {u.name || "—"}
                          </span>
                        </TableCell>
                        <TableCell className="font-mono border-r px-4 py-2">{u.email}</TableCell>
                        <TableCell className="border-r px-4 py-2">
                          <Badge 
                            className={`text-xs border pointer-events-none uppercase font-semibold ${
                              u.role === 'admin' 
                                ? "bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/50 dark:text-emerald-300 dark:border-emerald-700"
                                : u.role === 'internal_full_access'
                                ? "bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/50 dark:text-orange-300 dark:border-orange-700"
                                : u.role === 'internal_show_access'
                                ? "bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/50 dark:text-blue-300 dark:border-blue-700"
                                : u.role === 'partner'
                                ? "bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/50 dark:text-purple-300 dark:border-purple-700"
                                : "bg-gray-100 text-gray-800 border-gray-300 dark:bg-gray-900/50 dark:text-gray-300 dark:border-gray-700"
                            }`}
                          >
                            {formatRoleName(u.role)}
                          </Badge>
                        </TableCell>
                        <TableCell className="border-r px-4 py-2">
                          {u.created_at ? `${new Date(u.created_at).toLocaleDateString()}, ${new Date(u.created_at).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' })}` : "—"}
                        </TableCell>
                        <TableCell className="border-r px-4 py-2">
                          {u.mapped_vendor_qbo_id != null ? (
                            <span>
                              {u.mapped_vendor_name || "Unknown"}{" "}
                              <span className="text-muted-foreground">· ID {u.mapped_vendor_qbo_id}</span>
                            </span>
                          ) : (
                            "—"
                          )}
                        </TableCell>
                        <TableCell className="px-4 py-2">
                          <div className="flex items-center gap-1">
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-7 px-2"
                              onClick={() => { setViewingUser(u); setIsProfileDialogOpen(true); }}
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              View
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="outline" size="sm" className="h-7 px-2">
                                  <MoreHorizontal className="h-3 w-3" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => openEditor(u)}>
                                  <Pencil className="h-4 w-4 mr-2" />
                                  Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  onClick={() => requestDelete(u)}
                                  disabled={!canDelete(u)}
                                  className="text-red-600 focus:text-red-600"
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                </div>

              {paginatedUsers.length === 0 && (
                <div className="text-center py-12">
                  <div className="mx-auto h-12 w-12 text-muted-foreground mb-4">👥</div>
                  <p className="text-muted-foreground">
                    {searchTerm ? "No users found matching your search." : "No users found."}
                  </p>
                </div>
              )}

              {/* Pagination controls - Centered for mobile */}
              {filteredAndSortedUsers.length > 0 && (
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mt-4">
                  <div className="flex flex-col sm:flex-row items-center gap-3">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="user-page-size" className="text-xs text-muted-foreground whitespace-nowrap">
                        Items per page:
                      </Label>
                      <Select
                        value={PAGE_SIZE.toString()}
                        onValueChange={handlePageSizeChange}
                      >
                        <SelectTrigger id="user-page-size" className="w-20 h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {PAGE_SIZE_OPTIONS.map((size) => (
                            <SelectItem key={size} value={size.toString()}>
                              {size}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <span className="text-xs text-muted-foreground text-center sm:text-left">
                      Showing {Math.min((page - 1) * PAGE_SIZE + 1, filteredAndSortedUsers.length)} to {Math.min(page * PAGE_SIZE, filteredAndSortedUsers.length)} of {filteredAndSortedUsers.length} Users
                    </span>
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setPage(Math.max(1, page - 1))} 
                      disabled={page <= 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                      Prev
                    </Button>
                    <span className="text-xs text-muted-foreground">
                      Page {page} / {totalPages}
                    </span>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setPage(Math.min(totalPages, page + 1))} 
                      disabled={page >= totalPages}
                    >
                      Next
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Nested editor dialog */}
      <Dialog open={!!editing} onOpenChange={(v) => !v && setEditing(null)}>
        <DialogContent className="max-w-none w-full sm:max-w-[700px] md:max-w-[800px] h-screen sm:h-auto mobile-fullscreen flex flex-col p-0 sm:p-0 overflow-hidden border-0 [&>button:not(.navigation-button)]:hidden">
          {/* Mobile Header - full width with title left, close right */}
          <DialogHeader className="flex sm:hidden flex-row items-center justify-between px-6 py-4">
            <div className="flex w-full items-center justify-between gap-3">
              <DialogTitle className="text-lg font-semibold text-left truncate flex-1">
                Edit User
              </DialogTitle>
              <DialogClose asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 !gap-0 relative">
                  <X className="h-4 w-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                  <span className="sr-only">Close</span>
                </Button>
              </DialogClose>
            </div>
          </DialogHeader>

          {/* Desktop Header - title and close button */}
          <DialogHeader className="hidden sm:flex flex-row items-center justify-between px-6 py-4">
            <DialogTitle>Edit User</DialogTitle>
            <DialogClose asChild>
              <Button variant="outline" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 flex items-center justify-center !gap-0">
                <X className="h-4 w-4 m-0" />
                <span className="sr-only">Close</span>
              </Button>
            </DialogClose>
          </DialogHeader>

          {/* Scrollable Content Area - Mobile: with padding and scroll, Desktop: with padding and scroll */}
          <div className="flex-1 overflow-y-auto px-6 py-4 sm:px-6 sm:py-4">
            <form onSubmit={(e) => { e.preventDefault(); saveEdits(); }} className="space-y-4" id="edit-user-form">
              {/* Description - in body, above form fields */}
              <DialogDescription className="text-sm text-muted-foreground text-left">
                Update the user fields of Name, Email, Password, and Mapped Vendor.
              </DialogDescription>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  value={form.name}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                  placeholder="Full name"
                />
              </div>
            <div className="space-y-2">
              <Label htmlFor="email">Username (Email)</Label>
              <div className="relative">
                <Input
                  id="email"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                  placeholder="email@example.com"
                  className={emailError ? "border-red-500" : ""}
                />
                {isCheckingUsername && (
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-900"></div>
                  </div>
                )}
              </div>
              {emailError && <p className="text-sm text-red-500">{emailError}</p>}
            </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">User Type</Label>
              <Input id="role" value={formatRoleName(form.role)} readOnly className="bg-muted/30" />
            </div>

            <div className={form.password ? "grid grid-cols-1 md:grid-cols-2 gap-4" : "space-y-2"}>
              <div className="space-y-2">
                <Label htmlFor="password">Password (leave blank to keep current)</Label>
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={form.password}
                  onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
                  placeholder="••••••••"
                  endAdornment={
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      aria-label={showPassword ? "Hide password" : "Show password"}
                      onClick={() => setShowPassword((v) => !v)}
                      className="group h-full w-10 rounded-r-full rounded-l-none hover:bg-transparent px-0 hover:scale-100 active:scale-100"
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4 transition-transform duration-200 group-active:scale-90" />
                      ) : (
                        <Eye className="h-4 w-4 transition-transform duration-200 group-active:scale-90" />
                      )}
                    </Button>
                  }
                />
              </div>

              {form.password && (
                <div className="space-y-2 animate-in slide-in-from-right-4 duration-300 ease-out">
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    value={form.confirmPassword}
                    onChange={(e) => setForm((f) => ({ ...f, confirmPassword: e.target.value }))}
                    placeholder="Confirm password"
                    endAdornment={
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        aria-label={showConfirmPassword ? "Hide password" : "Show password"}
                        onClick={() => setShowConfirmPassword((v) => !v)}
                        className="group h-full w-10 rounded-r-full rounded-l-none hover:bg-transparent px-0 hover:scale-100 active:scale-100"
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4 transition-transform duration-200 group-active:scale-90" />
                        ) : (
                          <Eye className="h-4 w-4 transition-transform duration-200 group-active:scale-90" />
                        )}
                      </Button>
                    }
                  />
                  {realTimeErrors.confirmPassword && (
                    <p className="text-sm text-red-500">{realTimeErrors.confirmPassword}</p>
                  )}
                </div>
              )}
            </div>

            {isPartner && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Vendor Name as in QBO</Label>
                  <Popover open={vendorPopoverOpen} onOpenChange={setVendorPopoverOpen}>
                    <PopoverTrigger asChild>
                      <Button
                        type="button"
                        variant="outline"
                        role="combobox"
                        className={clsx("w-full justify-between pr-3", !form.mapped_vendor_qbo_id && "text-muted-foreground")}
                      >
                        <span className="truncate text-left flex-1 mr-3 text-sm">
                          {form.mapped_vendor_qbo_id
                            ? `${
                                vendors.find((v) => v.vendor_qbo_id === form.mapped_vendor_qbo_id)?.vendor_name ?? "Unknown"
                              } · ID ${form.mapped_vendor_qbo_id}`
                            : "Select vendor…"}
                        </span>
                        <ChevronsUpDown className="h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                  <CustomPopoverContent className="w-[--radix-popover-trigger-width] p-0" side="bottom" align="start">
                    <Command>
                      <CommandInput placeholder="Search vendor..." />
                      <CommandEmpty>No vendor found.</CommandEmpty>
                      <ScrollArea className="h-52">
                        <CommandGroup>
                        {vendors.map((v) => (
                          <CommandItem
                            key={v.vendor_qbo_id}
                            value={`${v.vendor_name} ${v.vendor_qbo_id}`}
                            onSelect={() => {
                              setForm((f) => ({ ...f, mapped_vendor_qbo_id: v.vendor_qbo_id }))
                              setVendorPopoverOpen(false)
                            }}
                          >
                            <Check
                              className={`mr-2 h-4 w-4 ${
                                form.mapped_vendor_qbo_id === v.vendor_qbo_id
                                  ? "opacity-100"
                                  : "opacity-0"
                              }`}
                            />
                            {v.vendor_name} <span className="text-muted-foreground">· ID {v.vendor_qbo_id}</span>
                          </CommandItem>
                        ))}
                        </CommandGroup>
                      </ScrollArea>
                    </Command>
                  </CustomPopoverContent>
                </Popover>
                </div>
              </div>
            )}
          </form>
        </div>

        {/* Desktop Footer - buttons */}
        <div className="hidden sm:flex items-center justify-end gap-2 px-6 py-4 border-t border-border">
          <Button type="submit" form="edit-user-form" disabled={saving} className="evergreen-button">
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Update User
          </Button>
          <Button type="button" variant="outline" onClick={() => setEditing(null)} disabled={saving}>
            Cancel
          </Button>
        </div>

        {/* Mobile Footer - Sticky footer for mobile only */}
        <div className="sticky bottom-0 bg-background border-t border-border p-6 sm:hidden">
          <div className="space-y-3">
            <Button type="submit" form="edit-user-form" disabled={saving} className="evergreen-button w-full">
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Update User
            </Button>
            <Button type="button" variant="outline" onClick={() => setEditing(null)} disabled={saving} className="w-full">
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-red-600 dark:text-red-400">
              <Trash2 className="h-5 w-5 inline-block mr-2" />
              Delete User
            </AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogDescription>
            This action permanently removes the selected user and cannot be undone.
            Are you sure you want to continue?
          </AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogAction 
              onClick={confirmDelete} 
              disabled={deleting}
              className="evergreen-button-red"
            >
              {deleting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </>
              )}
            </AlertDialogAction>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Create User Dialog */}
      <CreateUserDialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen} onUserCreated={loadUsers} />

      {/* User Profile Dialog */}
      <Dialog open={isProfileDialogOpen} onOpenChange={setIsProfileDialogOpen}>
        <DialogContent className="max-w-none w-full sm:w-[600px] h-screen sm:h-[80vh] mobile-fullscreen flex flex-col p-0 overflow-hidden dark:bg-black border-0 [&>button:not(.navigation-button)]:hidden">
          <DialogHeader className="flex flex-row items-center justify-between px-6 py-4">
            {/* Mobile: Title left, Close right */}
            <div className="flex sm:hidden w-full items-center justify-between gap-3">
              <DialogTitle className="text-lg font-semibold text-left truncate flex-1">
                User Profile
              </DialogTitle>
              <DialogClose asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 !gap-0 relative">
                  <X className="h-4 w-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                  <span className="sr-only">Close</span>
                </Button>
              </DialogClose>
            </div>

            {/* Desktop: Title and Close button */}
            <div className="hidden sm:flex flex-row items-center justify-between w-full">
              <DialogTitle className="text-2xl font-bold">User Profile</DialogTitle>
              <DialogClose asChild>
                <Button variant="outline" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 flex items-center justify-center !gap-0">
                  <X className="h-4 w-4 m-0" />
                  <span className="sr-only">Close</span>
                </Button>
              </DialogClose>
            </div>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto">
            {viewingUser && (
              <div className="space-y-6 p-6">
                {/* User Header with Basic Info */}
                <div className={`p-6 rounded-lg border ${
                  viewingUser.role === 'admin' 
                    ? "bg-gradient-to-r from-emerald-50 to-emerald-100 dark:from-emerald-950/20 dark:to-emerald-900/20 border-emerald-200 dark:border-emerald-800"
                    : viewingUser.role === 'internal_full_access'
                    ? "bg-gradient-to-r from-orange-50 to-orange-100 dark:from-orange-950/20 dark:to-orange-900/20 border-orange-200 dark:border-orange-800"
                    : viewingUser.role === 'internal_show_access'
                    ? "bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-950/20 dark:to-blue-900/20 border-blue-200 dark:border-blue-800"
                    : viewingUser.role === 'partner'
                    ? "bg-gradient-to-r from-purple-50 to-purple-100 dark:from-purple-950/20 dark:to-purple-900/20 border-purple-200 dark:border-purple-800"
                    : "bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-950/20 dark:to-slate-900/20 border-slate-200 dark:border-slate-800"
                }`}>
                  <div className="space-y-4">
                    <div>
                      <h2 className="text-2xl font-bold text-foreground">
                        {viewingUser.name || "Unnamed User"}
                      </h2>
                      <p className="text-lg text-muted-foreground font-mono">
                        {viewingUser.email}
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <Badge 
                          className={`text-xs border pointer-events-none uppercase font-semibold ${
                            viewingUser.role === 'admin' 
                              ? "bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/50 dark:text-emerald-300 dark:border-emerald-700"
                              : viewingUser.role === 'internal_full_access'
                              ? "bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/50 dark:text-orange-300 dark:border-orange-700"
                              : viewingUser.role === 'internal_show_access'
                              ? "bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/50 dark:text-blue-300 dark:border-blue-700"
                              : viewingUser.role === 'partner'
                              ? "bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/50 dark:text-purple-300 dark:border-purple-700"
                              : "bg-gray-100 text-gray-800 border-gray-300 dark:bg-gray-900/50 dark:text-gray-300 dark:border-gray-700"
                          }`}
                        >
                          {formatRoleName(viewingUser.role)}
                        </Badge>
                      </div>
                      {viewingUser.created_at && (
                        <div className="text-sm text-muted-foreground">
                          Member since {new Date(viewingUser.created_at).toLocaleDateString()}, {new Date(viewingUser.created_at).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' })}
                        </div>
                      )}
                    </div>
                  </div>
                </div>


                {/* Vendor Information */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Building className="h-5 w-5 text-emerald-600" />
                      Vendor Mapping
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {viewingUser.mapped_vendor_qbo_id ? (
                      <div className="space-y-3">
                        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 rounded-lg border border-emerald-200 dark:border-emerald-800">
                          <div className="flex items-center gap-2 mb-2">
                            <Building className="h-4 w-4 text-emerald-600" />
                            <span className="font-semibold text-emerald-900 dark:text-emerald-100">
                              {viewingUser.mapped_vendor_name || "Unknown Vendor"}
                            </span>
                          </div>
                          <p className="text-sm text-emerald-700 dark:text-emerald-300 font-mono">
                            QBO ID: {viewingUser.mapped_vendor_qbo_id}
                          </p>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <Building className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                        {viewingUser.role === 'admin' ? (
                          <>
                            <p className="text-muted-foreground font-medium">Admin users cannot be assigned to vendors</p>
                            <p className="text-sm text-muted-foreground mt-1">
                              Admin users have system-wide access and don't require vendor mapping
                            </p>
                          </>
                        ) : (viewingUser.role === 'internal_full_access' || viewingUser.role === 'internal_show_access') ? (
                          <>
                            <p className="text-muted-foreground font-medium">Internal users cannot be assigned to vendors</p>
                            <p className="text-sm text-muted-foreground mt-1">
                              Internal users are company employees and don't need vendor mapping
                            </p>
                          </>
                        ) : (
                          <>
                            <p className="text-muted-foreground">No vendor mapping assigned</p>
                            <p className="text-sm text-muted-foreground mt-1">
                              This partner user is not linked to any vendor in QuickBooks
                            </p>
                          </>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </div>

          {/* Sticky Footer - Mobile: 3 lines full width, Desktop: right side */}
          <div className="sticky bottom-0 bg-background border-t border-border p-6">
            {/* Mobile Layout */}
            <div className="sm:hidden space-y-3">
              <Button 
                onClick={() => { 
                  if (viewingUser) {
                    setIsProfileDialogOpen(false); 
                    openEditor(viewingUser); 
                  }
                }}
                disabled={!viewingUser}
                className={`w-full flex items-center gap-2 ${
                  viewingUser?.role === 'admin' 
                    ? "evergreen-button-admin"
                    : viewingUser?.role === 'internal_full_access'
                    ? "evergreen-button-orange"
                    : viewingUser?.role === 'internal_show_access'
                    ? "evergreen-button-blue"
                    : viewingUser?.role === 'partner'
                    ? "evergreen-button-purple"
                    : "evergreen-button-slate"
                }`}
              >
                <Pencil className="h-4 w-4" />
                Edit User Details
              </Button>
              <Button 
                variant="outline"
                onClick={() => {
                  if (viewingUser) {
                    setIsProfileDialogOpen(false)
                    requestDelete(viewingUser)
                  }
                }}
                disabled={!viewingUser || !canDelete(viewingUser)}
                className="w-full action-button-delete disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete User
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setIsProfileDialogOpen(false)}
                className="w-full bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950/20 dark:to-slate-900/20 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:from-slate-100 hover:to-slate-200 dark:hover:from-slate-900/30 dark:hover:to-slate-800/30"
              >
                Close
              </Button>
            </div>

            {/* Desktop Layout */}
            <div className="hidden sm:flex justify-end gap-3">
              <Button 
                onClick={() => { 
                  if (viewingUser) {
                    setIsProfileDialogOpen(false); 
                    openEditor(viewingUser); 
                  }
                }}
                disabled={!viewingUser}
                className={`flex items-center gap-2 ${
                  viewingUser?.role === 'admin' 
                    ? "evergreen-button-admin"
                    : viewingUser?.role === 'internal_full_access'
                    ? "evergreen-button-orange"
                    : viewingUser?.role === 'internal_show_access'
                    ? "evergreen-button-blue"
                    : viewingUser?.role === 'partner'
                    ? "evergreen-button-purple"
                    : "evergreen-button-slate"
                }`}
              >
                <Pencil className="h-4 w-4" />
                Edit User Details
              </Button>
              <Button 
                variant="outline"
                onClick={() => {
                  if (viewingUser) {
                    setIsProfileDialogOpen(false)
                    requestDelete(viewingUser)
                  }
                }}
                disabled={!viewingUser || !canDelete(viewingUser)}
                className="action-button-delete disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete User
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setIsProfileDialogOpen(false)}
                className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950/20 dark:to-slate-900/20 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:from-slate-100 hover:to-slate-200 dark:hover:from-slate-900/30 dark:hover:to-slate-800/30"
              >
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}