"use client"

import { useState, useEffect, useRef } from "react"
import { useSettings, ThemeColor, ThemeMode, BorderRadiusStyle, DensityMode, CardStyle, DateFormat, TimeFormat, LandingPage, TableDensitySettings } from "@/lib/settings-context"
import { useAuth } from "@/lib/auth-context"
import { useTheme } from "next-themes"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { 
  Sun, Moon, Monitor, RotateCcw, AlertTriangle, 
  Circle, Square, RectangleHorizontal, Hexagon,
  Minimize2, Maximize2, LayoutGrid,
  Layers, BoxSelect, Minus,
  Download, Upload, Database, Loader2,
  Home, Radio, DollarSign, Shield, Archive, Settings,
  HardDrive, RefreshCw,
  Eye, EyeOff
} from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { toast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"
import DeveloperConsole, { useDeveloperLog } from "@/components/developer-console"
import { apiClient, DatabaseStatus } from "@/lib/api-client"
import Image from "next/image"

const PAGE_SIZE_OPTIONS = [5, 10, 12, 15, 20, 25, 50, 100]
const TOAST_DURATION_OPTIONS = [
  { value: 2000, label: "2 seconds" },
  { value: 3000, label: "3 seconds" },
  { value: 5000, label: "5 seconds" },
  { value: 7000, label: "7 seconds" },
  { value: 10000, label: "10 seconds" },
]

const SESSION_TIMEOUT_OPTIONS = [
  { value: 0, label: "Never" },
  { value: 15, label: "15 minutes" },
  { value: 30, label: "30 minutes" },
  { value: 60, label: "1 hour" },
  { value: 120, label: "2 hours" },
]

const FONT_SCALE_OPTIONS = [
  { value: 0.9, label: "Small (90%)" },
  { value: 1, label: "Default (100%)" },
  { value: 1.1, label: "Large (110%)" },
  { value: 1.2, label: "Extra Large (120%)" },
]

const THEME_COLORS: { value: ThemeColor; label: string; color: string }[] = [
  { value: "emerald", label: "Myco (Default)", color: "bg-emerald-500" },
  { value: "blue", label: "Blue", color: "bg-blue-500" },
  { value: "purple", label: "Purple", color: "bg-purple-500" },
  { value: "red", label: "Red", color: "bg-red-500" },
  { value: "orange", label: "Orange", color: "bg-orange-500" },
  { value: "cyan", label: "Cyan", color: "bg-cyan-500" },
  { value: "pink", label: "Pink", color: "bg-pink-500" },
  { value: "indigo", label: "Indigo", color: "bg-indigo-500" },
]

const BORDER_RADIUS_OPTIONS: { value: BorderRadiusStyle; label: string; icon: React.ReactNode; description: string }[] = [
  { value: "circle", label: "Circle", icon: <Circle className="h-4 w-4" />, description: "Fully rounded, pill-shaped buttons" },
  { value: "squircle", label: "Squircle", icon: <Hexagon className="h-4 w-4" />, description: "Smooth, iOS-style rounded corners" },
  { value: "rounded", label: "Rounded", icon: <RectangleHorizontal className="h-4 w-4" />, description: "Standard rounded corners" },
  { value: "square", label: "Square", icon: <Square className="h-4 w-4" />, description: "Sharp, angular corners" },
]

const DENSITY_OPTIONS: { value: DensityMode; label: string; icon: React.ReactNode }[] = [
  { value: "compact", label: "Compact", icon: <Minimize2 className="h-4 w-4" /> },
  { value: "default", label: "Default", icon: <LayoutGrid className="h-4 w-4" /> },
]

const TABLE_DENSITY_LABELS: Record<keyof TableDensitySettings, string> = {
  revenueLedger: "Revenue Ledger",
  shows: "Shows",
}

const CARD_STYLE_OPTIONS: { value: CardStyle; label: string; icon: React.ReactNode; description: string }[] = [
  { value: "bordered", label: "Bordered", icon: <BoxSelect className="h-4 w-4" />, description: "Cards with visible borders" },
  { value: "elevated", label: "Elevated", icon: <Layers className="h-4 w-4" />, description: "Cards with shadow depth" },
  { value: "flat", label: "Flat", icon: <Minus className="h-4 w-4" />, description: "Minimal, flat appearance" },
]

const DATE_FORMAT_OPTIONS: { value: DateFormat; label: string; example: string }[] = [
  { value: "MM/DD/YYYY", label: "MM/DD/YYYY", example: "11/29/2025" },
  { value: "DD/MM/YYYY", label: "DD/MM/YYYY", example: "29/11/2025" },
  { value: "YYYY-MM-DD", label: "YYYY-MM-DD", example: "2025-11-29" },
]

const TIME_FORMAT_OPTIONS: { value: TimeFormat; label: string; example: string }[] = [
  { value: "12h", label: "12-hour", example: "2:30 PM" },
  { value: "24h", label: "24-hour", example: "14:30" },
]

const ALL_LANDING_PAGE_OPTIONS: { value: LandingPage; label: string; icon: React.ReactNode }[] = [
  { value: "dashboard", label: "Dashboard", icon: <Home className="h-4 w-4" /> },
  { value: "shows", label: "Shows", icon: <Radio className="h-4 w-4" /> },
  { value: "revenue", label: "Revenue", icon: <DollarSign className="h-4 w-4" /> },
  { value: "partners", label: "Admin", icon: <Shield className="h-4 w-4" /> },
  { value: "archived", label: "Archived", icon: <Archive className="h-4 w-4" /> },
  { value: "settings", label: "Settings", icon: <Settings className="h-4 w-4" /> },
]

// Helper function to get available landing page options based on user role
function getAvailableLandingPages(role: string | null | undefined): typeof ALL_LANDING_PAGE_OPTIONS {
  if (role === "partner") {
    // Partners only have access to Revenue Ledger and Settings
    return ALL_LANDING_PAGE_OPTIONS.filter(option => 
      option.value === "revenue" || option.value === "settings"
    )
  } else if (role === "internal_show_access") {
    // Internal Show Access only has access to Shows and Settings
    return ALL_LANDING_PAGE_OPTIONS.filter(option => 
      option.value === "shows" || option.value === "settings"
    )
  } else if (role === "admin") {
    // Admin has access to all pages
    return ALL_LANDING_PAGE_OPTIONS
  } else {
    // Internal Full Access: Dashboard, Shows, Revenue, Archived, Settings (but NOT Admin/partners)
    return ALL_LANDING_PAGE_OPTIONS.filter(option => 
      option.value !== "partners"
    )
  }
}

export default function SettingsPage() {
  const { settings, updateSettings, resetSettings, setThemeMode, addDeveloperLog } = useSettings()
  const { user } = useAuth()
  
  // Get available landing pages based on user role
  const availableLandingPages = getAvailableLandingPages(user?.role)
  const { theme, setTheme } = useTheme()
  const [showResetConfirm, setShowResetConfirm] = useState(false)
  const [showDeveloperOptionsConfirm, setShowDeveloperOptionsConfirm] = useState(false)
  const [developerButtonClickCount, setDeveloperButtonClickCount] = useState(0)
  const developerButtonTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const [isDark, setIsDark] = useState(false)
  
  // Database operations state
  const [isExporting, setIsExporting] = useState(false)
  const [isImporting, setIsImporting] = useState(false)
  const [dbStatus, setDbStatus] = useState<DatabaseStatus | null>(null)
  const [isLoadingDbStatus, setIsLoadingDbStatus] = useState(false)
  const [showImportConfirm, setShowImportConfirm] = useState(false)
  const [pendingImportFile, setPendingImportFile] = useState<File | null>(null)
  const [importMode, setImportMode] = useState<"full_replace_fast" | "full_replace_safe">("full_replace_fast")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const importJobPollingRef = useRef<NodeJS.Timeout | null>(null)
  const importJobIdRef = useRef<string | null>(null)
  
  const devLog = useDeveloperLog()

  // Role helpers (must be defined before effects that use them)
  const canAccessDeveloperOptions = user?.role === "admin" || 
                                    user?.role === "internal_full_access" || 
                                    user?.role === "internal_show_access"
  
  const isAdmin = user?.role === "admin"

  // Sync next-themes with our settings when themeMode changes from server
  useEffect(() => {
    if (settings.themeMode && settings.themeMode !== theme) {
      setTheme(settings.themeMode)
    }
  }, [settings.themeMode]) // eslint-disable-line react-hooks/exhaustive-deps

  // Check theme for logo
  useEffect(() => {
    const checkTheme = () => {
      setIsDark(document.documentElement.classList.contains("dark"))
    }
    checkTheme()

    const observer = new MutationObserver(checkTheme)
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    })

    return () => observer.disconnect()
  }, [])

  // Reset developer button click count if timeout expires
  useEffect(() => {
    if (developerButtonClickCount > 0) {
      if (developerButtonTimeoutRef.current) {
        clearTimeout(developerButtonTimeoutRef.current)
      }
      developerButtonTimeoutRef.current = setTimeout(() => {
        setDeveloperButtonClickCount(0)
      }, 2000) // Reset if no click within 2 seconds
    }

    return () => {
      if (developerButtonTimeoutRef.current) {
        clearTimeout(developerButtonTimeoutRef.current)
      }
    }
  }, [developerButtonClickCount])

  // Handler to update both next-themes and our settings
  const handleThemeChange = (mode: ThemeMode) => {
    setTheme(mode) // Update next-themes immediately for UI
    setThemeMode(mode) // Update our settings (will sync to server)
  }

  const handleReset = () => {
    resetSettings()
    setShowResetConfirm(false)
    toast({
      title: "Settings reset",
      description: "All settings have been reset to defaults.",
    })
  }

  const handleDeveloperOptionsToggle = (checked: boolean) => {
    if (checked) {
      // Show confirmation dialog when enabling
      setShowDeveloperOptionsConfirm(true)
    } else {
      // Disable directly without confirmation
      updateSettings({ developerOptionsEnabled: false })
      // Reset developer settings when disabled
      updateSettings({ debugMode: false, apiEndpointOverride: null, showApiResponseTimes: false })
    }
  }

  const handleConfirmDeveloperOptions = () => {
    updateSettings({ developerOptionsEnabled: true })
    setShowDeveloperOptionsConfirm(false)
    addDeveloperLog("success", "Developer options enabled")
  }

  const handleDisableDeveloperOptions = () => {
    updateSettings({ developerOptionsEnabled: false })
    // Reset developer settings when disabled
    updateSettings({ debugMode: false, apiEndpointOverride: null, showApiResponseTimes: false })
    setShowDeveloperOptionsConfirm(false)
    addDeveloperLog("info", "Developer options disabled")
  }

  const handleCancelDeveloperOptions = () => {
    setShowDeveloperOptionsConfirm(false)
  }

  const handleDeveloperButtonClick = () => {
    if (!isAdmin) return

    const newCount = developerButtonClickCount + 1
    setDeveloperButtonClickCount(newCount)

    if (newCount >= 7) {
      setDeveloperButtonClickCount(0)
      // Always show the dialog, regardless of whether developer options are already enabled
      setShowDeveloperOptionsConfirm(true)
      if (developerButtonTimeoutRef.current) {
        clearTimeout(developerButtonTimeoutRef.current)
      }
    }
  }

  const handleGlobalPageSizeChange = (value: string) => {
    if (value === "individual") {
      updateSettings({ globalPageSize: null })
    } else {
      updateSettings({ globalPageSize: parseInt(value) })
    }
  }

  const handleIndividualPageSizeChange = (page: keyof typeof settings.pagination, value: string) => {
    updateSettings({
      pagination: {
        ...settings.pagination,
        [page]: parseInt(value),
      },
    })
  }
  
  // Database operations
  const handleExportDatabase = async () => {
    setIsExporting(true)
    devLog.command("Initiating database export...")
    
    try {
      devLog.log("Connecting to database server...")
      const blob = await apiClient.exportDatabase()
      
      devLog.log("Generating SQL dump file...")
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `evergreen_backup_${new Date().toISOString().split('T')[0]}.sql`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      
      devLog.success("Database export completed successfully", `File size: ${(blob.size / 1024 / 1024).toFixed(2)} MB`)
      toast({ title: "Export complete", description: "Database backup has been downloaded." })
    } catch (error: any) {
      devLog.error("Database export failed", error.message)
      toast({ title: "Export failed", description: error.message, variant: "destructive" })
    } finally {
      setIsExporting(false)
    }
  }
  
  const handleImportDatabase = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return
    
    // Store the file and show confirmation dialog
    setPendingImportFile(file)
    setShowImportConfirm(true)
    
    // Clear the input so the same file can be selected again if cancelled
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }
  
  const handleConfirmImport = async () => {
    if (!pendingImportFile) return
    
    setIsImporting(true)
    setShowImportConfirm(false)
    devLog.command(`Importing database from: ${pendingImportFile.name}`)
    
    try {
      devLog.log("Validating SQL file...")
      devLog.log("Uploading to server...")
      
      const result = await apiClient.importDatabase(pendingImportFile, {
        mode: importMode,
      })

      // If the server accepted the request as an async job, poll until completion.
      if (result.job_id) {
        devLog.success("Database import started", `Job: ${result.job_id}`)
        toast({ title: "Import started", description: "Import is running on the server. This may take a few minutes." })

        const jobId = result.job_id
        importJobIdRef.current = jobId
        try {
          localStorage.setItem("evergreen_last_import_job_id", jobId)
          localStorage.setItem("evergreen_last_import_job_started_at", new Date().toISOString())
        } catch {}
        let lastStatus: string | null = null
        const startedAt = Date.now()
        const maxWaitMs = 30 * 60 * 1000 // 30 minutes (matches server import timeout)

        while (Date.now() - startedAt < maxWaitMs) {
          await new Promise((r) => setTimeout(r, 1500))
          let job: any
          try {
            job = await apiClient.getDatabaseImportJob(jobId)
          } catch (e: any) {
            const msg = e?.message || "Failed to poll import job status"
            if (typeof msg === "string" && msg.includes("Authentication required")) {
              devLog.error("Import job polling stopped", "Authentication required. Please log in again to continue tracking the import job.")
              toast({
                title: "Session expired",
                description: "Please log in again to continue tracking the import progress.",
                variant: "destructive",
              })
              break
            }
            // During full-replace, the DB may be temporarily unavailable; keep polling.
            devLog.warn("Import job poll warning", msg)
            continue
          }
          if (job.status !== lastStatus) {
            devLog.log("Import job status", `${job.status}${job.message ? ` – ${job.message}` : ""}`)
            lastStatus = job.status
          }
          if (job.status === "succeeded" || job.status === "failed") {
            if (job.result) {
              const final = job.result
              if (final.warnings && final.warnings.length > 0) {
                final.warnings.forEach(warning => devLog.warn("Import warning", warning))
              }
              if (final.success) {
                if (final.warnings && final.warnings.length > 0) {
                  devLog.warn("Database import completed with warnings", `Tables affected: ${final.tables_affected || 'unknown'}. Check warnings above.`)
                  toast({ title: "Import completed with warnings", description: final.message, variant: "default" })
                } else {
                  devLog.success("Database import completed", `Tables affected: ${final.tables_affected || 'unknown'}`)
                  toast({ title: "Import complete", description: final.message })
                }
              } else {
                devLog.error("Database import failed", final.message)
                toast({ title: "Import failed", description: final.message, variant: "destructive" })
              }
            } else {
              const msg = job.error || job.message || "Import finished."
              if (job.status === "succeeded") {
                devLog.success("Database import completed", msg)
                toast({ title: "Import complete", description: msg })
              } else {
                devLog.error("Database import failed", msg)
                toast({ title: "Import failed", description: msg, variant: "destructive" })
              }
            }
            break
          }
        }

        // Refresh status at end (best-effort)
        try {
          await handleRefreshDbStatus()
        } catch {}

        // Clear persisted job id once finished
        try {
          localStorage.removeItem("evergreen_last_import_job_id")
          localStorage.removeItem("evergreen_last_import_job_started_at")
        } catch {}
        importJobIdRef.current = null
        return
      }
      
      if (result.warnings && result.warnings.length > 0) {
        result.warnings.forEach(warning => devLog.warn("Import warning", warning))
      }
      
      // Show appropriate success/warning message
      if (result.success) {
        if (result.warnings && result.warnings.length > 0) {
          devLog.warn("Database import completed with warnings", `Tables affected: ${result.tables_affected || 'unknown'}. Check warnings above.`)
          toast({ 
            title: "Import completed with warnings", 
            description: result.message,
            variant: "default"
          })
        } else {
          devLog.success("Database import completed", `Tables affected: ${result.tables_affected || 'unknown'}`)
          toast({ title: "Import complete", description: result.message })
        }
      } else {
        devLog.error("Database import failed", result.message)
        toast({ 
          title: "Import failed", 
          description: result.message,
          variant: "destructive"
        })
      }
      
      // Refresh database status (handle auth errors gracefully)
      try {
        await handleRefreshDbStatus()
      } catch (refreshError: any) {
        // If session expired during long import, just log it as info, not an error
        if (refreshError.message?.includes("Authentication required")) {
          devLog.log("Session may have expired during import. Database status refresh skipped.")
          toast({
            title: "Import complete",
            description: "Import finished, but your session expired while refreshing database status. Please log in again to refresh status.",
          })
          // Don't show toast for auth errors after import - the import itself succeeded
        } else {
          // For other errors, log but don't block
          devLog.warn("Could not refresh database status", refreshError.message)
        }
      }
    } catch (error: any) {
      devLog.error("Database import failed", error.message)
      toast({ title: "Import failed", description: error.message, variant: "destructive" })
    } finally {
      setIsImporting(false)
      setPendingImportFile(null)
    }
  }
  
  const handleCancelImport = () => {
    setShowImportConfirm(false)
    setPendingImportFile(null)
  }
  
  const handleRefreshDbStatus = async () => {
    setIsLoadingDbStatus(true)
    try {
      const status = await apiClient.getDatabaseStatus()
      setDbStatus(status)
      if (status.warning) {
        devLog.warn("Database status retrieved with warnings", status.warning)
      } else {
        devLog.success("Database status retrieved", `Tables: ${status.total_tables}, Rows: ${status.total_rows}, Size: ${status.total_size_mb} MB`)
      }
    } catch (error: any) {
      const errorMessage = error.message || "Unknown error occurred"
      if (errorMessage.includes("Authentication required")) {
        devLog.log("Authentication required for database status", errorMessage)
        toast({
          title: "Authentication required",
          description: "Please log in again.",
        })
        return
      }
      if (errorMessage.includes("Endpoint not found")) {
        devLog.warn("Database status endpoint unavailable", errorMessage)
        return
      }
      // Only show error toast for genuine failures
      {
        devLog.error("Failed to get database status", errorMessage)
        toast({
          title: "Database Status Error",
          description: errorMessage,
          variant: "destructive"
        })
      }
    } finally {
      setIsLoadingDbStatus(false)
    }
  }
  
  // Load database status when developer options are enabled
  useEffect(() => {
    if (settings.developerOptionsEnabled && isAdmin && !dbStatus) {
      handleRefreshDbStatus()
    }
  }, [settings.developerOptionsEnabled, isAdmin]) // eslint-disable-line react-hooks/exhaustive-deps

  // Resume polling an in-flight import job after page refresh.
  useEffect(() => {
    if (!settings.developerOptionsEnabled || !isAdmin) return
    let jobId: string | null = null
    try {
      jobId = localStorage.getItem("evergreen_last_import_job_id")
    } catch {
      jobId = null
    }
    if (!jobId) return
    if (importJobIdRef.current === jobId) return
    importJobIdRef.current = jobId

    devLog.log("Resuming import job polling", `Job: ${jobId}`)

    const tick = async () => {
      try {
        const job = await apiClient.getDatabaseImportJob(jobId as string)
        if (job.status === "succeeded" || job.status === "failed") {
          devLog.log("Import job status", `${job.status}${job.message ? ` – ${job.message}` : ""}`)
          if (job.result) {
            const final = job.result
            if (final.warnings && final.warnings.length > 0) {
              final.warnings.forEach(warning => devLog.warn("Import warning", warning))
            }
            if (final.success) {
              devLog.success("Database import completed", final.message)
              toast({ title: "Import complete", description: final.message })
            } else {
              devLog.error("Database import failed", final.message)
              toast({ title: "Import failed", description: final.message, variant: "destructive" })
            }
          } else {
            const msg = job.error || job.message || "Import finished."
            if (job.status === "succeeded") {
              devLog.success("Database import completed", msg)
              toast({ title: "Import complete", description: msg })
            } else {
              devLog.error("Database import failed", msg)
              toast({ title: "Import failed", description: msg, variant: "destructive" })
            }
          }
          try {
            localStorage.removeItem("evergreen_last_import_job_id")
            localStorage.removeItem("evergreen_last_import_job_started_at")
          } catch {}
          importJobIdRef.current = null
          if (importJobPollingRef.current) {
            clearInterval(importJobPollingRef.current)
            importJobPollingRef.current = null
          }
          // best-effort refresh
          try { await handleRefreshDbStatus() } catch {}
        }
      } catch (e: any) {
        const msg = e?.message || "Failed to poll import job status"
        if (typeof msg === "string" && msg.includes("Authentication required")) {
          devLog.error("Import job polling stopped", "Authentication required. Please log in again to continue tracking the import job.")
          toast({
            title: "Session expired",
            description: "Please log in again to continue tracking the import progress.",
            variant: "destructive",
          })
          try {
            localStorage.removeItem("evergreen_last_import_job_id")
            localStorage.removeItem("evergreen_last_import_job_started_at")
          } catch {}
          importJobIdRef.current = null
          if (importJobPollingRef.current) {
            clearInterval(importJobPollingRef.current)
            importJobPollingRef.current = null
          }
          return
        }
        if (typeof msg === "string" && msg.toLowerCase().includes("import job tracking is unavailable")) {
          devLog.warn("Import job tracking unavailable", msg)
          toast({
            title: "Tracking unavailable",
            description: "Import is running, but this server can’t report job progress yet. Deploy the latest backend to enable tracking.",
          })
          try {
            localStorage.removeItem("evergreen_last_import_job_id")
            localStorage.removeItem("evergreen_last_import_job_started_at")
          } catch {}
          importJobIdRef.current = null
          if (importJobPollingRef.current) {
            clearInterval(importJobPollingRef.current)
            importJobPollingRef.current = null
          }
          return
        }
        // DB may be mid-replace; keep polling.
        devLog.warn("Import job poll warning", msg)
      }
    }

    tick()
    importJobPollingRef.current = setInterval(tick, 1500)
    return () => {
      if (importJobPollingRef.current) {
        clearInterval(importJobPollingRef.current)
        importJobPollingRef.current = null
      }
    }
  }, [settings.developerOptionsEnabled, isAdmin]) // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-3xl font-bold text-primary tracking-tight">
          Settings
        </h1>
        <p className="text-sm text-muted-foreground md:text-base">
          Manage your application preferences and customization options.
        </p>
      </div>

      {/* Appearance Section */}
      <div className="grid gap-6 md:grid-cols-1">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg md:text-xl">
              Appearance
            </CardTitle>
            <CardDescription className="text-sm text-muted-foreground">
              Customize the look and feel of the application.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0 px-6 pb-6">
            <div className="grid gap-6 md:grid-cols-2">
              {/* Left Column */}
              <div className="flex flex-col gap-6">
                {/* Theme Preference */}
                {/* Mobile: Direct content */}
                <div className="md:hidden py-4 border-b border-border/50">
                  <h3 className="text-base font-semibold mb-1">Theme Preference</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Choose your preferred color theme.
                  </p>
                  <div className="flex gap-2 items-center">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleThemeChange("light")}
                      className={cn(
                        "w-auto",
                        theme === "light" && "evergreen-button"
                      )}
                    >
                      <Sun className="mr-2 h-4 w-4" />
                      Light
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleThemeChange("dark")}
                      className={cn(
                        "w-auto",
                        theme === "dark" && "evergreen-button"
                      )}
                    >
                      <Moon className="mr-2 h-4 w-4" />
                      Dark
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleThemeChange("system")}
                      className={cn(
                        "w-auto",
                        theme === "system" && "evergreen-button"
                      )}
                    >
                      <Monitor className="mr-2 h-4 w-4" />
                      System
                    </Button>
                  </div>
                </div>

                {/* Desktop: Card wrapper */}
                <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                  <CardHeader className="p-6">
                    <CardTitle className="text-base">Theme Preference</CardTitle>
                    <CardDescription className="text-sm">
                      Choose your preferred color theme.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 px-6 pb-6">
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleThemeChange("light")}
                        className={cn(
                          theme === "light" && "evergreen-button"
                        )}
                      >
                        <Sun className="mr-2 h-4 w-4" />
                        Light
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleThemeChange("dark")}
                        className={cn(
                          theme === "dark" && "evergreen-button"
                        )}
                      >
                        <Moon className="mr-2 h-4 w-4" />
                        Dark
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleThemeChange("system")}
                        className={cn(
                          theme === "system" && "evergreen-button"
                        )}
                      >
                        <Monitor className="mr-2 h-4 w-4" />
                        System
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Theme Color */}
                {/* Mobile: Direct content */}
                <div className="md:hidden py-4 border-b border-border/50">
                  <h3 className="text-base font-semibold mb-1">Theme Color</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Choose the accent color for buttons and interactive elements.
                  </p>
                  <Select
                    value={settings.themeColor}
                    onValueChange={(value) => updateSettings({ themeColor: value as ThemeColor })}
                  >
                    <SelectTrigger id="theme-color-mobile" className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {THEME_COLORS.map((color) => (
                        <SelectItem key={color.value} value={color.value}>
                          <div className="flex items-center gap-2">
                            <div className={cn("h-4 w-4 rounded-full", color.color)} />
                            {color.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Desktop: Card wrapper */}
                <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                  <CardHeader className="p-6">
                    <CardTitle className="text-base">Theme Color</CardTitle>
                    <CardDescription className="text-sm">
                      Choose the accent color for buttons and interactive elements.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 px-6 pb-6">
                    <Select
                      value={settings.themeColor}
                      onValueChange={(value) => updateSettings({ themeColor: value as ThemeColor })}
                    >
                      <SelectTrigger id="theme-color" className="w-full max-w-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {THEME_COLORS.map((color) => (
                          <SelectItem key={color.value} value={color.value}>
                            <div className="flex items-center gap-2">
                              <div className={cn("h-4 w-4 rounded-full", color.color)} />
                              {color.label}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                {/* Button Shape */}
                {/* Mobile: Direct content */}
                <div className="md:hidden py-4 border-b border-border/50">
                  <h3 className="text-base font-semibold mb-1">Button Shape</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Choose the corner style for buttons and UI elements.
                  </p>
                  <div className="flex gap-2 flex-wrap items-center">
                    {BORDER_RADIUS_OPTIONS.map((option) => (
                      <Button
                        key={option.value}
                        variant="outline"
                        size="sm"
                        onClick={() => updateSettings({ borderRadiusStyle: option.value })}
                        className={cn(
                          "w-auto",
                          settings.borderRadiusStyle === option.value && "evergreen-button"
                        )}
                      >
                        {option.icon}
                        <span className="ml-2">{option.label}</span>
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Desktop: Card wrapper */}
                <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                  <CardHeader className="p-6">
                    <CardTitle className="text-base">Button Shape</CardTitle>
                    <CardDescription className="text-sm">
                      Choose the corner style for buttons and UI elements.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 px-6 pb-6">
                  <div className="flex gap-2 flex-wrap items-center">
                    {BORDER_RADIUS_OPTIONS.map((option) => (
                      <Button
                        key={option.value}
                        variant="outline"
                        size="sm"
                        onClick={() => updateSettings({ borderRadiusStyle: option.value })}
                        className={cn(
                          "w-auto",
                          settings.borderRadiusStyle === option.value && "evergreen-button"
                        )}
                      >
                        {option.icon}
                        <span className="ml-2">{option.label}</span>
                      </Button>
                    ))}
                  </div>
          </CardContent>
        </Card>

                {/* Table Density */}
                {/* Mobile: Direct content */}
                <div className="md:hidden py-4 border-b border-border/50">
                  <h3 className="text-base font-semibold mb-1">Table Density</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Adjust spacing for individual tables.
                  </p>
                  <div className="space-y-3">
                    {(Object.keys(TABLE_DENSITY_LABELS) as Array<keyof TableDensitySettings>).map((tableKey, index, array) => (
                      <div key={tableKey}>
                        <div className="flex items-center justify-between gap-4">
                          <Label className="text-sm font-medium">{TABLE_DENSITY_LABELS[tableKey]}</Label>
                          <div className="flex gap-2">
                            {DENSITY_OPTIONS.map((option) => (
                              <Button
                                key={option.value}
                                variant="outline"
                                size="sm"
                                onClick={() => updateSettings({ 
                                  tableDensity: {
                                    ...settings.tableDensity,
                                    [tableKey]: option.value
                                  }
                                })}
                                className={cn(
                                  "w-auto",
                                  settings.tableDensity[tableKey] === option.value && "evergreen-button"
                                )}
                              >
                                {option.icon}
                                <span className="ml-2">{option.label}</span>
                              </Button>
                            ))}
                          </div>
                        </div>
                        {index < array.length - 1 && <Separator className="mt-3" />}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Desktop: Card wrapper */}
                <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                  <CardHeader className="p-6">
                    <CardTitle className="text-base">Table Density</CardTitle>
                    <CardDescription className="text-sm">
                      Adjust spacing for individual tables.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 px-6 pb-6">
                    <div className="space-y-3">
                      {(Object.keys(TABLE_DENSITY_LABELS) as Array<keyof TableDensitySettings>).map((tableKey, index, array) => (
                        <div key={tableKey}>
                          <div className="flex items-center justify-between gap-4">
                            <Label className="text-sm font-medium">{TABLE_DENSITY_LABELS[tableKey]}</Label>
                            <div className="flex gap-2">
                              {DENSITY_OPTIONS.map((option) => (
                                <Button
                                  key={option.value}
                                  variant="outline"
                                  size="sm"
                                  onClick={() => updateSettings({ 
                                    tableDensity: {
                                      ...settings.tableDensity,
                                      [tableKey]: option.value
                                    }
                                  })}
                                  className={cn(
                                    "w-auto",
                                    settings.tableDensity[tableKey] === option.value && "evergreen-button"
                                  )}
                                >
                                  {option.icon}
                                  <span className="ml-2">{option.label}</span>
                                </Button>
                              ))}
                            </div>
                          </div>
                          {index < array.length - 1 && <Separator className="mt-3" />}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Right Column */}
              <div className="flex flex-col gap-6">
                {/* Card Style */}
                {/* Mobile: Direct content */}
                <div className="md:hidden py-4 border-b border-border/50">
                  <h3 className="text-base font-semibold mb-1">Card Style</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Choose how cards and containers appear.
                  </p>
                  <div className="flex gap-2 items-center">
                    {CARD_STYLE_OPTIONS.map((option) => (
                      <Button
                        key={option.value}
                        variant="outline"
                        size="sm"
                        onClick={() => updateSettings({ cardStyle: option.value })}
                        className={cn(
                          "w-auto",
                          settings.cardStyle === option.value && "evergreen-button"
                        )}
                      >
                        {option.icon}
                        <span className="ml-2">{option.label}</span>
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Desktop: Card wrapper */}
                <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                  <CardHeader className="p-6">
                    <CardTitle className="text-base">Card Style</CardTitle>
                    <CardDescription className="text-sm">
                      Choose how cards and containers appear.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 px-6 pb-6">
                    <div className="flex gap-2">
                      {CARD_STYLE_OPTIONS.map((option) => (
                        <Button
                          key={option.value}
                          variant="outline"
                          size="sm"
                          onClick={() => updateSettings({ cardStyle: option.value })}
                          className={cn(
                            settings.cardStyle === option.value && "evergreen-button"
                          )}
                        >
                          {option.icon}
                          <span className="ml-2">{option.label}</span>
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Font Size */}
                {/* Mobile: Direct content */}
                <div className="md:hidden py-4 border-b border-border/50">
                  <h3 className="text-base font-semibold mb-1">Font Size</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Adjust the text size throughout the application.
                  </p>
                  <Select
                    value={settings.fontScale.toString()}
                    onValueChange={(value) => updateSettings({ fontScale: parseFloat(value) })}
                  >
                    <SelectTrigger id="font-scale-mobile" className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {FONT_SCALE_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value.toString()}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Desktop: Card wrapper */}
                <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                  <CardHeader className="p-6">
                    <CardTitle className="text-base">Font Size</CardTitle>
                    <CardDescription className="text-sm">
                      Adjust the text size throughout the application.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 px-6 pb-6">
                    <Select
                      value={settings.fontScale.toString()}
                      onValueChange={(value) => updateSettings({ fontScale: parseFloat(value) })}
                    >
                      <SelectTrigger id="font-scale" className="w-full max-w-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {FONT_SCALE_OPTIONS.map((option) => (
                          <SelectItem key={option.value} value={option.value.toString()}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                {/* Visual Effects Toggles */}
                {/* Mobile: Direct content */}
                <div className="md:hidden py-4 border-b border-border/50">
                  <h3 className="text-base font-semibold mb-4">Visual Effects</h3>
                  <div className="space-y-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium">Liquid Glass Effect</h4>
                        <p className="text-xs text-muted-foreground">
                          Blur and glass effects across the website.
                        </p>
                      </div>
                      <Switch
                        checked={settings.liquidGlassEnabled}
                        onCheckedChange={(checked) => updateSettings({ liquidGlassEnabled: checked })}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium">Interactive Animations</h4>
                        <p className="text-xs text-muted-foreground">
                          Hover and click animations.
                        </p>
                      </div>
                      <Switch
                        checked={settings.interactiveAnimationsEnabled}
                        onCheckedChange={(checked) => updateSettings({ interactiveAnimationsEnabled: checked })}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium">Shadows</h4>
                        <p className="text-xs text-muted-foreground">
                          Drop shadows on elements.
                        </p>
                      </div>
                      <Switch
                        checked={settings.shadowsEnabled}
                        onCheckedChange={(checked) => updateSettings({ shadowsEnabled: checked })}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium">Reduce Motion</h4>
                        <p className="text-xs text-muted-foreground">
                          Minimize animations for accessibility.
                        </p>
                      </div>
                      <Switch
                        checked={settings.reduceMotion}
                        onCheckedChange={(checked) => updateSettings({ reduceMotion: checked })}
                      />
                    </div>
                  </div>
              </div>

                {/* Desktop: Card wrapper */}
                <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                  <CardHeader className="p-6">
                    <CardTitle className="text-base">Visual Effects</CardTitle>
                    <CardDescription className="text-sm">
                      Toggle visual effects and animations.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 px-6 pb-6 space-y-4">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1">
                        <div className="text-sm font-medium">Liquid Glass Effect</div>
                        <div className="text-xs text-muted-foreground">Blur and glass effects</div>
                      </div>
                      <Switch
                        checked={settings.liquidGlassEnabled}
                        onCheckedChange={(checked) => updateSettings({ liquidGlassEnabled: checked })}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1">
                        <div className="text-sm font-medium">Interactive Animations</div>
                        <div className="text-xs text-muted-foreground">Hover and click animations</div>
                      </div>
                      <Switch
                        checked={settings.interactiveAnimationsEnabled}
                        onCheckedChange={(checked) => updateSettings({ interactiveAnimationsEnabled: checked })}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1">
                        <div className="text-sm font-medium">Shadows</div>
                        <div className="text-xs text-muted-foreground">Drop shadows on elements</div>
                      </div>
                      <Switch
                        checked={settings.shadowsEnabled}
                        onCheckedChange={(checked) => updateSettings({ shadowsEnabled: checked })}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1">
                        <div className="text-sm font-medium">Reduce Motion</div>
                        <div className="text-xs text-muted-foreground">Minimize animations</div>
                      </div>
                      <Switch
                        checked={settings.reduceMotion}
                        onCheckedChange={(checked) => updateSettings({ reduceMotion: checked })}
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Localization & Behavior Section */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Localization */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg md:text-xl">Localization</CardTitle>
            <CardDescription className="text-sm text-muted-foreground">
              Configure date and time formats.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0 px-6 pb-6">
            <div className="grid gap-6 md:grid-cols-1">
                {/* Mobile: Direct content */}
                <div className="md:hidden py-4 border-b border-border/50">
                <h3 className="text-base font-semibold mb-1">Date Format</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                  Choose how dates are displayed.
                  </p>
                  <Select
                  value={settings.dateFormat}
                  onValueChange={(value) => updateSettings({ dateFormat: value as DateFormat })}
                  >
                  <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                    {DATE_FORMAT_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        <div className="flex items-center justify-between gap-4">
                          <span>{option.label}</span>
                          <span className="text-muted-foreground">({option.example})</span>
                        </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

              {/* Desktop: Card wrapper */}
              <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                <CardHeader className="p-6">
                  <CardTitle className="text-base">Date Format</CardTitle>
                  <CardDescription className="text-sm">
                    Choose how dates are displayed.
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0 px-6 pb-6">
                  <Select
                    value={settings.dateFormat}
                    onValueChange={(value) => updateSettings({ dateFormat: value as DateFormat })}
                  >
                    <SelectTrigger className="w-full max-w-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {DATE_FORMAT_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div className="flex items-center gap-2">
                            <span>{option.label}</span>
                            <span className="text-muted-foreground">({option.example})</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>

              {/* Mobile: Direct content */}
              <div className="md:hidden py-4 border-b border-border/50">
                <h3 className="text-base font-semibold mb-1">Time Format</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Choose 12-hour or 24-hour time display.
                </p>
                <div className="flex gap-2 items-center">
                  {TIME_FORMAT_OPTIONS.map((option) => (
                    <Button
                      key={option.value}
                      variant="outline"
                      size="sm"
                      onClick={() => updateSettings({ timeFormat: option.value })}
                      className={cn(
                        "w-auto",
                        settings.timeFormat === option.value && "evergreen-button"
                      )}
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
                </div>

              {/* Desktop: Card wrapper */}
              <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                <CardHeader className="p-6">
                  <CardTitle className="text-base">Time Format</CardTitle>
                  <CardDescription className="text-sm">
                    Choose 12-hour or 24-hour time display.
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0 px-6 pb-6">
                  <div className="flex gap-2">
                    {TIME_FORMAT_OPTIONS.map((option) => (
                      <Button
                        key={option.value}
                        variant="outline"
                        size="sm"
                        onClick={() => updateSettings({ timeFormat: option.value })}
                        className={cn(
                          settings.timeFormat === option.value && "evergreen-button"
                        )}
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>

        {/* Behavior */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg md:text-xl">Behavior</CardTitle>
            <CardDescription className="text-sm text-muted-foreground">
              Configure application behavior.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0 px-6 pb-6">
            <div className="grid gap-6 md:grid-cols-1">
              {/* Mobile: Direct content */}
              <div className="md:hidden py-4 border-b border-border/50">
                <h3 className="text-base font-semibold mb-1">Default Landing Page</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Choose which page to show after login.
                </p>
                  <Select
                  value={settings.defaultLandingPage}
                  onValueChange={(value) => updateSettings({ defaultLandingPage: value as LandingPage })}
                  >
                  <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                    {availableLandingPages.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        <div className="flex items-center gap-2">
                          {option.icon}
                          <span>{option.label}</span>
                        </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

              {/* Desktop: Card wrapper */}
              <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                <CardHeader className="p-6">
                  <CardTitle className="text-base">Default Landing Page</CardTitle>
                  <CardDescription className="text-sm">
                    Choose which page to show after login.
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0 px-6 pb-6">
                  <Select
                    value={settings.defaultLandingPage}
                    onValueChange={(value) => updateSettings({ defaultLandingPage: value as LandingPage })}
                  >
                    <SelectTrigger className="w-full max-w-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {availableLandingPages.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div className="flex items-center gap-2">
                            {option.icon}
                            <span>{option.label}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>

              {/* Mobile: Direct content */}
              <div className="md:hidden py-4 border-b border-border/50">
                <h3 className="text-base font-semibold mb-1">Session Timeout</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Automatically log out after inactivity.
                </p>
                  <Select
                  value={settings.sessionTimeout.toString()}
                  onValueChange={(value) => updateSettings({ sessionTimeout: parseInt(value) })}
                  >
                  <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                    {SESSION_TIMEOUT_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value.toString()}>
                        {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

              {/* Desktop: Card wrapper */}
              <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                <CardHeader className="p-6">
                  <CardTitle className="text-base">Session Timeout</CardTitle>
                  <CardDescription className="text-sm">
                    Automatically log out after inactivity.
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0 px-6 pb-6">
                  <Select
                    value={settings.sessionTimeout.toString()}
                    onValueChange={(value) => updateSettings({ sessionTimeout: parseInt(value) })}
                  >
                    <SelectTrigger className="w-full max-w-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SESSION_TIMEOUT_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value.toString()}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
                </div>

      {/* Pagination Settings */}
      <div className="grid gap-6 md:grid-cols-1">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg md:text-xl">Pagination Settings</CardTitle>
            <CardDescription className="text-sm text-muted-foreground">
              Configure how many items are displayed per page.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0 px-6 pb-6">
            <div className="grid gap-6 md:grid-cols-2">
              {/* Left Column */}
              <div className="flex flex-col gap-6">
                {/* Mobile: Direct content */}
                <div className="md:hidden py-4 border-b border-border/50">
                  <h3 className="text-base font-semibold mb-1">Global Page Size</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Set a global page size for all pages, or use individual page settings.
                  </p>
                  <Select
                    value={settings.globalPageSize?.toString() || "individual"}
                    onValueChange={handleGlobalPageSizeChange}
                  >
                    <SelectTrigger id="global-page-size-mobile" className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="individual">Use Individual Settings</SelectItem>
                      {PAGE_SIZE_OPTIONS.map((size) => (
                        <SelectItem key={size} value={size.toString()}>
                          {size} items
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Desktop: Card wrapper */}
                <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                  <CardHeader className="p-6">
                    <CardTitle className="text-base">Global Page Size</CardTitle>
                    <CardDescription className="text-sm">
                      Set a global page size for all pages, or use individual page settings.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 px-6 pb-6">
                  <Select
                      value={settings.globalPageSize?.toString() || "individual"}
                      onValueChange={handleGlobalPageSizeChange}
                  >
                      <SelectTrigger id="global-page-size" className="w-full max-w-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="individual">Use Individual Settings</SelectItem>
                      {PAGE_SIZE_OPTIONS.map((size) => (
                        <SelectItem key={size} value={size.toString()}>
                          {size} items
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  </CardContent>
                </Card>
                </div>

              {/* Right Column */}
              <div className="flex flex-col gap-6">
                {/* Mobile: Direct content */}
                <div className="md:hidden py-4 border-b border-border/50">
                  <h3 className="text-base font-semibold mb-1">Individual Page Settings</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Configure page size for each section individually. These settings are ignored if a global page size is set.
                  </p>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="shows-management" className="text-sm">Shows Management</Label>
                      <Select value={settings.pagination.showsManagement.toString()} onValueChange={(value) => handleIndividualPageSizeChange("showsManagement", value)} disabled={settings.globalPageSize !== null}>
                        <SelectTrigger id="shows-management"><SelectValue /></SelectTrigger>
                        <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="user-management" className="text-sm">User Management</Label>
                      <Select value={settings.pagination.userManagement.toString()} onValueChange={(value) => handleIndividualPageSizeChange("userManagement", value)} disabled={settings.globalPageSize !== null}>
                        <SelectTrigger id="user-management"><SelectValue /></SelectTrigger>
                        <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                      </Select>
                  </div>
                    <div className="space-y-2">
                      <Label htmlFor="revenue-ledger" className="text-sm">Revenue Ledger</Label>
                      <Select value={settings.pagination.revenueLedger.toString()} onValueChange={(value) => handleIndividualPageSizeChange("revenueLedger", value)} disabled={settings.globalPageSize !== null}>
                        <SelectTrigger id="revenue-ledger"><SelectValue /></SelectTrigger>
                        <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="partner-payments" className="text-sm">Partner Payments</Label>
                      <Select value={settings.pagination.partnerPayments.toString()} onValueChange={(value) => handleIndividualPageSizeChange("partnerPayments", value)} disabled={settings.globalPageSize !== null}>
                        <SelectTrigger id="partner-payments"><SelectValue /></SelectTrigger>
                        <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="archived-shows" className="text-sm">Archived Shows</Label>
                      <Select value={settings.pagination.archivedShows.toString()} onValueChange={(value) => handleIndividualPageSizeChange("archivedShows", value)} disabled={settings.globalPageSize !== null}>
                        <SelectTrigger id="archived-shows"><SelectValue /></SelectTrigger>
                        <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="feedbacks" className="text-sm">Feedbacks</Label>
                      <Select value={settings.pagination.feedbacks.toString()} onValueChange={(value) => handleIndividualPageSizeChange("feedbacks", value)} disabled={settings.globalPageSize !== null}>
                        <SelectTrigger id="feedbacks"><SelectValue /></SelectTrigger>
                        <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="change-requests" className="text-sm">Change Requests</Label>
                      <Select value={settings.pagination.changeRequests.toString()} onValueChange={(value) => handleIndividualPageSizeChange("changeRequests", value)} disabled={settings.globalPageSize !== null}>
                        <SelectTrigger id="change-requests"><SelectValue /></SelectTrigger>
                        <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="split-history" className="text-sm">Split History</Label>
                      <Select value={settings.pagination.splitHistory.toString()} onValueChange={(value) => handleIndividualPageSizeChange("splitHistory", value)} disabled={settings.globalPageSize !== null}>
                        <SelectTrigger id="split-history"><SelectValue /></SelectTrigger>
                        <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Desktop: Card wrapper */}
                <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
                  <CardHeader className="p-6">
                    <CardTitle className="text-base">Individual Page Settings</CardTitle>
                    <CardDescription className="text-sm">
                      Configure page size for each section individually. These settings are ignored if a global page size is set.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 px-6 pb-6">
                    <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                        <Label htmlFor="shows-management-desktop" className="text-sm">Shows Management</Label>
                        <Select value={settings.pagination.showsManagement.toString()} onValueChange={(value) => handleIndividualPageSizeChange("showsManagement", value)} disabled={settings.globalPageSize !== null}>
                          <SelectTrigger id="shows-management-desktop"><SelectValue /></SelectTrigger>
                          <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                        <Label htmlFor="user-management-desktop" className="text-sm">User Management</Label>
                        <Select value={settings.pagination.userManagement.toString()} onValueChange={(value) => handleIndividualPageSizeChange("userManagement", value)} disabled={settings.globalPageSize !== null}>
                          <SelectTrigger id="user-management-desktop"><SelectValue /></SelectTrigger>
                          <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                        <Label htmlFor="revenue-ledger-desktop" className="text-sm">Revenue Ledger</Label>
                        <Select value={settings.pagination.revenueLedger.toString()} onValueChange={(value) => handleIndividualPageSizeChange("revenueLedger", value)} disabled={settings.globalPageSize !== null}>
                          <SelectTrigger id="revenue-ledger-desktop"><SelectValue /></SelectTrigger>
                          <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                        <Label htmlFor="partner-payments-desktop" className="text-sm">Partner Payments</Label>
                        <Select value={settings.pagination.partnerPayments.toString()} onValueChange={(value) => handleIndividualPageSizeChange("partnerPayments", value)} disabled={settings.globalPageSize !== null}>
                          <SelectTrigger id="partner-payments-desktop"><SelectValue /></SelectTrigger>
                          <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                        <Label htmlFor="archived-shows-desktop" className="text-sm">Archived Shows</Label>
                        <Select value={settings.pagination.archivedShows.toString()} onValueChange={(value) => handleIndividualPageSizeChange("archivedShows", value)} disabled={settings.globalPageSize !== null}>
                          <SelectTrigger id="archived-shows-desktop"><SelectValue /></SelectTrigger>
                          <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                        <Label htmlFor="feedbacks-desktop" className="text-sm">Feedbacks</Label>
                        <Select value={settings.pagination.feedbacks.toString()} onValueChange={(value) => handleIndividualPageSizeChange("feedbacks", value)} disabled={settings.globalPageSize !== null}>
                          <SelectTrigger id="feedbacks-desktop"><SelectValue /></SelectTrigger>
                          <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                        <Label htmlFor="change-requests-desktop" className="text-sm">Change Requests</Label>
                        <Select value={settings.pagination.changeRequests.toString()} onValueChange={(value) => handleIndividualPageSizeChange("changeRequests", value)} disabled={settings.globalPageSize !== null}>
                          <SelectTrigger id="change-requests-desktop"><SelectValue /></SelectTrigger>
                          <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                        <Label htmlFor="split-history-desktop" className="text-sm">Split History</Label>
                        <Select value={settings.pagination.splitHistory.toString()} onValueChange={(value) => handleIndividualPageSizeChange("splitHistory", value)} disabled={settings.globalPageSize !== null}>
                          <SelectTrigger id="split-history-desktop"><SelectValue /></SelectTrigger>
                          <SelectContent>{PAGE_SIZE_OPTIONS.map((size) => (<SelectItem key={size} value={size.toString()}>{size} items</SelectItem>))}</SelectContent>
                  </Select>
                </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notifications & Alerts and Accessibility - Combined in 2 columns */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Notifications & Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg md:text-xl">Notifications & Alerts</CardTitle>
            <CardDescription className="text-sm text-muted-foreground">
              Configure notification behavior.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0 px-6 pb-6">
            {/* Mobile: Direct content */}
            <div className="md:hidden py-4 border-b border-border/50">
              <h3 className="text-base font-semibold mb-1">Toast Notification Duration</h3>
              <p className="text-sm text-muted-foreground mb-4">
                How long toast notifications should be displayed before automatically dismissing.
              </p>
              <Select
                value={settings.toastDuration.toString()}
                onValueChange={(value) => updateSettings({ toastDuration: parseInt(value) })}
              >
                <SelectTrigger id="toast-duration-mobile" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TOAST_DURATION_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value.toString()}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Desktop: Card wrapper */}
            <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
              <CardHeader className="p-6">
                <CardTitle className="text-base">Toast Notification Duration</CardTitle>
                <CardDescription className="text-sm">
                  How long toast notifications should be displayed before automatically dismissing.
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0 px-6 pb-6">
                <Select
                  value={settings.toastDuration.toString()}
                  onValueChange={(value) => updateSettings({ toastDuration: parseInt(value) })}
                >
                  <SelectTrigger id="toast-duration" className="w-full max-w-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TOAST_DURATION_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value.toString()}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>
          </CardContent>
        </Card>

        {/* Accessibility */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg md:text-xl">Accessibility</CardTitle>
            <CardDescription className="text-sm text-muted-foreground">
              Improve accessibility and usability.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0 px-6 pb-6">
            {/* Mobile: Direct content */}
            <div className="md:hidden py-4 border-b border-border/50">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <h3 className="text-base font-semibold mb-1">High Contrast Mode</h3>
                  <p className="text-sm text-muted-foreground">
                    Increase contrast for better visibility and readability.
                  </p>
                </div>
                <div className="flex-shrink-0 pt-1">
                  <Switch
                    id="high-contrast"
                    checked={settings.highContrastMode}
                    onCheckedChange={(checked) => updateSettings({ highContrastMode: checked })}
                  />
                </div>
              </div>
            </div>

            {/* Desktop: Card wrapper */}
            <Card className="hidden md:block shadow-none border-border/50" style={{ boxShadow: "none" }}>
              <CardHeader className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-base mb-1">High Contrast Mode</CardTitle>
                    <CardDescription className="text-sm">
                      Increase contrast for better visibility and readability.
                    </CardDescription>
                  </div>
                  <div className="flex-shrink-0 pt-1">
                    <Switch
                      id="high-contrast-desktop"
                      checked={settings.highContrastMode}
                      onCheckedChange={(checked) => updateSettings({ highContrastMode: checked })}
                    />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </CardContent>
        </Card>
      </div>

      {/* Developer Options - Only for Admin and Internal users - Only show when enabled */}
      {canAccessDeveloperOptions && settings.developerOptionsEnabled && (
        <div className="grid gap-6 md:grid-cols-1">
          <Card>
          <CardHeader>
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <CardTitle className="text-lg md:text-xl">Developer Options</CardTitle>
                <CardDescription className="text-sm text-muted-foreground">
                  Advanced settings for developers and debugging.
                </CardDescription>
              </div>
              <div className="flex-shrink-0 pt-1">
                <Switch
                  id="developer-options"
                  checked={settings.developerOptionsEnabled}
                  onCheckedChange={handleDeveloperOptionsToggle}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0 px-6 pb-6">
            <div className="grid gap-6 md:grid-cols-2">
                {/* Left Column */}
                <div className="flex flex-col gap-6">
                    {/* Debug Mode */}
                    <Card className="shadow-none border-border/50" style={{ boxShadow: "none" }}>
                      <CardHeader className="p-6">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                            <CardTitle className="text-base mb-1">Debug Mode</CardTitle>
                            <CardDescription className="text-sm">
                          Enable additional console logging and debug information.
                            </CardDescription>
                      </div>
                      <div className="flex-shrink-0 pt-1">
                        <Switch
                          id="debug-mode"
                          checked={settings.debugMode}
                              onCheckedChange={(checked) => {
                                updateSettings({ debugMode: checked })
                                addDeveloperLog(checked ? "success" : "info", checked ? "Debug mode enabled" : "Debug mode disabled")
                              }}
                        />
                      </div>
                    </div>
                      </CardHeader>
                    </Card>

                    {/* Show API Response Times */}
                    <Card className="shadow-none border-border/50" style={{ boxShadow: "none" }}>
                    <CardHeader className="p-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                            <CardTitle className="text-base mb-1">Show API Response Times</CardTitle>
                          <CardDescription className="text-sm">
                              Display API latency in the developer console.
                          </CardDescription>
                        </div>
                        <div className="flex-shrink-0 pt-1">
                          <Switch
                              id="api-response-times"
                              checked={settings.showApiResponseTimes}
                              onCheckedChange={(checked) => updateSettings({ showApiResponseTimes: checked })}
                          />
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                </div>

                {/* Right Column */}
                <div className="flex flex-col gap-6">
                    {/* API Endpoint Override */}
                    <Card className="shadow-none border-border/50" style={{ boxShadow: "none" }}>
                      <CardHeader className="p-6">
                        <CardTitle className="text-base">API Endpoint Override</CardTitle>
                        <CardDescription className="text-sm">
                      Override the default API endpoint. Leave empty to use the default.
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="pt-0 px-6 pb-6 space-y-3">
                      <Input
                          id="api-endpoint"
                        type="text"
                        placeholder="https://api.example.com"
                        value={settings.apiEndpointOverride || ""}
                          onChange={(e) => {
                            const value = e.target.value || null
                            updateSettings({ apiEndpointOverride: value })
                            if (value) {
                              addDeveloperLog("warning", "API endpoint override set", value)
                            }
                          }}
                        className="w-full"
                      />
                      {settings.apiEndpointOverride && (
                        <Button
                          variant="outline"
                          size="sm"
                            onClick={() => {
                              updateSettings({ apiEndpointOverride: null })
                              addDeveloperLog("info", "API endpoint override cleared")
                            }}
                        >
                          Clear Override
                        </Button>
                      )}
                      </CardContent>
                    </Card>
                    </div>
                  </div>

                {/* Database Operations - Admin Only */}
                {isAdmin && (
                  <>
                    <Separator className="my-6" />
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <Database className="h-5 w-5" />
                        <h3 className="text-base font-semibold">Database Operations</h3>
                        <Badge variant="outline" className="text-amber-600 border-amber-600">Admin Only</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Export and import SQL dumps of the database. Use with caution.
                      </p>
                      
                      <div className="grid gap-4 md:grid-cols-2">
                        {/* Export Database */}
                        <Card className="shadow-none border-border/50" style={{ boxShadow: "none" }}>
                    <CardHeader className="p-6">
                            <CardTitle className="text-base">Export Database</CardTitle>
                      <CardDescription className="text-sm">
                              Download a complete SQL dump of the current database.
                      </CardDescription>
                    </CardHeader>
                          <CardContent className="pt-0 px-6 pb-6">
                            <Button
                              onClick={handleExportDatabase}
                              disabled={isExporting}
                              className="evergreen-button"
                            >
                              {isExporting ? (
                                <>
                                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                  Exporting...
                                </>
                              ) : (
                                <>
                                  <Download className="mr-2 h-4 w-4" />
                                  Export SQL Dump
                                </>
                              )}
                            </Button>
                          </CardContent>
                        </Card>

                        {/* Import Database */}
                        <Card className="shadow-none border-border/50" style={{ boxShadow: "none" }}>
                          <CardHeader className="p-6">
                            <CardTitle className="text-base">Import Database</CardTitle>
                            <CardDescription className="text-sm">
                              Upload and execute a SQL dump file.
                            </CardDescription>
                          </CardHeader>
                          <CardContent className="pt-0 px-6 pb-6">
                            <input
                              type="file"
                              accept=".sql"
                              ref={fileInputRef}
                              onChange={handleImportDatabase}
                              className="hidden"
                            />
                        <Button
                          variant="outline"
                              onClick={() => fileInputRef.current?.click()}
                              disabled={isImporting}
                            >
                              {isImporting ? (
                                <>
                                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                  Importing...
                                </>
                              ) : (
                                <>
                                  <Upload className="mr-2 h-4 w-4" />
                                  Import SQL File
                                </>
                              )}
                            </Button>
                          </CardContent>
                        </Card>
                      </div>
                </div>
                    <Separator className="my-6" />
                  </>
                )}

                {/* Database Status and Developer Console - 2 Column Layout */}
                <div className="grid grid-cols-1 lg:grid-cols-6 gap-6 mt-6">
                  {/* Developer Console - Left Column (5/6 width) */}
                  <div className={cn("lg:col-span-5", !dbStatus && "lg:col-span-6")}>
                    <DeveloperConsole />
                  </div>

                  {/* Database Status - Right Column (1/6 width) */}
                  {dbStatus && (
                    <div className="lg:col-span-1">
                      <Card className="shadow-none border-border/50" style={{ boxShadow: "none" }}>
                        <CardHeader className="p-6">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-base">Database Status</CardTitle>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={handleRefreshDbStatus}
                              disabled={isLoadingDbStatus}
                            >
                              <RefreshCw className={cn("h-4 w-4", isLoadingDbStatus && "animate-spin")} />
                            </Button>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0 px-6 pb-6">
                          <div className="space-y-4 text-sm">
                            <div className="flex items-center gap-2">
                              <HardDrive className="h-4 w-4 text-muted-foreground" />
                              <div>
                                <div className="font-medium">{dbStatus.total_tables}</div>
                                <div className="text-xs text-muted-foreground">Tables</div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Database className="h-4 w-4 text-muted-foreground" />
                              <div>
                                <div className="font-medium">{dbStatus.total_rows.toLocaleString()}</div>
                                <div className="text-xs text-muted-foreground">Rows</div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <HardDrive className="h-4 w-4 text-muted-foreground" />
                              <div>
                                <div className="font-medium">{dbStatus.total_size_mb} MB</div>
                                <div className="text-xs text-muted-foreground">Size</div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  )}
                </div>
            </CardContent>
        </Card>
        </div>
      )}

      {/* Reset Settings */}
      <div className="grid gap-6 md:grid-cols-1">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg md:text-xl">Reset Settings</CardTitle>
            <CardDescription className="text-sm text-muted-foreground">
              Restore all settings to their default values.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0 px-6 pb-6">
            <Button variant="outline" onClick={() => setShowResetConfirm(true)}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Reset All Settings
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Developer Options Footer Button - Admin Only */}
      {isAdmin && (
        <div className="flex justify-end mt-4">
          <Button variant="outline" onClick={handleDeveloperButtonClick}>
            <Image
              src={isDark ? "/myco-beta-footer-logo-light.png" : "/myco-beta-footer-logo.png"}
              alt="Myco"
              width={80}
              height={40}
              className="object-contain"
            />
          </Button>
        </div>
      )}

      {/* Reset Settings Confirmation Dialog */}
      <AlertDialog open={showResetConfirm} onOpenChange={setShowResetConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-red-600 dark:text-red-400">
              <AlertTriangle className="h-5 w-5 inline-block mr-2" />
              Reset All Settings
            </AlertDialogTitle>
          </AlertDialogHeader>
          <div className="text-sm text-muted-foreground px-6 py-4">
            <p className="mb-4">
              Are you sure you want to reset all settings to their default values? This action cannot be undone.
            </p>
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                This will reset all your preferences including:
                <ul className="mt-2 ml-4 list-disc space-y-1">
                  <li>Appearance settings (theme, colors, effects)</li>
                  <li>Pagination settings</li>
                  <li>Notification preferences</li>
                  <li>Accessibility settings</li>
                  <li>Developer options</li>
                </ul>
              </AlertDescription>
            </Alert>
          </div>
          <AlertDialogFooter>
            <AlertDialogAction
              onClick={handleReset}
              className="evergreen-button-red"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Confirm Reset
            </AlertDialogAction>
            <AlertDialogCancel onClick={() => setShowResetConfirm(false)}>
              Cancel
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Developer Options Confirmation Dialog */}
      <AlertDialog open={showDeveloperOptionsConfirm} onOpenChange={setShowDeveloperOptionsConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className={settings.developerOptionsEnabled ? "text-amber-600 dark:text-amber-400" : "text-amber-600 dark:text-amber-400"}>
              <AlertTriangle className="h-5 w-5 inline-block mr-2" />
              {settings.developerOptionsEnabled ? "Developer Options Enabled" : "Enable Developer Options"}
            </AlertDialogTitle>
          </AlertDialogHeader>
          <div className="text-sm text-muted-foreground px-6 py-4">
            {settings.developerOptionsEnabled ? (
              <>
                <p className="mb-4">
                  Developer options are currently <strong>enabled</strong>. You have access to advanced developer features.
                </p>
                <div className="relative w-full rounded-2xl border border-amber-500/30 dark:border-amber-400/20 p-4 bg-amber-50/50 dark:bg-amber-950/20">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                    <div className="flex-1 text-sm text-foreground">
                      <p className="font-medium text-amber-900 dark:text-amber-100 mb-2">
                        You currently have access to:
                      </p>
                      <ul className="mt-2 ml-4 list-disc space-y-1 text-amber-800 dark:text-amber-200">
                        <li>Debug mode with additional console logging</li>
                        <li>API endpoint override capabilities</li>
                        <li>API response time monitoring</li>
                        <li>Database export/import (Admin only)</li>
                        <li>Developer console with logs</li>
                      </ul>
                      <p className="mt-3 font-medium text-amber-900 dark:text-amber-100">
                        Disabling developer options will reset all developer settings to their defaults.
                      </p>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                <p className="mb-4">
                  Are you sure you want to enable developer options? These settings are intended for advanced users and developers.
                </p>
                <div className="relative w-full rounded-2xl border border-amber-500/30 dark:border-amber-400/20 p-4 bg-amber-50/50 dark:bg-amber-950/20">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                    <div className="flex-1 text-sm text-foreground">
                      <p className="font-medium text-amber-900 dark:text-amber-100 mb-2">
                        Enabling developer options will give you access to:
                      </p>
                      <ul className="mt-2 ml-4 list-disc space-y-1 text-amber-800 dark:text-amber-200">
                        <li>Debug mode with additional console logging</li>
                        <li>API endpoint override capabilities</li>
                        <li>API response time monitoring</li>
                        <li>Database export/import (Admin only)</li>
                        <li>Developer console with logs</li>
                      </ul>
                      <p className="mt-3 font-medium text-amber-900 dark:text-amber-100">
                        <strong>Warning:</strong> These features may affect application stability and should only be used by experienced developers.
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
          <AlertDialogFooter>
            {settings.developerOptionsEnabled ? (
              <>
                <AlertDialogAction
                  onClick={handleDisableDeveloperOptions}
                  className="evergreen-button-red"
                >
                  Disable Developer Options
                </AlertDialogAction>
                <AlertDialogCancel onClick={handleCancelDeveloperOptions}>
                  Cancel
                </AlertDialogCancel>
              </>
            ) : (
              <>
                <AlertDialogAction
                  onClick={handleConfirmDeveloperOptions}
                  className="evergreen-button-amber"
                >
                  Enable Developer Options
                </AlertDialogAction>
                <AlertDialogCancel onClick={handleCancelDeveloperOptions}>
                  Cancel
                </AlertDialogCancel>
              </>
            )}
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Database Import Confirmation Dialog */}
      <AlertDialog open={showImportConfirm} onOpenChange={setShowImportConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-red-600 dark:text-red-400">
              <AlertTriangle className="h-5 w-5 inline-block mr-2" />
              Import Database
            </AlertDialogTitle>
          </AlertDialogHeader>
          <div className="text-sm text-muted-foreground px-6 py-4">
            <p className="mb-4">
              Are you sure you want to import this SQL file? This action will <strong>replace or modify</strong> the current database.
            </p>
            {pendingImportFile && (
              <div className="mb-4">
                <p className="font-medium text-foreground mb-1">File to import:</p>
                <p className="text-sm text-muted-foreground">{pendingImportFile.name}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Size: {(pendingImportFile.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            )}
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Warning:</strong> This operation will:
                <ul className="mt-2 ml-4 list-disc space-y-1">
                  <li>Execute all SQL statements in the file</li>
                  <li>Potentially drop and recreate tables</li>
                  <li>Replace existing data with data from the SQL file</li>
                  <li>May cause data loss if not properly backed up</li>
                </ul>
                <p className="mt-2 font-medium">
                  This action cannot be undone. Make sure you have a backup before proceeding.
                </p>
              </AlertDescription>
            </Alert>

            <div className="mt-4 rounded-lg border border-border/60 bg-muted/20 p-4">
              <p className="font-medium text-foreground mb-3">Import mode</p>
              <div className="space-y-2">
                <label className="flex items-start gap-3 rounded-md border border-border/60 bg-background/60 p-3 hover:bg-background transition-colors">
                  <input
                    type="radio"
                    name="importMode"
                    value="full_replace_fast"
                    checked={importMode === "full_replace_fast"}
                    onChange={() => setImportMode("full_replace_fast")}
                    disabled={isImporting}
                    className="mt-1"
                  />
                  <span className="flex-1">
                    <span className="font-medium text-foreground leading-tight">Full replace (fast)</span>
                    <span className="block text-xs text-muted-foreground mt-1">
                      Drops and recreates the database, then bulk imports. Fastest option.
                    </span>
                  </span>
                </label>

                <label className="flex items-start gap-3 rounded-md border border-border/60 bg-background/60 p-3 hover:bg-background transition-colors">
                  <input
                    type="radio"
                    name="importMode"
                    value="full_replace_safe"
                    checked={importMode === "full_replace_safe"}
                    onChange={() => setImportMode("full_replace_safe")}
                    disabled={isImporting}
                    className="mt-1"
                  />
                  <span className="flex-1">
                    <span className="font-medium text-foreground leading-tight">Full replace (safe)</span>
                    <span className="block text-xs text-muted-foreground mt-1">
                      Creates a server-side backup first (best-effort), then performs a full replace.
                    </span>
                  </span>
                </label>
              </div>
            </div>
          </div>
          <AlertDialogFooter>
            <AlertDialogAction
              onClick={handleConfirmImport}
              className="evergreen-button-red"
              disabled={isImporting}
            >
              {isImporting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Confirm Import
                </>
              )}
            </AlertDialogAction>
            <AlertDialogCancel onClick={handleCancelImport} disabled={isImporting}>
              Cancel
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
