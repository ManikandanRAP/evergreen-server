"use client"

import { useState, useEffect, useRef } from "react"
import { useAuth } from "@/lib/auth-context"
import { useSettings, ThemeMode } from "@/lib/settings-context"
import { Button } from "@/components/ui/button"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetTrigger,
} from "@/components/ui/sheet"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Menu,
  Home,
  Radio,
  Users,
  DollarSign,
  Settings,
  LogOut,
  Sun,
  Moon,
  Monitor,
  ChevronLeft,
  ChevronRight,
  Shield,
  Lightbulb,
  MessageSquare,
  BarChart3,
  Archive,
  Sidebar,
  FileEdit,
  SidebarClose,
  X,
  Building,
  User as UserIcon,
  Pencil,
} from "lucide-react"
import { useTheme } from "next-themes"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { cn } from "@/lib/utils"

interface DashboardNavProps {
  onSidebarToggle?: (collapsed: boolean) => void
}

export default function DashboardNav({ onSidebarToggle }: DashboardNavProps) {
  const { user, logout } = useAuth()
  const { setTheme, theme } = useTheme()
  const { setThemeMode } = useSettings()
  const pathname = usePathname()
  
  // Handler to update both next-themes and our settings (syncs to server)
  const handleThemeChange = (mode: ThemeMode) => {
    setTheme(mode) // Update next-themes immediately for UI
    setThemeMode(mode) // Update our settings (will sync to server)
  }
  const router = useRouter()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isDesktopCollapsed, setIsDesktopCollapsed] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [isUserProfileOpen, setIsUserProfileOpen] = useState(false)
  const [isDark, setIsDark] = useState(() =>
    typeof document !== "undefined" ? document.documentElement.classList.contains("dark") : false
  )
  const [isNavigating, setIsNavigating] = useState(() => {
    // Check sessionStorage on mount to persist navigation state across component unmounts
    if (typeof window !== 'undefined') {
      const navigating = sessionStorage.getItem('mobile-nav-navigating')
      return navigating === 'true'
    }
    return false
  })
  const navigationTimerRef = useRef<NodeJS.Timeout | null>(null)
  
  // Check theme
  useEffect(() => {
    const checkTheme = () => {
      setIsDark(document.documentElement.classList.contains('dark'))
    }
    checkTheme()
    
    const observer = new MutationObserver(checkTheme)
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    })
    
    return () => observer.disconnect()
  }, [])

  // Helper function to format role names for display
  const formatRoleName = (role: string | null) => {
    switch (role) {
      case 'admin': return 'Admin'
      case 'partner': return 'Partner'
      case 'internal_full_access': return 'Internal - Full Access'
      case 'internal_show_access': return 'Internal - Show Access'
      default: return role || '—'
    }
  }

  // Helper function to get first name from full name
  const getFirstName = (fullName: string | null | undefined) => {
    if (!fullName) return 'User'
    return fullName.split(' ')[0]
  }

  // Ensure component is mounted before rendering theme-dependent content
  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    onSidebarToggle?.(isDesktopCollapsed)
  }, [isDesktopCollapsed, onSidebarToggle])

  // Close mobile menu when pathname changes
  useEffect(() => {
    setIsMobileMenuOpen(false)
    
    // If we're navigating, extend the guard period with each pathname change
    // This handles pages with loading states that cause multiple renders
    if (isNavigating) {
      if (navigationTimerRef.current) {
        clearTimeout(navigationTimerRef.current)
      }
      navigationTimerRef.current = setTimeout(() => {
        setIsNavigating(false)
        sessionStorage.removeItem('mobile-nav-navigating')
        navigationTimerRef.current = null
      }, 600) // Extended period to cover loading states
    }
  }, [pathname]) // Only depend on pathname, not isNavigating

  // Cleanup timer and sessionStorage on unmount
  useEffect(() => {
    return () => {
      if (navigationTimerRef.current) {
        clearTimeout(navigationTimerRef.current)
      }
      // Don't clear sessionStorage here - we want it to persist across unmounts
    }
  }, [])

  // Handle navigation from mobile menu
  const handleMobileNav = (href: string) => {
    // First, close the Sheet to trigger its closing animation
    setIsMobileMenuOpen(false)
    
    // Wait for the Sheet animation to complete (~300ms), then unmount and navigate
    setTimeout(() => {
      setIsNavigating(true)
      sessionStorage.setItem('mobile-nav-navigating', 'true')
      router.push(href)
    }, 300)
  }

  // Handle Sheet open/close - prevent opening during navigation
  const handleSheetOpenChange = (open: boolean) => {
    const sessionNavigating = typeof window !== 'undefined' 
      ? sessionStorage.getItem('mobile-nav-navigating') === 'true'
      : false
    
    // Block opening if either state or sessionStorage indicates we're navigating
    if (open && (isNavigating || sessionNavigating)) {
      return
    }
    
    setIsMobileMenuOpen(open)
  }

  let mainNavItems: { href: string; label: string; icon: any; variant?: "default" | "ghost" | "outline" }[] = []

  if (user?.role === "partner") {
    mainNavItems = [{ href: "/revenue-ledger", label: "Revenue Ledger", icon: DollarSign }]
  } else if (user?.role === "internal_show_access") {
    mainNavItems = [{ href: "/shows-management", label: "Shows", icon: Radio }]
  } else {
    mainNavItems = [
      { href: "/", label: "Dashboard", icon: Home },
      { href: "/shows-management", label: "Shows", icon: Radio },
      { href: "/revenue-ledger", label: "Revenue Ledger", icon: DollarSign },
      ...(user?.role === "admin"
        ? [{ href: "/administrator", label: "Administrator", icon: Shield }]
        : []),
    ]
    
  }

  const secondaryNavItems = [
    // Change Requests temporarily hidden - accessible via direct URL /change-requests
    // ...(user?.role === "internal_full_access" || user?.role === "internal_show_access" || user?.role === "admin" || user?.role === "partner" 
    //   ? [{ href: "/change-requests", label: "Change Requests", variant: "outline", icon: FileEdit }] 
    //   : []),
    ...(user?.role === "internal_full_access" || user?.role === "internal_show_access" || user?.role === "admin" 
      ? [{ href: "/add-feature-suggestion", label: "Feature Suggestion", variant: "outline", icon: Lightbulb }] 
      : []),
    ...(user?.role === "admin" 
      ? [{ href: "/feedbacks", label: "Feedbacks", variant: "outline", icon: MessageSquare }] 
      : []),
  ]

  const handleSidebarToggle = () => {
    setIsDesktopCollapsed(!isDesktopCollapsed)
  }

  const ThemeToggle = ({ isMobile = false, isCollapsed = false }: { isMobile?: boolean; isCollapsed?: boolean }) => {
    const getButtonClass = () => {
      if (isMobile) return "w-full justify-start"
      if (isCollapsed) return "w-11 h-11 rounded-full"
      return "h-10 w-10 rounded-full" // Match default button height in expanded mode, circular shape
    }

    if (!mounted) {
      return (
        <Button variant="outline" size="icon" className={getButtonClass()}>
          <Sun className="h-4 w-4" />
          {isMobile && <span className="ml-3">Theme</span>}
        </Button>
      )
    }

    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className={getButtonClass()}
          >
            <Sun className={cn("absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0 z-10", isCollapsed ? "h-5 w-5" : "h-4 w-4")} />
            <Moon className={cn("absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100 z-10", isCollapsed ? "h-5 w-5" : "h-4 w-4")} />
            {isMobile && <span className="ml-3 relative z-10">Theme</span>}
            <span className="sr-only">Toggle theme</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => handleThemeChange("light")} className="cursor-pointer">
            <Sun className="mr-2 h-4 w-4" />
            Light
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleThemeChange("dark")} className="cursor-pointer">
            <Moon className="mr-2 h-4 w-4" />
            Dark
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleThemeChange("system")} className="cursor-pointer">
            <Monitor className="mr-2 h-4 w-4" />
            System
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    )
  }

  const SidebarContent = ({ isMobile = false }: { isMobile?: boolean }) => (
    <div className="flex flex-col h-full">
      <div
        className={cn(
          "p-6 border-b border-border/50 flex items-center",
          isDesktopCollapsed && !isMobile ? "justify-center p-4" : "",
        )}
      >
        {(!isDesktopCollapsed || isMobile) && (
          <Link href="/" className="block">
            <Image src={isDark ? "/myco-beta-logo-light.png" : "/myco-beta-logo.png"} alt="Myco" width={200} height={50} className="h-12 w-auto" priority />
          </Link>
        )}
        {isDesktopCollapsed && !isMobile && (
          <Link href="/" className="block">
            <div className="w-11 h-11 rounded-full flex items-center justify-center hover:opacity-80 transition-opacity overflow-hidden">
              <Image src="/myco-logo-icon.png" alt="Myco" width={44} height={44} className="w-full h-full object-cover" priority />
            </div>
          </Link>
        )}
      </div>

      <nav className={cn("flex-1 flex flex-col p-4", isDesktopCollapsed && !isMobile && "items-center")}>
        <div className={cn("space-y-2", isDesktopCollapsed && !isMobile && "flex flex-col items-center")}>
          {mainNavItems.map((item) => {
            // Use router.push for mobile to prevent Sheet reopening during navigation
            if (isMobile) {
              return (
                <Button
                  key={item.href}
                  variant={pathname === item.href ? "default" : (item.variant ?? "outline")}
                  className={cn(
                    "w-full justify-start",
                    pathname === item.href ? "evergreen-button shadow-lg" : "hover:bg-accent hover:text-accent-foreground",
                  )}
                  onClick={() => handleMobileNav(item.href)}
                  title={item.label}
                >
                  <item.icon className="h-4 w-4 mr-3" />
                  {item.label}
                </Button>
              )
            }
            // Desktop uses Link as before
            return (
              <Link key={item.href} href={item.href} className="block">
                <Button
                  variant={pathname === item.href ? "default" : (item.variant ?? "outline")}
                  size={isDesktopCollapsed ? "icon" : "default"}
                  className={cn(
                    pathname === item.href ? "evergreen-button shadow-lg" : "hover:bg-accent hover:text-accent-foreground",
                    isDesktopCollapsed ? "w-11 h-11 rounded-full" : "w-full justify-start",
                  )}
                  title={isDesktopCollapsed ? item.label : undefined}
                >
                  <item.icon className={cn(isDesktopCollapsed ? "h-5 w-5" : "h-4 w-4", !isDesktopCollapsed && "mr-3")} />
                  {!isDesktopCollapsed && item.label}
                </Button>
              </Link>
            )
          })}
        </div>
        <div className={cn("mt-auto space-y-2", isDesktopCollapsed && !isMobile && "flex flex-col items-center")}>
          {secondaryNavItems.map((item) => {
            // Use router.push for mobile to prevent Sheet reopening during navigation
            if (isMobile) {
              return (
                <Button
                  key={item.href}
                  variant={pathname === item.href ? "default" : "outline"}
                  className={cn(
                    "w-full justify-start",
                    pathname === item.href ? "evergreen-button shadow-lg" : "hover:bg-accent hover:text-accent-foreground",
                  )}
                  onClick={() => handleMobileNav(item.href)}
                  title={item.label}
                >
                  <item.icon className="h-4 w-4 mr-3" />
                  {item.label}
                </Button>
              )
            }
            // Desktop uses Link as before
            return (
              <Link key={item.href} href={item.href} className="block">
                <Button
                  variant={pathname === item.href ? "default" : "outline"}
                  size={isDesktopCollapsed ? "icon" : "default"}
                  className={cn(
                    pathname === item.href ? "evergreen-button shadow-lg" : "hover:bg-accent hover:text-accent-foreground",
                    isDesktopCollapsed ? "w-11 h-11 rounded-full" : "w-full justify-start",
                  )}
                  title={isDesktopCollapsed ? item.label : undefined}
                >
                  <item.icon className={cn(isDesktopCollapsed ? "h-5 w-5" : "h-4 w-4", !isDesktopCollapsed && "mr-3")} />
                  {!isDesktopCollapsed && item.label}
                </Button>
              </Link>
            )
          })}
        </div>
      </nav>

      <div className={cn("p-4 border-t border-border/50 space-y-2", isDesktopCollapsed && !isMobile && "flex flex-col items-center")}>
        {(!isDesktopCollapsed || isMobile) && (
          <>
            <Button
              variant="ghost"
              className="w-full text-left justify-start transition-all duration-200 h-auto py-1.5 items-center"
              style={{
                backgroundColor: isDark 
                  ? (user?.role === 'admin' 
                      ? "rgba(16, 185, 129, 0.3)"
                      : user?.role === 'internal_full_access'
                      ? "rgba(249, 115, 22, 0.3)"
                      : user?.role === 'internal_show_access'
                      ? "rgba(59, 130, 246, 0.3)"
                      : user?.role === 'partner'
                      ? "rgba(168, 85, 247, 0.3)"
                      : "rgba(148, 163, 184, 0.3)")
                  : (user?.role === 'admin' 
                      ? "rgba(16, 185, 129, 0.15)"
                      : user?.role === 'internal_full_access'
                      ? "rgba(249, 115, 22, 0.15)"
                      : user?.role === 'internal_show_access'
                      ? "rgba(59, 130, 246, 0.15)"
                      : user?.role === 'partner'
                      ? "rgba(168, 85, 247, 0.15)"
                      : "rgba(148, 163, 184, 0.15)")
              }}
              onMouseEnter={(e) => {
                if (isDark) {
                  e.currentTarget.style.backgroundColor = user?.role === 'admin' 
                    ? "rgba(16, 185, 129, 0.4)"
                    : user?.role === 'internal_full_access'
                    ? "rgba(249, 115, 22, 0.4)"
                    : user?.role === 'internal_show_access'
                    ? "rgba(59, 130, 246, 0.4)"
                    : user?.role === 'partner'
                    ? "rgba(168, 85, 247, 0.4)"
                    : "rgba(148, 163, 184, 0.4)"
                } else {
                  e.currentTarget.style.backgroundColor = user?.role === 'admin' 
                    ? "rgba(16, 185, 129, 0.2)"
                    : user?.role === 'internal_full_access'
                    ? "rgba(249, 115, 22, 0.2)"
                    : user?.role === 'internal_show_access'
                    ? "rgba(59, 130, 246, 0.2)"
                    : user?.role === 'partner'
                    ? "rgba(168, 85, 247, 0.2)"
                    : "rgba(148, 163, 184, 0.2)"
                }
              }}
              onMouseLeave={(e) => {
                if (isDark) {
                  e.currentTarget.style.backgroundColor = user?.role === 'admin' 
                    ? "rgba(16, 185, 129, 0.3)"
                    : user?.role === 'internal_full_access'
                    ? "rgba(249, 115, 22, 0.3)"
                    : user?.role === 'internal_show_access'
                    ? "rgba(59, 130, 246, 0.3)"
                    : user?.role === 'partner'
                    ? "rgba(168, 85, 247, 0.3)"
                    : "rgba(148, 163, 184, 0.3)"
                } else {
                  e.currentTarget.style.backgroundColor = user?.role === 'admin' 
                    ? "rgba(16, 185, 129, 0.15)"
                    : user?.role === 'internal_full_access'
                    ? "rgba(249, 115, 22, 0.15)"
                    : user?.role === 'internal_show_access'
                    ? "rgba(59, 130, 246, 0.15)"
                    : user?.role === 'partner'
                    ? "rgba(168, 85, 247, 0.15)"
                    : "rgba(148, 163, 184, 0.15)"
                }
              }}
              onClick={() => setIsUserProfileOpen(true)}
            >
              <UserIcon className="h-4 w-4 mr-3 flex-shrink-0" />
              <div className="text-sm min-w-0 flex-1 text-left">
                <p className="font-semibold text-foreground truncate">{getFirstName(user?.name)}</p>
                <p className="text-xs text-muted-foreground truncate">{formatRoleName(user?.role ?? null)}</p>
              </div>
            </Button>
            <div className="flex items-center gap-2">
              {isMobile ? (
                <Button
                  variant={pathname === "/settings" ? "default" : "outline"}
                  className={cn(
                    "flex-1 justify-start",
                    pathname === "/settings" ? "evergreen-button shadow-lg" : "hover:bg-accent hover:text-accent-foreground",
                  )}
                  onClick={() => handleMobileNav("/settings")}
                  title="Settings"
                >
                  <Settings className="h-4 w-4 mr-3" />
                  Settings
                </Button>
              ) : (
                <Link href="/settings" className="flex-1">
                  <Button
                    variant={pathname === "/settings" ? "default" : "outline"}
                    className={cn(
                      "w-full justify-start",
                      pathname === "/settings" ? "evergreen-button shadow-lg" : "hover:bg-accent hover:text-accent-foreground",
                    )}
                  >
                    <Settings className="h-4 w-4 mr-3" />
                    Settings
                  </Button>
                </Link>
              )}
              <ThemeToggle />
            </div>
          </>
        )}

        {isDesktopCollapsed && !isMobile && (
          <div className="flex flex-col items-center space-y-2">
            <Button
              variant="ghost"
              size="icon"
              className="w-11 h-11 rounded-full flex items-center justify-center transition-colors p-0 border"
              style={{
                backgroundColor: isDark 
                  ? (user?.role === 'admin' 
                      ? "rgba(16, 185, 129, 0.3)"
                      : user?.role === 'internal_full_access'
                      ? "rgba(249, 115, 22, 0.3)"
                      : user?.role === 'internal_show_access'
                      ? "rgba(59, 130, 246, 0.3)"
                      : user?.role === 'partner'
                      ? "rgba(168, 85, 247, 0.3)"
                      : "rgba(148, 163, 184, 0.3)")
                  : (user?.role === 'admin' 
                      ? "rgba(16, 185, 129, 0.15)"
                      : user?.role === 'internal_full_access'
                      ? "rgba(249, 115, 22, 0.15)"
                      : user?.role === 'internal_show_access'
                      ? "rgba(59, 130, 246, 0.15)"
                      : user?.role === 'partner'
                      ? "rgba(168, 85, 247, 0.15)"
                      : "rgba(148, 163, 184, 0.15)"),
                borderColor: isDark
                  ? (user?.role === 'admin' 
                      ? "rgba(16, 185, 129, 0.5)"
                      : user?.role === 'internal_full_access'
                      ? "rgba(249, 115, 22, 0.5)"
                      : user?.role === 'internal_show_access'
                      ? "rgba(59, 130, 246, 0.5)"
                      : user?.role === 'partner'
                      ? "rgba(168, 85, 247, 0.5)"
                      : "rgba(148, 163, 184, 0.5)")
                  : (user?.role === 'admin' 
                      ? "rgba(16, 185, 129, 0.3)"
                      : user?.role === 'internal_full_access'
                      ? "rgba(249, 115, 22, 0.3)"
                      : user?.role === 'internal_show_access'
                      ? "rgba(59, 130, 246, 0.3)"
                      : user?.role === 'partner'
                      ? "rgba(168, 85, 247, 0.3)"
                      : "rgba(148, 163, 184, 0.3)")
              }}
              onMouseEnter={(e) => {
                if (isDark) {
                  e.currentTarget.style.backgroundColor = user?.role === 'admin' 
                    ? "rgba(16, 185, 129, 0.4)"
                    : user?.role === 'internal_full_access'
                    ? "rgba(249, 115, 22, 0.4)"
                    : user?.role === 'internal_show_access'
                    ? "rgba(59, 130, 246, 0.4)"
                    : user?.role === 'partner'
                    ? "rgba(168, 85, 247, 0.4)"
                    : "rgba(148, 163, 184, 0.4)"
                } else {
                  e.currentTarget.style.backgroundColor = user?.role === 'admin' 
                    ? "rgba(16, 185, 129, 0.25)"
                    : user?.role === 'internal_full_access'
                    ? "rgba(249, 115, 22, 0.25)"
                    : user?.role === 'internal_show_access'
                    ? "rgba(59, 130, 246, 0.25)"
                    : user?.role === 'partner'
                    ? "rgba(168, 85, 247, 0.25)"
                    : "rgba(148, 163, 184, 0.25)"
                }
              }}
              onMouseLeave={(e) => {
                if (isDark) {
                  e.currentTarget.style.backgroundColor = user?.role === 'admin' 
                    ? "rgba(16, 185, 129, 0.3)"
                    : user?.role === 'internal_full_access'
                    ? "rgba(249, 115, 22, 0.3)"
                    : user?.role === 'internal_show_access'
                    ? "rgba(59, 130, 246, 0.3)"
                    : user?.role === 'partner'
                    ? "rgba(168, 85, 247, 0.3)"
                    : "rgba(148, 163, 184, 0.3)"
                } else {
                  e.currentTarget.style.backgroundColor = user?.role === 'admin' 
                    ? "rgba(16, 185, 129, 0.15)"
                    : user?.role === 'internal_full_access'
                    ? "rgba(249, 115, 22, 0.15)"
                    : user?.role === 'internal_show_access'
                    ? "rgba(59, 130, 246, 0.15)"
                    : user?.role === 'partner'
                    ? "rgba(168, 85, 247, 0.15)"
                    : "rgba(148, 163, 184, 0.15)"
                }
              }}
              onClick={() => setIsUserProfileOpen(true)}
              title={`${getFirstName(user?.name)} - ${formatRoleName(user?.role ?? null)}`}
            >
              <span className="text-foreground font-semibold text-base">
                {user?.name ? user.name.charAt(0).toUpperCase() : 'U'}
              </span>
            </Button>
            <Link href="/settings" className="block">
              <Button
                variant={pathname === "/settings" ? "default" : "outline"}
                size="icon"
                className={cn(
                  "w-11 h-11 rounded-full",
                  pathname === "/settings" ? "evergreen-button shadow-lg" : "hover:bg-accent hover:text-accent-foreground",
                )}
                title="Settings"
              >
                <Settings className="h-5 w-5" />
              </Button>
            </Link>
            <ThemeToggle isCollapsed={true} />
          </div>
        )}

        <Button
          variant="outline"
          size={isDesktopCollapsed && !isMobile ? "icon" : "default"}
          className={cn(
            "text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 hover:bg-red-50 dark:hover:bg-red-900/20 border-red-200 hover:border-red-300 dark:border-red-800 dark:hover:border-red-700",
            isDesktopCollapsed && !isMobile ? "w-11 h-11 rounded-full" : "w-full justify-start",
          )}
          onClick={logout}
          title={isDesktopCollapsed && !isMobile ? "Sign Out" : undefined}
        >
          <LogOut className={cn(isDesktopCollapsed && !isMobile ? "h-5 w-5" : "h-4 w-4", (!isDesktopCollapsed || isMobile) && "mr-3")} />
          {(!isDesktopCollapsed || isMobile) && "Sign Out"}
        </Button>
      </div>
    </div>
  )

  return (
    <>
      {/* Desktop Sidebar */}
      <div
        className={cn(
          "hidden lg:flex lg:flex-col lg:fixed lg:inset-y-0 lg:z-50 lg:bg-card lg:border-r lg:border-border/50 transition-all duration-300 ease-in-out",
          isDesktopCollapsed ? "lg:w-20" : "lg:w-64",
        )}
      >
        <SidebarContent />

        {/* Collapse Toggle Button */}
        <Button
          variant="outline"
          size="icon"
          className="absolute -right-3 top-1/2 -translate-y-1/2 h-6 w-6 rounded-full border border-border bg-background hover:bg-background shadow-sm z-10 sidebar-toggle-button"
          style={{ 
            backgroundColor: 'hsl(var(--background))',
            backdropFilter: 'none',
            WebkitBackdropFilter: 'none'
          }}
          onClick={handleSidebarToggle}
        >
          {isDesktopCollapsed ? <ChevronRight className="h-3 w-3" /> : <ChevronLeft className="h-3 w-3" />}
        </Button>
      </div>

      {/* Mobile Header */}
      <div className="lg:hidden flex items-center justify-between p-4 bg-card border-b border-border/50 sticky top-0 z-40">
        <Link href="/" className="block">
          <Image src={isDark ? "/myco-beta-logo-light.png" : "/myco-beta-logo.png"} alt="Myco" width={180} height={50} className="h-10 w-auto" priority />
        </Link>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          {!isNavigating && (
            <Sheet 
              open={isMobileMenuOpen} 
              onOpenChange={handleSheetOpenChange}
            >
              <SheetTrigger asChild>
                <Button 
                  variant="outline" 
                  size="icon"
                >
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent 
                side="right" 
                className="p-0 w-64 border-l border-white/15 dark:border-white/5"
                style={{
                  backgroundColor: isDark 
                    ? "rgb(20, 20, 20)" 
                    : "rgb(255, 255, 255)",
                  // Ensure solid background - no backdrop filter or blur
                  WebkitBackdropFilter: "none",
                  backdropFilter: "none",
                }}
              >
                <SheetHeader className="sr-only">
                  <SheetTitle>Navigation Menu</SheetTitle>
                  <SheetDescription>
                    Select a page to navigate to from the list of options.
                  </SheetDescription>
                </SheetHeader>
                <SidebarContent isMobile={true} />
              </SheetContent>
            </Sheet>
          )}
          {isNavigating && (
            <Button 
              variant="outline" 
              size="icon"
              disabled
            >
              <Menu className="h-6 w-6" />
            </Button>
          )}
        </div>
      </div>

      {/* User Profile Dialog */}
      <Dialog open={isUserProfileOpen} onOpenChange={setIsUserProfileOpen}>
        <DialogContent 
          className="max-w-none w-full sm:w-[600px] h-screen sm:max-h-[80vh] mobile-fullscreen flex flex-col p-0 overflow-hidden border-0 sm:overflow-y-auto"
          style={{
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            maxHeight: '80vh',
            backgroundColor: isDark 
              ? "rgb(20, 20, 20)" 
              : "rgb(255, 255, 255)",
          }}
        >
          <DialogHeader className="flex flex-row items-center justify-between px-6 py-4 pr-20">
            {/* Mobile: Title left */}
            <div className="flex sm:hidden w-full items-center justify-between">
              <DialogTitle className="text-lg font-semibold text-left truncate flex-1 pr-4">
                User Profile
              </DialogTitle>
            </div>

            {/* Desktop: Title */}
            <div className="hidden sm:flex flex-row items-center justify-between w-full">
              <DialogTitle className="text-2xl font-bold">User Profile</DialogTitle>
            </div>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto">
            {user && (
              <div className="space-y-6 p-6">
                {/* User Header with Basic Info */}
                <div className={`p-6 rounded-lg border ${
                  user.role === 'admin' 
                    ? "bg-gradient-to-r from-emerald-50 to-emerald-100 dark:from-emerald-950/20 dark:to-emerald-900/20 border-emerald-200 dark:border-emerald-800"
                    : user.role === 'internal_full_access'
                    ? "bg-gradient-to-r from-orange-50 to-orange-100 dark:from-orange-950/20 dark:to-orange-900/20 border-orange-200 dark:border-orange-800"
                    : user.role === 'internal_show_access'
                    ? "bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-950/20 dark:to-blue-900/20 border-blue-200 dark:border-blue-800"
                    : user.role === 'partner'
                    ? "bg-gradient-to-r from-purple-50 to-purple-100 dark:from-purple-950/20 dark:to-purple-900/20 border-purple-200 dark:border-purple-800"
                    : "bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-950/20 dark:to-slate-900/20 border-slate-200 dark:border-slate-800"
                }`}>
                  <div className="space-y-4">
                    <div>
                      <h2 className="text-2xl font-bold text-foreground">
                        {user.name || "Unnamed User"}
                      </h2>
                      <p className="text-lg text-muted-foreground font-mono">
                        {user.email}
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <Badge 
                          className={`text-xs border pointer-events-none uppercase font-semibold ${
                            user.role === 'admin' 
                              ? "bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/50 dark:text-emerald-300 dark:border-emerald-700"
                              : user.role === 'internal_full_access'
                              ? "bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/50 dark:text-orange-300 dark:border-orange-700"
                              : user.role === 'internal_show_access'
                              ? "bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/50 dark:text-blue-300 dark:border-blue-700"
                              : user.role === 'partner'
                              ? "bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/50 dark:text-purple-300 dark:border-purple-700"
                              : "bg-gray-100 text-gray-800 border-gray-300 dark:bg-gray-900/50 dark:text-gray-300 dark:border-gray-700"
                          }`}
                        >
                          {formatRoleName(user.role)}
                        </Badge>
                      </div>
                      {user.created_at && (
                        <div className="text-sm text-muted-foreground">
                          Member since {new Date(user.created_at).toLocaleDateString()}, {new Date(user.created_at).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' })}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Vendor Information */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Building className="h-5 w-5 text-emerald-600" />
                      Vendor Mapping
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {user.mapped_vendor_qbo_id ? (
                      <div className="space-y-3">
                        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 rounded-lg border border-emerald-200 dark:border-emerald-800">
                          <div className="flex items-center gap-2 mb-2">
                            <Building className="h-4 w-4 text-emerald-600" />
                            <span className="font-semibold text-emerald-900 dark:text-emerald-100">
                              {user.mapped_vendor_name || "Unknown Vendor"}
                            </span>
                          </div>
                          <p className="text-sm text-emerald-700 dark:text-emerald-300 font-mono">
                            QBO ID: {user.mapped_vendor_qbo_id}
                          </p>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <Building className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                        {user.role === 'admin' ? (
                          <>
                            <p className="text-muted-foreground font-medium">Admin users cannot be assigned to vendors</p>
                            <p className="text-sm text-muted-foreground mt-1">
                              Admin users have system-wide access and don't require vendor mapping
                            </p>
                          </>
                        ) : (user.role === 'internal_full_access' || user.role === 'internal_show_access') ? (
                          <>
                            <p className="text-muted-foreground font-medium">Internal users cannot be assigned to vendors</p>
                            <p className="text-sm text-muted-foreground mt-1">
                              Internal users are company employees and don't need vendor mapping
                            </p>
                          </>
                        ) : (
                          <>
                            <p className="text-muted-foreground">No vendor mapping assigned</p>
                            <p className="text-sm text-muted-foreground mt-1">
                              This partner user is not linked to any vendor in QuickBooks
                            </p>
                          </>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </div>

          {/* Sticky Footer - Mobile: 2 lines full width, Desktop: right side */}
          <div className="sticky bottom-0 bg-background border-t border-border p-6">
            {/* Mobile Layout */}
            <div className="sm:hidden space-y-3">
              {user?.role === 'admin' && (
                <Button 
                  onClick={() => {
                    setIsUserProfileOpen(false)
                    router.push('/user-management')
                  }}
                  className="w-full flex items-center gap-2 evergreen-button"
                >
                  <Users className="h-4 w-4" />
                  User Management
                </Button>
              )}
              <Button 
                variant="outline" 
                onClick={() => setIsUserProfileOpen(false)}
                className="w-full bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950/20 dark:to-slate-900/20 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:from-slate-100 hover:to-slate-200 dark:hover:from-slate-900/30 dark:hover:to-slate-800/30"
              >
                Close
              </Button>
            </div>

            {/* Desktop Layout */}
            <div className="hidden sm:flex justify-end gap-3">
              {user?.role === 'admin' && (
                <Button 
                  onClick={() => {
                    setIsUserProfileOpen(false)
                    router.push('/user-management')
                  }}
                  className="flex items-center gap-2 evergreen-button-admin"
                >
                  <Users className="h-4 w-4" />
                  User Management
                </Button>
              )}
              <Button 
                variant="outline" 
                onClick={() => setIsUserProfileOpen(false)}
                className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950/20 dark:to-slate-900/20 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:from-slate-100 hover:to-slate-200 dark:hover:from-slate-900/30 dark:hover:to-slate-800/30"
              >
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}