"use client"

import type React from "react"
import { useState, useMemo, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useAuth } from "@/lib/auth-context"
import { useSettings } from "@/lib/settings-context"
import { useRouter } from "next/navigation"
import {
  Search,
  Plus,
  Eye,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  FileEdit,
  CheckCircle,
  Clock,
  AlertCircle,
  X,
  ChevronLeft,
  ChevronRight,
  ArrowLeft,
  User,
  Calendar,
  DollarSign,
  Clock3,
  MessageSquare,
  Check,
  XCircle,
  AlertTriangle,
  MoreVertical,
  Loader2,
} from "lucide-react"
import type { ChangeRequest, ChangeRequestStatus, ChangeRequestCreate, ChangeRequestUpdate, ChangeRequestCancel } from "@/lib/change-request"
import { toast } from "sonner"

type SortDirection = "asc" | "desc" | "original"

// Mock data for demo
const mockChangeRequests: ChangeRequest[] = [
  {
    id: "1",
    title: "Additional Ad Slots for Q4 Campaign",
    description: "We need to add 2 additional ad slots per episode for our Q4 holiday campaign. This will help us maximize revenue during the peak season.",
    status: "waiting_for_client",
    initiated_by: "user1",
    initiated_by_name: "John Smith",
    initiated_at: "2024-01-15T10:30:00Z",
    estimated_hours: 8.5,
    estimated_cost: 1250.00,
    production_notes: "Will require additional editing time and coordination with ad insertion team.",
    production_manager_id: "pm1",
    production_manager_name: "Sarah Johnson",
    production_filled_at: "2024-01-15T14:20:00Z",
  },
  {
    id: "2", 
    title: "Podcast Artwork Update",
    description: "Update the podcast artwork to reflect our new branding guidelines and ensure consistency across all platforms.",
    status: "approved",
    initiated_by: "user2",
    initiated_by_name: "Mike Wilson",
    initiated_at: "2024-01-10T09:15:00Z",
    estimated_hours: 4.0,
    estimated_cost: 0.00,
    production_notes: "No additional cost - using existing design assets.",
    production_manager_id: "pm1",
    production_manager_name: "Sarah Johnson",
    production_filled_at: "2024-01-10T11:45:00Z",
    client_approved_by: "user2",
    client_approved_by_name: "Mike Wilson",
    client_approved_at: "2024-01-10T16:30:00Z",
    evergreen_approved_by: "pm1",
    evergreen_approved_by_name: "Sarah Johnson",
    evergreen_approved_at: "2024-01-11T08:00:00Z",
  },
  {
    id: "3",
    title: "Extended Episode Length",
    description: "Extend the standard episode length from 30 minutes to 45 minutes to accommodate more content and longer sponsor segments.",
    status: "wip",
    initiated_by: "user3",
    initiated_by_name: "Lisa Chen",
    initiated_at: "2024-01-20T13:45:00Z",
  },
  {
    id: "4",
    title: "New Sponsor Integration",
    description: "Integrate a new sponsor with custom intro/outro segments and mid-roll advertisements.",
    status: "waiting_for_evergreen",
    initiated_by: "user1",
    initiated_by_name: "John Smith",
    initiated_at: "2024-01-18T11:20:00Z",
    estimated_hours: 12.0,
    estimated_cost: 2500.00,
    production_notes: "Requires custom audio production and coordination with sponsor's marketing team.",
    production_manager_id: "pm2",
    production_manager_name: "David Brown",
    production_filled_at: "2024-01-19T09:30:00Z",
    client_approved_by: "user1",
    client_approved_by_name: "John Smith",
    client_approved_at: "2024-01-19T15:45:00Z",
  },
  {
    id: "5",
    title: "Seasonal Theme Music",
    description: "Create seasonal theme music for holiday episodes to enhance listener engagement.",
    status: "cancelled",
    initiated_by: "user4",
    initiated_by_name: "Emma Davis",
    initiated_at: "2024-01-12T14:00:00Z",
    cancelled_by: "user4",
    cancelled_by_name: "Emma Davis",
    cancelled_at: "2024-01-13T10:15:00Z",
    cancellation_reason: "Budget constraints - project postponed to next quarter",
  }
]

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000"

export default function ChangeRequests() {
  const { user, token } = useAuth()
  const { getPageSize, settings, updateSettings } = useSettings()
  const router = useRouter()
  const [changeRequests, setChangeRequests] = useState<ChangeRequest[]>(mockChangeRequests)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [sortField, setSortField] = useState<string | null>(null)
  const [sortDirection, setSortDirection] = useState<SortDirection>("original")
  const [originalOrder, setOriginalOrder] = useState<ChangeRequest[]>(mockChangeRequests)
  const [selectedChangeRequest, setSelectedChangeRequest] = useState<ChangeRequest | null>(null)
  const [currentChangeRequestIndex, setCurrentChangeRequestIndex] = useState<number>(0)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isProductionDialogOpen, setIsProductionDialogOpen] = useState(false)
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false)
  const [isFinalApprovalConfirmOpen, setIsFinalApprovalConfirmOpen] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = useMemo(() => getPageSize("changeRequests") || 10, [getPageSize])
  
  const PAGE_SIZE_OPTIONS = [5, 10, 12, 15, 20, 25, 50, 100]
  
  const handlePageSizeChange = (value: string) => {
    const newPageSize = parseInt(value)
    const updates: any = {
      pagination: {
        ...settings.pagination,
        changeRequests: newPageSize,
      },
    }
    
    if (settings.globalPageSize !== null) {
      updates.globalPageSize = null
    }
    
    updateSettings(updates)
    setCurrentPage(1)
  }
  
  useEffect(() => setCurrentPage(1), [itemsPerPage])

  // Form states
  const [createForm, setCreateForm] = useState<ChangeRequestCreate>({ title: "", description: "" })
  const [productionForm, setProductionForm] = useState<ChangeRequestUpdate>({ estimated_hours: 0, estimated_cost: 0, production_notes: "" })
  const [cancelForm, setCancelForm] = useState<ChangeRequestCancel>({ cancellation_reason: "" })
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Check if user has access
  if (!user || (user.role !== "admin" && user.role !== "internal_full_access" && user.role !== "internal_show_access" && user.role !== "partner")) {
    return (
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Change Requests</h1>
          <p className="text-muted-foreground">Manage change requests and approvals.</p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>This feature is only accessible to authorized users.</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              You don't have permission to access this feature. Please contact your administrator if you believe this is an error.
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  const getStatusBadge = (status: ChangeRequestStatus) => {
    const statusConfig = {
      draft: { 
        label: "Draft", 
        icon: FileEdit,
        className: "text-xs border bg-gray-100 text-gray-800 border-gray-300 dark:bg-gray-900/50 dark:text-gray-300 dark:border-gray-700" 
      },
      wip: { 
        label: "Work in Progress", 
        icon: Clock,
        className: "text-xs border bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/50 dark:text-blue-300 dark:border-blue-700" 
      },
      waiting_for_client: { 
        label: "Waiting for Client", 
        icon: User,
        className: "text-xs border bg-yellow-100 text-yellow-800 border-yellow-300 dark:bg-yellow-900/50 dark:text-yellow-300 dark:border-yellow-700" 
      },
      waiting_for_evergreen: { 
        label: "Waiting for EG", 
        icon: CheckCircle,
        className: "text-xs border bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/50 dark:text-orange-300 dark:border-orange-700" 
      },
      approved: { 
        label: "Approved", 
        icon: Check,
        className: "text-xs border bg-green-100 text-green-800 border-green-300 dark:bg-green-900/50 dark:text-green-300 dark:border-green-700" 
      },
      cancelled: { 
        label: "Cancelled", 
        icon: XCircle,
        className: "text-xs border bg-red-100 text-red-800 border-red-300 dark:bg-red-900/50 dark:text-red-300 dark:border-red-700" 
      },
    }
    
    const config = statusConfig[status]
    const Icon = config.icon
    
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full font-medium ${config.className}`}>
        <Icon className="h-3 w-3" />
        {config.label}
      </span>
    )
  }

  const canUserTakeAction = (cr: ChangeRequest | null) => {
    if (!user || !cr) return null
    
    // Production managers can fill estimates
    if (cr.status === "wip" && (user.role === "admin" || (user as any).permissions?.groups?.includes("production_manager"))) {
      return { action: "production", label: "Fill Cost Estimate" }
    }
    
    // Client can approve their own requests
    if (cr.status === "waiting_for_client" && cr.initiated_by === user.id) {
      return { action: "client_approve", label: "Approve Request" }
    }
    
    // Production managers can give final approval
    if (cr.status === "waiting_for_evergreen" && (user.role === "admin" || (user as any).permissions?.groups?.includes("production_manager"))) {
      return { action: "evergreen_approve", label: "Final Approval" }
    }
    
    // Anyone can cancel non-approved requests
    if (cr.status !== "approved" && cr.status !== "cancelled") {
      return { action: "cancel", label: "Cancel Request" }
    }
    
    return null
  }

  const filteredAndSortedChangeRequests = useMemo(() => {
    let filtered = changeRequests.filter(cr => {
      const matchesSearch = cr.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           cr.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           cr.initiated_by_name?.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesStatus = statusFilter === "all" || cr.status === statusFilter
      return matchesSearch && matchesStatus
    })

    if (sortField && sortDirection !== "original") {
      filtered.sort((a, b) => {
        let aVal = a[sortField as keyof ChangeRequest]
        let bVal = b[sortField as keyof ChangeRequest]
        
        if (sortField === "initiated_at") {
          aVal = new Date(aVal as string).getTime()
          bVal = new Date(bVal as string).getTime()
        }
        
        if (typeof aVal === "string" && typeof bVal === "string") {
          return sortDirection === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal)
        }
        
        if (typeof aVal === "number" && typeof bVal === "number") {
          return sortDirection === "asc" ? aVal - bVal : bVal - aVal
        }
        
        return 0
      })
    }

    return filtered
  }, [changeRequests, searchTerm, statusFilter, sortField, sortDirection])

  const totalPages = Math.ceil(filteredAndSortedChangeRequests.length / itemsPerPage)
  const paginatedChangeRequests = filteredAndSortedChangeRequests.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : sortDirection === "desc" ? "original" : "asc")
      if (sortDirection === "desc") {
        setSortField(null)
      }
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  const getSortIcon = (field: string) => {
    if (sortField !== field) return <ArrowUpDown className="h-4 w-4" />
    if (sortDirection === "asc") return <ArrowUp className="h-4 w-4" />
    if (sortDirection === "desc") return <ArrowDown className="h-4 w-4" />
    return <ArrowUpDown className="h-4 w-4" />
  }

  const handleViewChangeRequest = (cr: ChangeRequest, index: number) => {
    setSelectedChangeRequest(cr)
    setCurrentChangeRequestIndex(index)
    setIsViewDialogOpen(true)
  }

  const handleCreateChangeRequest = async () => {
    setIsSubmitting(true)
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const newCR: ChangeRequest = {
        id: Date.now().toString(),
        title: createForm.title,
        description: createForm.description,
        status: "wip",
        initiated_by: user?.id || "",
        initiated_by_name: user?.name || "Current User",
        initiated_at: new Date().toISOString(),
      }
      
      setChangeRequests(prev => [newCR, ...prev])
      setCreateForm({ title: "", description: "" })
      setIsCreateDialogOpen(false)
      toast.success("Change request created successfully!")
    } catch (error) {
      toast.error("Failed to create change request")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleProductionUpdate = async () => {
    if (!selectedChangeRequest) return
    
    setIsSubmitting(true)
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const updatedCR: ChangeRequest = {
        ...selectedChangeRequest,
        estimated_hours: productionForm.estimated_hours,
        estimated_cost: productionForm.estimated_cost,
        production_notes: productionForm.production_notes,
        production_manager_id: user?.id,
        production_manager_name: user?.name || null,
        production_filled_at: new Date().toISOString(),
        status: "waiting_for_client" as ChangeRequestStatus,
      }
      
      setChangeRequests(prev => prev.map(cr => cr.id === selectedChangeRequest.id ? updatedCR : cr))
      setSelectedChangeRequest(updatedCR)
      setIsProductionDialogOpen(false)
      toast.success("Cost estimate submitted! Client will be notified.")
    } catch (error) {
      toast.error("Failed to update cost estimate")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleClientApprove = async () => {
    if (!selectedChangeRequest) return
    
    setIsSubmitting(true)
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const updatedCR: ChangeRequest = {
        ...selectedChangeRequest,
        client_approved_by: user?.id,
        client_approved_by_name: user?.name || null,
        client_approved_at: new Date().toISOString(),
        status: "waiting_for_evergreen" as ChangeRequestStatus,
      }
      
      setChangeRequests(prev => prev.map(cr => cr.id === selectedChangeRequest.id ? updatedCR : cr))
      setSelectedChangeRequest(updatedCR)
      toast.success("Change request approved! Production managers will be notified.")
    } catch (error) {
      toast.error("Failed to approve change request")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleEvergreenApprove = async () => {
    if (!selectedChangeRequest) return
    
    setIsSubmitting(true)
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const updatedCR: ChangeRequest = {
        ...selectedChangeRequest,
        evergreen_approved_by: user?.id,
        evergreen_approved_by_name: user?.name || null,
        evergreen_approved_at: new Date().toISOString(),
        status: "approved" as ChangeRequestStatus,
      }
      
      setChangeRequests(prev => prev.map(cr => cr.id === selectedChangeRequest.id ? updatedCR : cr))
      setSelectedChangeRequest(updatedCR)
      setIsFinalApprovalConfirmOpen(false)
      toast.success("Change request fully approved!")
    } catch (error) {
      toast.error("Failed to approve change request")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleCancel = async () => {
    if (!selectedChangeRequest) return
    
    setIsSubmitting(true)
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const updatedCR: ChangeRequest = {
        ...selectedChangeRequest,
        cancelled_by: user?.id,
        cancelled_by_name: user?.name || null,
        cancelled_at: new Date().toISOString(),
        cancellation_reason: cancelForm.cancellation_reason,
        status: "cancelled" as ChangeRequestStatus,
      }
      
      setChangeRequests(prev => prev.map(cr => cr.id === selectedChangeRequest.id ? updatedCR : cr))
      setSelectedChangeRequest(updatedCR)
      setCancelForm({ cancellation_reason: "" })
      setIsCancelDialogOpen(false)
      toast.success("Change request cancelled")
    } catch (error) {
      toast.error("Failed to cancel change request")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
        {/* Title and description - buttons align with title only */}
        <div className="flex-1">
          <div className="flex flex-col md:flex-row md:items-start gap-4">
            <Button variant="outline" onClick={() => router.back()} className="gap-2 w-fit hidden md:flex">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
            <div>
              <h1 className="text-xl sm:text-3xl font-bold text-primary tracking-tight">Change Requests</h1>
              {/* Description - right below title */}
              <p className="text-sm text-muted-foreground md:text-base">Manage change requests and approvals for ad slots and inventory.</p>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between md:justify-end gap-2">
          <Button variant="outline" onClick={() => router.back()} className="gap-2 w-fit md:hidden">
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <Button className="evergreen-button" onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            New Request
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="md:px-6 px-4">
          {/* Mobile Layout */}
          <div className="md:hidden space-y-4">
            <div className="flex items-center space-x-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground z-10 pointer-events-none" />
                <Input
                  placeholder="Search change requests..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              {/* Mobile Change Requests Count - styled like split history page */}
              <div className="h-10 px-2 flex flex-col items-center justify-center min-w-[60px] gap-0 border border-border rounded-full bg-background">
                <span className="text-sm font-bold leading-none">{filteredAndSortedChangeRequests.length}</span>
                <span className="text-xs text-muted-foreground leading-none">Requests</span>
              </div>
            </div>
            
            {/* Status Filter for Mobile */}
            <div className="flex items-center space-x-4 w-full">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="wip">Work in Progress</SelectItem>
                  <SelectItem value="waiting_for_client">Waiting for Client</SelectItem>
                  <SelectItem value="waiting_for_evergreen">Waiting for Evergreen</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Desktop Layout */}
          <div className="hidden md:flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground z-10 pointer-events-none" />
                <Input
                  placeholder="Search change requests..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              
              {/* Status Filter for Desktop */}
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="wip">Work in Progress</SelectItem>
                  <SelectItem value="waiting_for_client">Waiting for Client</SelectItem>
                  <SelectItem value="waiting_for_evergreen">Waiting for Evergreen</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
              
              {/* Change Requests Count for Desktop */}
              <div>
                <Badge variant="outline" className="text-xs font-normal">
                  {filteredAndSortedChangeRequests.length} request{filteredAndSortedChangeRequests.length !== 1 ? "s" : ""}
                </Badge>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="md:px-6 px-4">
            <div className="rounded-md border overflow-hidden">
              <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="px-4 py-2 font-semibold border-r bg-muted/50 cursor-pointer hover:bg-muted/50 select-none" onClick={() => handleSort("title")}>
                    <div className="flex items-center space-x-1">
                      <span>Title</span>
                      {getSortIcon("title")}
                    </div>
                  </TableHead>
                  <TableHead className="px-4 py-2 font-semibold border-r bg-muted/50 cursor-pointer hover:bg-muted/50 select-none" onClick={() => handleSort("status")}>
                    <div className="flex items-center space-x-1">
                      <span>Status</span>
                      {getSortIcon("status")}
                    </div>
                  </TableHead>
                  <TableHead className="px-4 py-2 font-semibold border-r bg-muted/50 cursor-pointer hover:bg-muted/50 select-none whitespace-nowrap" onClick={() => handleSort("initiated_by_name")}>
                    <div className="flex items-center space-x-1">
                      <span>Initiated By</span>
                      {getSortIcon("initiated_by_name")}
                    </div>
                  </TableHead>
                  <TableHead className="px-4 py-2 font-semibold border-r bg-muted/50">Cost Estimate</TableHead>
                  <TableHead className="px-4 py-2 font-semibold border-r bg-muted/50 cursor-pointer hover:bg-muted/50 select-none whitespace-nowrap" onClick={() => handleSort("initiated_at")}>
                    <div className="flex items-center space-x-1">
                      <span>Created At</span>
                      {getSortIcon("initiated_at")}
                    </div>
                  </TableHead>
                  <TableHead className="px-4 py-2 font-semibold bg-muted/50">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedChangeRequests.map((cr, index) => {
                  const userAction = canUserTakeAction(cr)
                  return (
                    <TableRow key={cr.id}>
                      <TableCell 
                        className="font-medium border-r px-4 py-2 cursor-pointer hover:bg-accent/30 transition-colors whitespace-nowrap"
                        onClick={() => handleViewChangeRequest(cr, index)}
                      >
                        <span className="hover:underline hover:text-emerald-600 transition-colors">
                          {cr.title}
                        </span>
                      </TableCell>
                      <TableCell className="border-r px-4 py-2 whitespace-nowrap">
                        {getStatusBadge(cr.status)}
                      </TableCell>
                      <TableCell className="border-r px-4 py-2 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span>{cr.initiated_by_name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="border-r px-4 py-2 whitespace-nowrap">
                        {cr.estimated_cost !== undefined ? (
                          <div className="flex items-center gap-1">
                            <DollarSign className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">${cr.estimated_cost.toFixed(2)}</span>
                            {cr.estimated_hours && (
                              <span className="text-sm text-muted-foreground">
                                ({cr.estimated_hours}h)
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-muted-foreground">Pending</span>
                        )}
                      </TableCell>
                      <TableCell className="border-r px-4 py-2 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">
                            {new Date(cr.initiated_at).toLocaleDateString()}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="px-4 py-2">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleViewChangeRequest(cr, index)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {userAction && (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="outline" size="sm">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={() => {
                                    if (userAction.action === "production") {
                                      setSelectedChangeRequest(cr)
                                      setProductionForm({
                                        estimated_hours: cr.estimated_hours || 0,
                                        estimated_cost: cr.estimated_cost || 0,
                                        production_notes: cr.production_notes || ""
                                      })
                                      setIsProductionDialogOpen(true)
                                    } else if (userAction.action === "client_approve") {
                                      setSelectedChangeRequest(cr)
                                      handleClientApprove()
                                    } else if (userAction.action === "evergreen_approve") {
                                      setSelectedChangeRequest(cr)
                                      setIsFinalApprovalConfirmOpen(true)
                                    } else if (userAction.action === "cancel") {
                                      setSelectedChangeRequest(cr)
                                      setIsCancelDialogOpen(true)
                                    }
                                  }}
                                  className={userAction.action === "cancel" ? "text-red-600 focus:text-red-600" : ""}
                                >
                                  {userAction.action === "production" && <Clock className="h-4 w-4 mr-2" />}
                                  {userAction.action === "client_approve" && <CheckCircle className="h-4 w-4 mr-2" />}
                                  {userAction.action === "evergreen_approve" && <Check className="h-4 w-4 mr-2" />}
                                  {userAction.action === "cancel" && <XCircle className="h-4 w-4 mr-2" />}
                                  {userAction.label}
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
            </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <Label htmlFor="change-requests-page-size" className="text-xs text-muted-foreground whitespace-nowrap">
                    Items per page:
                  </Label>
                  <Select
                    value={itemsPerPage.toString()}
                    onValueChange={handlePageSizeChange}
                  >
                    <SelectTrigger id="change-requests-page-size" className="w-20 h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PAGE_SIZE_OPTIONS.map((size) => (
                        <SelectItem key={size} value={size.toString()}>
                          {size}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="text-sm text-muted-foreground">
                  Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, filteredAndSortedChangeRequests.length)} of {filteredAndSortedChangeRequests.length} results
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                  Previous
                </Button>
                <div className="flex items-center gap-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(page)}
                      className="w-8 h-8 p-0"
                    >
                      {page}
                    </Button>
                  ))}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                >
                  Next
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Change Request Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-none w-full sm:max-w-[700px] md:max-w-[800px] h-screen sm:h-auto mobile-fullscreen flex flex-col p-0 sm:p-0 overflow-hidden border-0 [&>button:not(.navigation-button)]:hidden">
          {/* Mobile Header - full width with title left, close right */}
          <DialogHeader className="flex sm:hidden flex-row items-center justify-between px-6 py-4">
            <div className="flex w-full items-center justify-between gap-3">
              <DialogTitle className="text-lg font-semibold text-left truncate flex-1">
                Create New Change Request
              </DialogTitle>
              <DialogClose asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 !gap-0 relative">
                  <X className="h-4 w-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                  <span className="sr-only">Close</span>
                </Button>
              </DialogClose>
            </div>
          </DialogHeader>

          {/* Desktop Header - title and close button */}
          <DialogHeader className="hidden sm:flex flex-row items-center justify-between px-6 py-4">
            <DialogTitle>Create New Change Request</DialogTitle>
            <DialogClose asChild>
              <Button variant="outline" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 flex items-center justify-center !gap-0">
                <X className="h-4 w-4 m-0" />
                <span className="sr-only">Close</span>
              </Button>
            </DialogClose>
          </DialogHeader>

          {/* Scrollable Content Area */}
          <div className="flex-1 overflow-y-auto px-6 py-4 sm:px-6 sm:py-4">
            <form onSubmit={(e) => { e.preventDefault(); handleCreateChangeRequest(); }} className="space-y-4" id="create-change-request-form">
              <DialogDescription className="text-sm text-muted-foreground text-left">
                Submit a new change request for ad slots, inventory, or other modifications.
              </DialogDescription>
              <div>
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  placeholder="Brief title for your change request"
                  value={createForm.title}
                  onChange={(e) => setCreateForm(prev => ({ ...prev, title: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Detailed description of the requested changes..."
                  className="contact-textarea min-h-[120px]"
                  value={createForm.description}
                  onChange={(e) => setCreateForm(prev => ({ ...prev, description: e.target.value }))}
                />
              </div>
            </form>
          </div>

          {/* Desktop Footer - buttons */}
          <div className="hidden sm:flex items-center justify-end gap-2 px-6 py-4 border-t border-border">
            <Button 
              type="submit" 
              form="create-change-request-form"
              onClick={handleCreateChangeRequest}
              disabled={!createForm.title || !createForm.description || isSubmitting} 
              className="evergreen-button"
            >
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isSubmitting ? "Creating..." : "Create Request"}
            </Button>
            <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              Cancel
            </Button>
          </div>

          {/* Mobile Footer - Sticky footer for mobile only */}
          <div className="sticky bottom-0 bg-background border-t border-border p-6 sm:hidden">
            <div className="space-y-3">
              <Button 
                type="submit" 
                form="create-change-request-form"
                onClick={handleCreateChangeRequest}
                disabled={!createForm.title || !createForm.description || isSubmitting} 
                className="evergreen-button w-full"
              >
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isSubmitting ? "Creating..." : "Create Request"}
              </Button>
              <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)} className="w-full">
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Production Estimate Dialog */}
      <Dialog open={isProductionDialogOpen} onOpenChange={setIsProductionDialogOpen}>
        <DialogContent className="max-w-none w-full sm:max-w-[700px] md:max-w-[800px] h-screen sm:h-auto mobile-fullscreen flex flex-col p-0 sm:p-0 overflow-hidden border-0 [&>button:not(.navigation-button)]:hidden">
          {/* Mobile Header - full width with title left, close right */}
          <DialogHeader className="flex sm:hidden flex-row items-center justify-between px-6 py-4">
            <div className="flex w-full items-center justify-between gap-3">
              <DialogTitle className="text-lg font-semibold text-left truncate flex-1">
                Fill Cost Estimate
              </DialogTitle>
              <DialogClose asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 !gap-0 relative">
                  <X className="h-4 w-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                  <span className="sr-only">Close</span>
                </Button>
              </DialogClose>
            </div>
          </DialogHeader>

          {/* Desktop Header - title and close button */}
          <DialogHeader className="hidden sm:flex flex-row items-center justify-between px-6 py-4">
            <DialogTitle>Fill Cost Estimate</DialogTitle>
            <DialogClose asChild>
              <Button variant="outline" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 flex items-center justify-center !gap-0">
                <X className="h-4 w-4 m-0" />
                <span className="sr-only">Close</span>
              </Button>
            </DialogClose>
          </DialogHeader>

          {/* Scrollable Content Area */}
          <div className="flex-1 overflow-y-auto px-6 py-4 sm:px-6 sm:py-4">
            <form onSubmit={(e) => { e.preventDefault(); handleProductionUpdate(); }} className="space-y-4" id="production-estimate-form">
              <DialogDescription className="text-sm text-muted-foreground text-left">
                Provide cost and time estimates for this change request.
              </DialogDescription>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="estimated_hours">Estimated Hours</Label>
                  <Input
                    id="estimated_hours"
                    type="number"
                    step="0.5"
                    placeholder="0.0"
                    value={productionForm.estimated_hours}
                    onChange={(e) => setProductionForm(prev => ({ ...prev, estimated_hours: parseFloat(e.target.value) || 0 }))}
                  />
                </div>
                <div>
                  <Label htmlFor="estimated_cost">Estimated Cost ($)</Label>
                  <Input
                    id="estimated_cost"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={productionForm.estimated_cost}
                    onChange={(e) => setProductionForm(prev => ({ ...prev, estimated_cost: parseFloat(e.target.value) || 0 }))}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="production_notes">Production Notes</Label>
                <Textarea
                  id="production_notes"
                  placeholder="Additional notes about the production requirements..."
                  className="contact-textarea min-h-[100px]"
                  value={productionForm.production_notes}
                  onChange={(e) => setProductionForm(prev => ({ ...prev, production_notes: e.target.value }))}
                />
              </div>
            </form>
          </div>

          {/* Desktop Footer - buttons */}
          <div className="hidden sm:flex items-center justify-end gap-2 px-6 py-4 border-t border-border">
            <Button 
              type="submit" 
              form="production-estimate-form"
              onClick={handleProductionUpdate}
              disabled={isSubmitting} 
              className="evergreen-button"
            >
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isSubmitting ? "Submitting..." : "Submit Estimate"}
            </Button>
            <Button type="button" variant="outline" onClick={() => setIsProductionDialogOpen(false)}>
              Cancel
            </Button>
          </div>

          {/* Mobile Footer - Sticky footer for mobile only */}
          <div className="sticky bottom-0 bg-background border-t border-border p-6 sm:hidden">
            <div className="space-y-3">
              <Button 
                type="submit" 
                form="production-estimate-form"
                onClick={handleProductionUpdate}
                disabled={isSubmitting} 
                className="evergreen-button w-full"
              >
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isSubmitting ? "Submitting..." : "Submit Estimate"}
              </Button>
              <Button type="button" variant="outline" onClick={() => setIsProductionDialogOpen(false)} className="w-full">
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Cancel Request Dialog */}
      <Dialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
        <DialogContent className="max-w-none w-full sm:max-w-[700px] md:max-w-[800px] h-screen sm:h-auto mobile-fullscreen flex flex-col p-0 sm:p-0 overflow-hidden border-0 [&>button:not(.navigation-button)]:hidden">
          {/* Mobile Header - full width with title left, close right */}
          <DialogHeader className="flex sm:hidden flex-row items-center justify-between px-6 py-4">
            <div className="flex w-full items-center justify-between gap-3">
              <DialogTitle className="text-lg font-semibold text-left truncate flex-1">
                Cancel Change Request
              </DialogTitle>
              <DialogClose asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 !gap-0 relative">
                  <X className="h-4 w-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                  <span className="sr-only">Close</span>
                </Button>
              </DialogClose>
            </div>
          </DialogHeader>

          {/* Desktop Header - title and close button */}
          <DialogHeader className="hidden sm:flex flex-row items-center justify-between px-6 py-4">
            <DialogTitle>Cancel Change Request</DialogTitle>
            <DialogClose asChild>
              <Button variant="outline" size="sm" className="h-9 w-9 rounded-full p-0 flex-shrink-0 flex items-center justify-center !gap-0">
                <X className="h-4 w-4 m-0" />
                <span className="sr-only">Close</span>
              </Button>
            </DialogClose>
          </DialogHeader>

          {/* Scrollable Content Area */}
          <div className="flex-1 overflow-y-auto px-6 py-4 sm:px-6 sm:py-4">
            <form onSubmit={(e) => { e.preventDefault(); handleCancel(); }} className="space-y-4" id="cancel-request-form">
              <DialogDescription className="text-sm text-muted-foreground text-left">
                Provide a reason for cancelling this change request.
              </DialogDescription>
              <div>
                <Label htmlFor="cancellation_reason">Cancellation Reason *</Label>
                <Textarea
                  id="cancellation_reason"
                  placeholder="Explain why this change request is being cancelled..."
                  className="contact-textarea min-h-[100px]"
                  value={cancelForm.cancellation_reason}
                  onChange={(e) => setCancelForm(prev => ({ ...prev, cancellation_reason: e.target.value }))}
                />
              </div>
            </form>
          </div>

          {/* Desktop Footer - buttons */}
          <div className="hidden sm:flex items-center justify-end gap-2 px-6 py-4 border-t border-border">
            <Button 
              type="submit" 
              form="cancel-request-form"
              onClick={handleCancel}
              disabled={!cancelForm.cancellation_reason || isSubmitting}
              variant="destructive"
            >
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isSubmitting ? "Cancelling..." : "Cancel Request"}
            </Button>
            <Button type="button" variant="outline" onClick={() => setIsCancelDialogOpen(false)}>
              Keep Request
            </Button>
          </div>

          {/* Mobile Footer - Sticky footer for mobile only */}
          <div className="sticky bottom-0 bg-background border-t border-border p-6 sm:hidden">
            <div className="space-y-3">
              <Button 
                type="submit" 
                form="cancel-request-form"
                onClick={handleCancel}
                disabled={!cancelForm.cancellation_reason || isSubmitting}
                variant="destructive"
                className="w-full"
              >
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isSubmitting ? "Cancelling..." : "Cancel Request"}
              </Button>
              <Button type="button" variant="outline" onClick={() => setIsCancelDialogOpen(false)} className="w-full">
                Keep Request
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Change Request Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl w-full sm:w-[90%] h-screen sm:h-[95vh] mobile-fullscreen flex flex-col p-0 overflow-hidden dark:bg-black border-0">
          <DialogHeader className="flex flex-row items-center justify-between px-6 py-4">
            {/* Mobile: Title only */}
            <div className="flex sm:hidden w-full items-center">
              <DialogTitle className="text-lg font-semibold text-left truncate flex-1">
                {selectedChangeRequest?.title}
              </DialogTitle>
            </div>

            {/* Desktop: Title and description */}
            <div className="hidden sm:flex flex-row items-center w-full">
              <div>
                <DialogTitle className="text-2xl font-bold">{selectedChangeRequest?.title}</DialogTitle>
                <DialogDescription className="text-sm text-muted-foreground mt-1">
                  Change Request #{selectedChangeRequest?.id}
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>
          
          <div className="flex-1 overflow-y-auto pb-32">
            {selectedChangeRequest && (
              <div className="space-y-6 p-6">
              {/* Status and Basic Info */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm font-medium">Status</Label>
                  <div className="mt-1">
                    {getStatusBadge(selectedChangeRequest.status)}
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium">Initiated By</Label>
                  <div className="mt-1 flex items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span>{selectedChangeRequest.initiated_by_name}</span>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium">Created</Label>
                  <div className="mt-1 flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>{new Date(selectedChangeRequest.initiated_at).toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <Label className="text-sm font-medium">Description</Label>
                <div className="mt-1 p-3 bg-muted rounded-md">
                  <p className="text-sm">{selectedChangeRequest.description}</p>
                </div>
              </div>

              {/* Cost Estimate */}
              {selectedChangeRequest.estimated_cost !== undefined && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium">Estimated Cost</Label>
                    <div className="mt-1 flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                      <span className="text-lg font-semibold">${selectedChangeRequest.estimated_cost.toFixed(2)}</span>
                    </div>
                  </div>
                  {selectedChangeRequest.estimated_hours && (
                    <div>
                      <Label className="text-sm font-medium">Estimated Hours</Label>
                      <div className="mt-1 flex items-center gap-2">
                        <Clock3 className="h-4 w-4 text-muted-foreground" />
                        <span className="text-lg font-semibold">{selectedChangeRequest.estimated_hours}h</span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Production Notes */}
              {selectedChangeRequest.production_notes && (
                <div>
                  <Label className="text-sm font-medium">Production Notes</Label>
                  <div className="mt-1 p-3 bg-muted rounded-md">
                    <p className="text-sm">{selectedChangeRequest.production_notes}</p>
                  </div>
                </div>
              )}

              {/* Approval Timeline */}
              <div>
                <Label className="text-sm font-medium">Approval Timeline</Label>
                <div className="mt-2 space-y-3">
                  <div className="flex items-start gap-3 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <div className="font-medium flex items-center gap-2 md:whitespace-nowrap">
                        <span>Request initiated by {selectedChangeRequest.initiated_by_name}</span>
                        <span className="text-muted-foreground text-xs hidden md:inline">
                          {new Date(selectedChangeRequest.initiated_at).toLocaleString()}
                        </span>
                      </div>
                      <div className="text-muted-foreground text-xs mt-1 md:hidden">
                        {new Date(selectedChangeRequest.initiated_at).toLocaleString()}
                      </div>
                    </div>
                  </div>
                  
                  {selectedChangeRequest.production_filled_at && (
                    <div className="flex items-start gap-3 text-sm">
                      <CheckCircle className="h-4 w-4 text-blue-600 flex-shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium flex items-center gap-2 md:whitespace-nowrap">
                          <span>Cost estimate provided by {selectedChangeRequest.production_manager_name}</span>
                          <span className="text-muted-foreground text-xs hidden md:inline">
                            {new Date(selectedChangeRequest.production_filled_at).toLocaleString()}
                          </span>
                        </div>
                        <div className="text-muted-foreground text-xs mt-1 md:hidden">
                          {new Date(selectedChangeRequest.production_filled_at).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {selectedChangeRequest.client_approved_at && (
                    <div className="flex items-start gap-3 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium flex items-center gap-2 md:whitespace-nowrap">
                          <span>Approved by client ({selectedChangeRequest.client_approved_by_name})</span>
                          <span className="text-muted-foreground text-xs hidden md:inline">
                            {new Date(selectedChangeRequest.client_approved_at).toLocaleString()}
                          </span>
                        </div>
                        <div className="text-muted-foreground text-xs mt-1 md:hidden">
                          {new Date(selectedChangeRequest.client_approved_at).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {selectedChangeRequest.evergreen_approved_at && (
                    <div className="flex items-start gap-3 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium flex items-center gap-2 md:whitespace-nowrap">
                          <span>Final approval by {selectedChangeRequest.evergreen_approved_by_name}</span>
                          <span className="text-muted-foreground text-xs hidden md:inline">
                            {new Date(selectedChangeRequest.evergreen_approved_at).toLocaleString()}
                          </span>
                        </div>
                        <div className="text-muted-foreground text-xs mt-1 md:hidden">
                          {new Date(selectedChangeRequest.evergreen_approved_at).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {selectedChangeRequest.cancelled_at && (
                    <div className="flex items-start gap-3 text-sm">
                      <XCircle className="h-4 w-4 text-red-600 flex-shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium flex items-center gap-2 md:whitespace-nowrap">
                          <span>Cancelled by {selectedChangeRequest.cancelled_by_name}</span>
                          <span className="text-muted-foreground text-xs hidden md:inline">
                            {new Date(selectedChangeRequest.cancelled_at).toLocaleString()}
                          </span>
                        </div>
                        <div className="text-muted-foreground text-xs mt-1 md:hidden">
                          {new Date(selectedChangeRequest.cancelled_at).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Cancellation Reason */}
              {selectedChangeRequest.cancellation_reason && (
                <div>
                  <Label className="text-sm font-medium">Cancellation Reason</Label>
                  <div className="mt-1 p-3 bg-red-50 border border-red-200 rounded-md">
                    <p className="text-sm text-red-800">{selectedChangeRequest.cancellation_reason}</p>
                  </div>
                </div>
              )}

            </div>
          )}
          </div>

          {/* Footer with Action Buttons */}
          <div className="flex justify-end gap-2 p-6 bg-background dark:bg-[#262626] border-t border-border">
            {(() => {
              const userAction = canUserTakeAction(selectedChangeRequest)
              return userAction ? (
                <Button
                  variant={userAction.action === "cancel" ? "destructive" : "default"}
                  onClick={() => {
                    if (userAction.action === "production") {
                      setProductionForm({
                        estimated_hours: selectedChangeRequest.estimated_hours || 0,
                        estimated_cost: selectedChangeRequest.estimated_cost || 0,
                        production_notes: selectedChangeRequest.production_notes || ""
                      })
                      setIsProductionDialogOpen(true)
                      setIsViewDialogOpen(false)
                    } else if (userAction.action === "client_approve") {
                      handleClientApprove()
                      setIsViewDialogOpen(false)
                    } else if (userAction.action === "evergreen_approve") {
                      setIsFinalApprovalConfirmOpen(true)
                      setIsViewDialogOpen(false)
                    } else if (userAction.action === "cancel") {
                      setIsCancelDialogOpen(true)
                      setIsViewDialogOpen(false)
                    }
                  }}
                >
                  {userAction.label}
                </Button>
              ) : null
            })()}
            <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Final Approval Confirmation Dialog */}
      <AlertDialog open={isFinalApprovalConfirmOpen} onOpenChange={setIsFinalApprovalConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-primary">
              <CheckCircle className="h-5 w-5 inline-block mr-2" />
              Confirm Final Approval
            </AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogDescription>
            Are you sure you want to give final approval to this change request? This action cannot be undone and will mark the request as fully approved.
          </AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogAction onClick={handleEvergreenApprove} className="evergreen-button" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Approving...
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Approve
                </>
              )}
            </AlertDialogAction>
            <AlertDialogCancel disabled={isSubmitting}>Cancel</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
