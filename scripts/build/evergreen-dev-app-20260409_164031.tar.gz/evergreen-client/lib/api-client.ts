import { toast } from "sonner"

export async function authHeaders() {
  const token = localStorage.getItem("access_token")
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  }
}

interface LoginCredentials {
  username: string
  password: string
}

interface Token {
  access_token: string
  token_type: string
}

interface UserSettings {
  // Appearance
  liquidGlassEnabled?: boolean
  highContrastMode?: boolean
  interactiveAnimationsEnabled?: boolean
  shadowsEnabled?: boolean
  themeColor?: "emerald" | "blue" | "purple" | "red" | "orange" | "cyan" | "pink" | "indigo"
  themeMode?: "light" | "dark" | "system"
  borderRadiusStyle?: "circle" | "squircle" | "rounded" | "square"
  tableDensity?: {
    revenueLedger?: "compact" | "default"
    shows?: "compact" | "default"
  }
  cardStyle?: "bordered" | "elevated" | "flat"
  fontScale?: number
  reduceMotion?: boolean
  
  // Localization & Formatting
  dateFormat?: "MM/DD/YYYY" | "DD/MM/YYYY" | "YYYY-MM-DD"
  timeFormat?: "12h" | "24h"
  
  // Behavior & UX
  defaultLandingPage?: "dashboard" | "shows" | "revenue" | "partners" | "archived" | "settings"
  sidebarCollapsed?: boolean
  
  // Pagination
  globalPageSize?: number | null
  pagination?: {
    showsManagement?: number
    userManagement?: number
    revenueLedger?: number
    partnerPayments?: number
    archivedShows?: number
    feedbacks?: number
    changeRequests?: number
    splitHistory?: number
  }
  
  // Notifications
  toastDuration?: number
  
  // Security & Session
  sessionTimeout?: number
  
  // Developer
  developerOptionsEnabled?: boolean
  debugMode?: boolean
  apiEndpointOverride?: string | null
  showApiResponseTimes?: boolean
}

interface User {
  id: string
  name: string | null
  email: string | null
  password_hash: string | null
  role: "admin" | "partner" | "internal_full_access" | "internal_show_access" | null
  created_at: string | null
  mapped_vendor_qbo_id?: number | null
  mapped_vendor_name?: string | null
  settings?: UserSettings | null
}

interface Show {
  id: string;
  title: string;
  minimum_guarantee: boolean;
  annual_usd: Record<string, any>;
  subnetwork_id: string;
  media_type: "video" | "audio" | "both";
  rate_card: boolean;
  relationship_level: "strong" | "medium" | "weak";
  show_type: "Branded" | "Original" | "Partner" | "Hybrid";
  ranking_category: "1" | "2" | "3" | "4" | "5" | null;
  evergreen_ownership_pct: number;
  has_sponsorship_revenue: boolean;
  has_non_evergreen_revenue: boolean;
  requires_partner_access: boolean;
  has_branded_revenue: boolean;
  has_marketing_revenue: boolean;
  has_web_mgmt_revenue: boolean;
  genre_name: string;
  is_original: boolean;
  cadence: "Daily" | "Weekly" | "Biweekly" | "Monthly" | "Ad hoc";
  latest_cpm_usd: number;
  span_cpm_usd: number;
  ad_slots: number;
  avg_show_length_mins: number;
  start_date: string;
  side_bonus_percent: number;
  youtube_ads_percent: number;
  subscriptions_percent: number;
  standard_ads_percent: number;
  sponsorship_ad_fp_lead_percent: number;
  sponsorship_ad_partner_lead_percent: number;
  sponsorship_ad_partner_sold_percent: number;
  programmatic_ads_span_percent: number;
  merchandise_percent: number;
  branded_revenue_percent: number;
  marketing_services_revenue_percent: number;
  direct_customer_hands_off_percent: number;
  youtube_hands_off_percent: number;
  subscription_hands_off_percent: number;
  revenue_2023: number;
  revenue_2024: number;
  revenue_2025: number;
  show_host_contact: string;
  show_primary_contact: string;
  age_demographic: "18-24" | "25-34" | "35-44" | "45-54" | "55+";
  region: string;
  is_undersized: boolean;  // camelCase to match your database
  gender: string;
  is_active: boolean;      // camelCase to match your database
  primary_education: string;
  secondary_education: string;
  evergreen_production_staff_name: string;
  qbo_show_name: string;
  qbo_show_id: string;
  // Archive fields
  is_archived?: boolean;
  archived_at?: string;
  archived_by?: string;
  archived_by_id?: string;
  // Creation fields
  created_at?: string;
  created_by?: string;
  created_by_id?: string;
}

interface ShowCreate {
  title: string;
  minimum_guarantee?: boolean;
  annual_usd?: Record<string, any>;
  subnetwork_id?: string;
  media_type?: "video" | "audio" | "both";
  rate_card?: boolean;
  relationship_level?: "strong" | "medium" | "weak";
  show_type?: "Branded" | "Original" | "Partner" | "Hybrid";
  ranking_category?: "1" | "2" | "3" | "4" | "5" | null;
  evergreen_ownership_pct?: number;
  has_sponsorship_revenue?: boolean;
  has_non_evergreen_revenue?: boolean;
  requires_partner_access?: boolean;
  has_branded_revenue?: boolean;
  has_marketing_revenue?: boolean;
  has_web_mgmt_revenue?: boolean;
  genre_name?: string;
  is_original?: boolean;
  cadence?: "Daily" | "Weekly" | "Biweekly" | "Monthly" | "Ad hoc";
  latest_cpm_usd?: number;
  span_cpm_usd?: number;
  ad_slots?: number;
  avg_show_length_mins?: number;
  start_date?: string;
  side_bonus_percent?: number;
  youtube_ads_percent?: number;
  subscriptions_percent?: number;
  standard_ads_percent?: number;
  sponsorship_ad_fp_lead_percent?: number;
  sponsorship_ad_partner_lead_percent?: number;
  sponsorship_ad_partner_sold_percent?: number;
  programmatic_ads_span_percent?: number;
  merchandise_percent?: number;
  branded_revenue_percent?: number;
  marketing_services_revenue_percent?: number;
  direct_customer_hands_off_percent?: number;
  youtube_hands_off_percent?: number;
  subscription_hands_off_percent?: number;
  revenue_2023?: number;
  revenue_2024?: number;
  revenue_2025?: number;
  evergreen_production_staff_name?: string;
  show_host_contact?: string;
  show_primary_contact?: string;
  age_demographic?: "18-24" | "25-34" | "35-44" | "45-54" | "55+";
  is_undersized?: boolean;  // camelCase to match your database
  is_active?: boolean;      // camelCase to match your database
  primary_education?: string;
  secondary_education?: string;
  region?: string;
  gender?: string;
  qbo_show_id?: number
  qbo_show_name?: string
}

interface ShowUpdate {
  title: string;
  minimum_guarantee?: boolean;
  annual_usd?: Record<string, any>;
  subnetwork_id?: string;
  media_type?: "video" | "audio" | "both";
  rate_card?: boolean;
  relationship_level?: "strong" | "medium" | "weak";
  show_type?: "Branded" | "Original" | "Partner" | "Hybrid";
  evergreen_ownership_pct?: number;
  has_sponsorship_revenue?: boolean;
  has_non_evergreen_revenue?: boolean;
  requires_partner_access?: boolean;
  has_branded_revenue?: boolean;
  has_marketing_revenue?: boolean;
  has_web_mgmt_revenue?: boolean;
  genre_name?: string;
  is_original?: boolean;
  cadence?: "Daily" | "Weekly" | "Biweekly" | "Monthly" | "Ad hoc";
  latest_cpm_usd?: number;
  span_cpm_usd?: number;
  ad_slots?: number;
  avg_show_length_mins?: number;
  start_date?: string;
  side_bonus_percent?: number;
  youtube_ads_percent?: number;
  subscriptions_percent?: number;
  standard_ads_percent?: number;
  sponsorship_ad_fp_lead_percent?: number;
  sponsorship_ad_partner_lead_percent?: number;
  sponsorship_ad_partner_sold_percent?: number;
  programmatic_ads_span_percent?: number;
  merchandise_percent?: number;
  branded_revenue_percent?: number;
  marketing_services_revenue_percent?: number;
  direct_customer_hands_off_percent?: number;
  youtube_hands_off_percent?: number;
  subscription_hands_off_percent?: number;
  revenue_2023?: number;
  revenue_2024?: number;
  revenue_2025?: number;
  evergreen_production_staff_name?: string;
  show_host_contact?: string;
  show_primary_contact?: string;
  age_demographic?: "18-24" | "25-34" | "35-44" | "45-54" | "55+";
  is_undersized?: boolean;  // camelCase to match your database
  is_active?: boolean;      // camelCase to match your database
  primary_education?: string;
  secondary_education?: string;
  gender?: string;
  region?: string;
  qbo_show_id?: number
  qbo_show_name?: string
}

interface PartnerCreate {
  name: string
  email: string
  password: string
}

interface PasswordUpdate {
  password: string
}

interface FilterParams {
  title?: string | null
  media_type?: "video" | "audio" | "both" | null
  rate_card?: boolean | null
  relationship_level?: "strong" | "medium" | "weak" | null
  show_type?: "Branded" | "Original" | "Partner" | "Hybrid" | null
  has_sponsorship_revenue?: boolean | null
  has_non_evergreen_revenue?: boolean | null
  requires_partner_access?: boolean | null
  has_branded_revenue?: boolean | null
  has_marketing_revenue?: boolean | null
  has_web_mgmt_revenue?: boolean | null
  is_original?: boolean | null
}

// --- NEW INTERFACE FOR BULK RESPONSE ---
interface BulkImportResponse {
  message: string;
  total: number;
  successful: number;
  failed: number;
  errors: string[];
}

// --- NEW INTERFACES FOR DUPLICATE HANDLING ---
interface DuplicateCheckResult {
  title: string;
  exists: boolean;
  existing_show: Show | null;
}

interface DuplicateCheckResponse {
  duplicates: DuplicateCheckResult[];
  total_checked: number;
  duplicates_found: number;
  message: string;
}

interface DuplicateAction {
  title: string;
  action: "create" | "update" | "skip";
}

interface BulkImportWithActionsResponse {
  message: string;
  total: number;
  successful: number;
  updated: number;
  skipped: number;
  failed: number;
  errors: string[];
  warnings?: string[];
}

export interface ShowFormOptionsResponse {
  genres: string[];
  showTypes: string[];
  mediaTypes: string[];
  relationshipLevels: string[];
  rankingCategories: string[];
  cadences: string[];
  regions: string[];
  educationLevels: string[];
  ageDemographics: string[];
}

interface DatabaseImportResponse {
  success: boolean;
  message: string;
  tables_affected?: number;
  warnings?: string[];
  executed_at: string;
  // Async job mode
  job_id?: string;
  status?: "queued" | "running" | "succeeded" | "failed";
}

interface DatabaseImportJobStatus {
  job_id: string;
  status: "queued" | "running" | "succeeded" | "failed";
  message: string;
  queued_at: string;
  started_at?: string | null;
  finished_at?: string | null;
  result?: DatabaseImportResponse | null;
  error?: string | null;
}

interface DatabaseTableInfo {
  table_name: string;
  row_count: number;
  data_size_mb: number;
  index_size_mb: number;
  last_updated: string | null;
}

interface DatabaseStatus {
  database_name: string;
  total_tables: number;
  total_rows: number;
  total_data_size_mb: number;
  total_index_size_mb: number;
  total_size_mb: number;
  tables: DatabaseTableInfo[];
  checked_at: string;
  warning?: string;
}

class ApiClient {
  private baseUrl: string
  private token: string | null = null

  // DEFAULT to same-origin '/api' if env is not set
  constructor(baseUrl = (process.env.NEXT_PUBLIC_API_URL ?? "/api") as string) {
    this.baseUrl = baseUrl
    if (typeof window !== "undefined") {
      // Check both storage locations on initialization
      this.token = this.getStoredToken()
    }
  }

  // Get the actual base URL (checks localStorage override for runtime config)
  private getBaseUrl(): string {
    if (typeof window !== 'undefined') {
      // Check for runtime override in localStorage (useful for mobile testing)
      const override = localStorage.getItem('api_url_override')
      if (override) {
        return override
      }
    }
    return this.baseUrl
  }

  /**
   * Turn API error detail (FastAPI validation array or other shapes) into a human-readable string.
   */
  private formatApiErrorDetail(detail: unknown): string {
    if (typeof detail === "string") return detail
    if (Array.isArray(detail)) {
      const parts = detail.map((item: { loc?: unknown[]; msg?: string }) => {
        const loc = item?.loc
        const msg = item?.msg ?? (item as { message?: string }).message ?? "Validation error"
        if (Array.isArray(loc) && loc.length >= 2) {
          // loc e.g. ["body", 0, "start_date"] -> row index 0, field "start_date"
          const bodyIndex = loc[1]
          const field = typeof loc[2] === "string" ? loc[2] : loc[loc.length - 1]
          const rowNum = typeof bodyIndex === "number" ? bodyIndex + 1 : bodyIndex
          return `Row ${rowNum} – ${field}: ${msg}`
        }
        if (Array.isArray(loc) && loc.length === 1) return `${loc[0]}: ${msg}`
        return msg
      })
      return parts.join("\n")
    }
    if (detail && typeof detail === "object") {
      const obj = detail as { message?: string; msg?: string }
      if (typeof obj.message === "string") return obj.message
      if (typeof obj.msg === "string") return obj.msg
    }
    try {
      const s = JSON.stringify(detail)
      return s.length > 200 ? s.slice(0, 200) + "…" : s || "Validation failed"
    } catch {
      return "Validation failed"
    }
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.getBaseUrl()}${endpoint}`
    const headers = new Headers(options.headers)
    if (!headers.has("Content-Type")) {
      headers.set("Content-Type", "application/json")
    }
    if (typeof window !== "undefined") {
      if (!this.token) this.token = this.getStoredToken()
    }
    if (this.token) {
      headers.set("Authorization", `Bearer ${this.token}`)
    }
    const response = await fetch(url, { ...options, headers })
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      // 422 with structured validation detail is handled by the UI (e.g. import validation table); don't log as error
      const isValidationError = response.status === 422 && Array.isArray(errorData.detail)
      // Import job polling can hit 404 if backend isn't deployed yet; don't spam console for that.
      const isImportJobEndpoint = endpoint.startsWith("/admin/database/import/jobs/")
      const suppressConsoleError = isValidationError || (isImportJobEndpoint && response.status === 404)
      if (!suppressConsoleError) {
        console.error(`API Error: ${response.status} - ${response.statusText}`, errorData)
      }
      if (response.status === 401) {
        throw new Error("Authentication required. Please log in again.")
      } else if (response.status === 404) {
        if (isImportJobEndpoint) {
          throw new Error("Import job tracking is unavailable (backend not updated yet). Refresh after deploying the latest backend.")
        }
        throw new Error("Endpoint not found. Please check if the backend server is running with the latest code.")
      }
      const message = errorData.detail != null
        ? this.formatApiErrorDetail(errorData.detail)
        : `HTTP error! status: ${response.status}`
      const err = new Error(message) as Error & { validationDetails?: unknown }
      if (Array.isArray(errorData.detail)) err.validationDetails = errorData.detail
      throw err
    }
    if (response.status === 204) {
      return {} as T
    }
    return response.json()
  }

  setToken(token: string, rememberMe: boolean = true) {
    this.token = token
    if (typeof window !== "undefined") {
      // Clear from both storage locations first
      localStorage.removeItem("access_token")
      sessionStorage.removeItem("access_token")
      
      // Store in appropriate location based on rememberMe
      if (rememberMe) {
        localStorage.setItem("access_token", token)
      } else {
        sessionStorage.setItem("access_token", token)
      }
    }
  }

  clearToken() {
    this.token = null
    if (typeof window !== "undefined") {
      localStorage.removeItem("access_token")
      sessionStorage.removeItem("access_token")
    }
  }

  getStoredToken(): string | null {
    if (typeof window === "undefined") return null
    
    // Check localStorage first (remember me), then sessionStorage
    return localStorage.getItem("access_token") || sessionStorage.getItem("access_token")
  }

  setTokenInMemory(token: string) {
    // Set token in memory only, without storing in localStorage/sessionStorage
    this.token = token
  }

  async login(credentials: LoginCredentials): Promise<{ success: boolean; token?: Token; error?: string }> {
    try {
      const formData = new URLSearchParams()
      formData.append("username", credentials.username)
      formData.append("password", credentials.password)
      
      const response = await fetch(`${this.getBaseUrl()}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: formData,
      })
      
      if (!response.ok) {
        // Handle different types of errors
        if (response.status === 401) {
          return { success: false, error: "Invalid username or password" }
        } else if (response.status === 422) {
          return { success: false, error: "Invalid credentials format" }
        } else if (response.status >= 500) {
          return { success: false, error: "Server error. Please try again later" }
        } else {
          // Try to get error details from response
          try {
            const errorData = await response.json()
            return { success: false, error: errorData.detail || `Login failed with status ${response.status}` }
          } catch {
            return { success: false, error: `Login failed with status ${response.status}` }
          }
        }
      }
      
      const token = await response.json()
      // Don't store token here - let auth-context handle it with rememberMe preference
      // Just set it in memory for immediate use
      this.token = token.access_token
      return { success: true, token }
    } catch (error) {
      // Handle network errors and other exceptions
      if (error instanceof TypeError && error.message.includes('fetch')) {
        return { success: false, error: "Unable to connect to server. Please check your internet connection and try again." }
      }
      // Handle other unexpected errors
      return { success: false, error: "An unexpected error occurred. Please try again." }
    }
  }

  async getCurrentUser(): Promise<User> {
    return this.request<User>("/users/me")
  }

  // User Settings Methods
  async getUserSettings(): Promise<UserSettings> {
    try {
      return await this.request<UserSettings>("/users/me/settings")
    } catch (error) {
      console.error("Failed to get user settings:", error)
      return {}
    }
  }

  async updateUserSettings(settings: UserSettings): Promise<{ message: string; settings: UserSettings }> {
    return this.request<{ message: string; settings: UserSettings }>("/users/me/settings", {
      method: "PUT",
      body: JSON.stringify({ settings }),
    })
  }

  async getUserById(userId: string): Promise<User> {
    return this.request<User>(`/users/${userId}`)
  }

  async deleteUser(userId: string): Promise<void> {
    return this.request<void>(`/users/${userId}`, { method: "DELETE" })
  }

  async getAllPodcasts(): Promise<Show[]> {
    return this.request<Show[]>("/podcasts")
  }

  async filterPodcasts(params: FilterParams): Promise<Show[]> {
    const searchParams = new URLSearchParams()
    Object.entries(params).forEach(([key, value]) => {
      if (value !== null && value !== undefined) {
        searchParams.append(key, String(value))
      }
    })
    const queryString = searchParams.toString()
    const endpoint = queryString ? `/podcasts/filter?${queryString}` : "/podcasts/filter"
    return this.request<Show[]>(endpoint)
  }

  async getPodcast(showId: string): Promise<Show> {
    return this.request<Show>(`/podcasts/${showId}`)
  }

  async getShowFormOptions(): Promise<ShowFormOptionsResponse> {
    return this.request<ShowFormOptionsResponse>("/show-form-options")
  }

  async createPodcast(data: ShowCreate): Promise<Show> {
    try {
      console.log("API Client sending data to backend:", JSON.stringify(data, null, 2))
      const newShow = await this.request<Show>("/podcasts", {
        method: "POST",
        body: JSON.stringify(data),
      })
      toast.success("Show created successfully!")
      return newShow
    } catch (error: any) {
      console.error("API Client error:", error)
      toast.error(error.message || "Failed to create show.")
      throw error
    }
  }

  // --- UPDATED BULK CREATE METHOD ---
  async bulkCreatePodcasts(data: ShowCreate[]): Promise<BulkImportResponse> {
    try {
      console.log("Bulk import sending data to backend:", JSON.stringify(data, null, 2))
      const response = await this.request<BulkImportResponse>("/podcasts/bulk-import", {
        method: "POST",
        body: JSON.stringify(data),
      });

      // Custom toast message based on the outcome
      if (response.failed > 0 && response.successful === 0) {
        toast.error(response.message || "All show imports failed.");
      } else if (response.failed > 0) {
        toast.warning(response.message || "Bulk import completed with some errors.");
      } else {
        toast.success(response.message || "Bulk import completed successfully!");
      }
      
      return response;
    } catch (error: any) {
      console.error("Bulk import error:", error)
      // This will now only catch true network/server errors
      toast.error(error.message || "An unexpected error occurred during the import process.");
      throw error;
    }
  }
  // --- END UPDATED METHOD ---

  // --- NEW DUPLICATE CHECKING METHODS ---
  async checkDuplicates(data: ShowCreate[]): Promise<DuplicateCheckResponse> {
    try {
      console.log("Checking for duplicates:", JSON.stringify(data, null, 2))
      const response = await this.request<DuplicateCheckResponse>("/podcasts/check-duplicates", {
        method: "POST",
        body: JSON.stringify(data),
      })
      return response
    } catch (error: any) {
      console.error("Duplicate check error:", error)
      throw error
    }
  }

  async checkSingleDuplicate(data: ShowCreate): Promise<{ exists: boolean; existing_show: any; is_archived: boolean }> {
    try {
      console.log("Checking single duplicate:", JSON.stringify(data, null, 2))
      const response = await this.request<{ exists: boolean; existing_show: any; is_archived: boolean }>("/podcasts/check-duplicate", {
        method: "POST",
        body: JSON.stringify(data),
      })
      return response
    } catch (error: any) {
      console.error("Single duplicate check error:", error)
      throw error
    }
  }

  async bulkCreatePodcastsWithActions(
    data: ShowCreate[], 
    actions: DuplicateAction[]
  ): Promise<BulkImportWithActionsResponse> {
    try {
      console.log("Bulk import with actions:", JSON.stringify({ data, actions }, null, 2))
      const response = await this.request<BulkImportWithActionsResponse>("/podcasts/bulk-import-with-actions", {
        method: "POST",
        body: JSON.stringify({ shows_data: data, actions }),
      })

      // Custom toast message based on the outcome
      if (response.failed > 0 && response.successful === 0 && response.updated === 0) {
        toast.error(response.message || "All show imports failed.")
      } else if (response.failed > 0) {
        toast.warning(response.message || "Bulk import completed with some errors.")
      } else {
        toast.success(response.message || "Bulk import completed successfully!")
      }
      
      return response
    } catch (error: any) {
      console.error("Bulk import with actions error:", error)
      toast.error(error.message || "An unexpected error occurred during the import process.")
      throw error
    }
  }

  async updatePodcast(showId: string, data: ShowUpdate): Promise<Show> {
    try {
      const updatedShow = await this.request<Show>(`/podcasts/${showId}`, {
        method: "PUT",
        body: JSON.stringify(data),
      })
      toast.success("Show updated successfully!")
      return updatedShow
    } catch (error: any) {
      toast.error(error.message || "Failed to update show.")
      throw error
    }
  }

  async deletePodcast(showId: string): Promise<void> {
    try {
      await this.request<void>(`/podcasts/${showId}`, { method: "DELETE" })
      toast.success("Show deleted successfully!")
    } catch (error: any) {
      toast.error(error.message || "Failed to delete show.")
      throw error
    }
  }

  async bulkDeletePodcasts(showIds: string[]): Promise<{ successful: number; failed: number; errors: string[]; message: string }> {
    try {
      const response = await this.request<{ successful: number; failed: number; errors: string[]; message: string }>("/podcasts/bulk-delete", {
        method: "DELETE",
        body: JSON.stringify({ show_ids: showIds }),
      })
      return response
    } catch (error: any) {
      console.error("Bulk delete podcasts error:", error)
      throw error
    }
  }

  async createPartner(data: PartnerCreate): Promise<User> {
    return this.request<User>("/partners", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  async updatePartnerPassword(userId: string, data: PasswordUpdate): Promise<void> {
    return this.request<void>(`/partners/${userId}/password`, {
      method: "PUT",
      body: JSON.stringify(data),
    })
  }

  async getMyPodcasts(): Promise<Show[]> {
    return this.request<Show[]>("/partners/me/podcasts")
  }

  async getPodcastsForPartner(partnerId: string): Promise<Show[]> {
    return this.request<Show[]>(`/partners/${partnerId}/podcasts`)
  }

  async associatePartnerWithShow(showId: string, partnerId: string): Promise<void> {
    return this.request<void>(`/podcasts/${showId}/partners/${partnerId}`, {
      method: "POST",
    })
  }

  async unassociatePartnerFromShow(showId: string, partnerId: string): Promise<void> {
    return this.request<void>(`/podcasts/${showId}/partners/${partnerId}`, {
      method: "DELETE",
    })
  }

  // Archive methods
  async archiveShow(showId: string): Promise<Show> {
    try {
      const response = await this.request<Show>(`/podcasts/${showId}/archive`, {
        method: "PATCH",
      })
      toast.success("Show archived successfully!")
      return response
    } catch (error: any) {
      toast.error(error.message || "Failed to archive show.")
      throw error
    }
  }

  async unarchiveShow(showId: string): Promise<Show> {
    try {
      const response = await this.request<Show>(`/podcasts/${showId}/unarchive`, {
        method: "PATCH",
      })
      toast.success("Show unarchived successfully!")
      return response
    } catch (error: any) {
      toast.error(error.message || "Failed to unarchive show.")
      throw error
    }
  }

  async getArchivedShows(): Promise<Show[]> {
    try {
      return await this.request<Show[]>("/podcasts/archived")
    } catch (error: any) {
      // If the error is "not found" or similar, return empty array instead of throwing
      if (error.message?.includes("not found") || error.message?.includes("404")) {
        return []
      }
      throw error
    }
  }

  async bulkArchiveShows(showIds: string[]): Promise<{ successful: number; failed: number; message: string }> {
    try {
      const response = await this.request<{ successful: number; failed: number; message: string }>("/podcasts/bulk-archive", {
        method: "PATCH",
        body: JSON.stringify({ show_ids: showIds }),
      })
      toast.success(`Successfully archived ${response.successful} shows!`)
      return response
    } catch (error: any) {
      toast.error(error.message || "Failed to archive shows.")
      throw error
    }
  }

  async bulkUnarchiveShows(showIds: string[]): Promise<{ successful: number; failed: number; message: string }> {
    try {
      const response = await this.request<{ successful: number; failed: number; message: string }>("/podcasts/bulk-unarchive", {
        method: "PATCH",
        body: JSON.stringify({ show_ids: showIds }),
      })
      toast.success(`Successfully unarchived ${response.successful} shows!`)
      return response
    } catch (error: any) {
      toast.error(error.message || "Failed to unarchive shows.")
      throw error
    }
  }

  // Database Export/Import (Developer Options - Admin only)
  async exportDatabase(): Promise<Blob> {
    const url = `${this.getBaseUrl()}/admin/database/export`
    const headers = new Headers()
    if (this.token) {
      headers.set("Authorization", `Bearer ${this.token}`)
    }
    
    const response = await fetch(url, { headers })
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(errorData.detail || `Export failed with status ${response.status}`)
    }
    
    return response.blob()
  }

  async importDatabase(
    file: File,
    options?: { mode?: "legacy_python" | "full_replace_fast" | "full_replace_safe"; confirm?: string }
  ): Promise<DatabaseImportResponse> {
    const url = `${this.getBaseUrl()}/admin/database/import`
    const formData = new FormData()
    formData.append('file', file)
    if (options?.mode) {
      formData.append("mode", options.mode)
    }
    if (options?.confirm) {
      formData.append("confirm", options.confirm)
    }
    
    const headers = new Headers()
    if (this.token) {
      headers.set("Authorization", `Bearer ${this.token}`)
    }
    // Don't set Content-Type - let browser set it with boundary for FormData
    
    // Add timeout to prevent hanging (20 minutes for large imports)
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 20 * 60 * 1000) // 20 minutes for large database imports
    
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers,
        body: formData,
        signal: controller.signal,
      })
      
      clearTimeout(timeoutId)
      
      // Async job accepted: return a lightweight response the UI can poll
      if (response.status === 202) {
        const data = await response.json().catch(() => ({} as any))
        return {
          success: true,
          message: data.message || "Import started.",
          executed_at: new Date().toISOString(),
          job_id: data.job_id,
          status: data.status || "queued",
        }
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        if (response.status === 401) {
          throw new Error("Authentication required. Please log in again.")
        }
        throw new Error(errorData.detail || `Import failed with status ${response.status}`)
      }
      
      return response.json()
    } catch (error: any) {
      clearTimeout(timeoutId)
      if (error.name === 'AbortError') {
        throw new Error("Import request timed out. The file may be too large or the server is taking too long to respond.")
      }
      throw error
    }
  }

  async getDatabaseStatus(): Promise<DatabaseStatus> {
    return this.request<DatabaseStatus>("/admin/database/status")
  }

  async getDatabaseImportJob(jobId: string): Promise<DatabaseImportJobStatus> {
    return this.request<DatabaseImportJobStatus>(`/admin/database/import/jobs/${jobId}`)
  }
}

export interface AllclassItem {
  id: number
  name: string
}

// Use same-origin '/api' if env missing
const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "/api"

// Helper function to get API URL (checks localStorage override for runtime config)
function getApiUrl(): string {
  if (typeof window !== 'undefined') {
    // Check for runtime override in localStorage (useful for mobile testing)
    const override = localStorage.getItem('api_url_override')
    if (override) {
      return override
    }
  }
  return API_URL
}

export async function fetchAllclass(): Promise<AllclassItem[]> {
  const apiUrl = getApiUrl()
  const res = await fetch(`${apiUrl}/qbo/allclass`, {
    method: 'GET',
    headers: await authHeaders(),
  })
  if (!res.ok) throw new Error('Failed to load QBO shows')
  return res.json()
}

// Create apiClient - it will check localStorage dynamically on each request
export const apiClient = new ApiClient(API_URL)

export type { 
  User,
  UserSettings,
  Show, 
  ShowCreate, 
  ShowUpdate, 
  PartnerCreate, 
  PasswordUpdate, 
  FilterParams, 
  Token, 
  LoginCredentials,
  DuplicateCheckResult,
  DuplicateCheckResponse,
  DuplicateAction,
  BulkImportWithActionsResponse,
  DatabaseImportResponse,
  DatabaseTableInfo,
  DatabaseStatus
}