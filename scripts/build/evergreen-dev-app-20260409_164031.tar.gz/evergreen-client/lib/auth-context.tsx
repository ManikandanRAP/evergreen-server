"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { apiClient, type User, type LoginCredentials } from "./api-client"
import { useSettings } from "./settings-context"

export type UserRole = "admin" | "partner" | "internal_full_access" | "internal_show_access"

interface AuthContextType {
  user: User | null
  token: string | null // Expose token in the context
  login: (email: string, password: string, rememberMe?: boolean) => Promise<{ success: boolean; error?: string }>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [token, setToken] = useState<string | null>(null) // Add state for the token
  const [isLoading, setIsLoading] = useState(true)
  const { syncSettingsFromServer } = useSettings()

  useEffect(() => {
    // Check for stored token and validate it on initial load
    // Check both localStorage (remember me) and sessionStorage (session only)
    const initAuth = async () => {
      const storedToken = apiClient.getStoredToken()
      if (storedToken) {
        try {
          // Set token in memory (don't re-store, just use existing)
          apiClient.setTokenInMemory(storedToken)
          const currentUser = await apiClient.getCurrentUser()
          setUser(currentUser)
          setToken(storedToken) // Set the token in state
          
          // Sync settings from server after authentication
          await syncSettingsFromServer()
        } catch (error) {
          console.error("Failed to validate token:", error)
          apiClient.clearToken()
          setToken(null)
        }
      }
      setIsLoading(false)
    }

    initAuth()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const login = async (email: string, password: string, rememberMe: boolean = true): Promise<{ success: boolean; error?: string }> => {
    const credentials: LoginCredentials = {
      username: email, // API uses username field for email
      password,
    }

    const result = await apiClient.login(credentials)
    
    if (result.success && result.token) {
      try {
        // Store token with rememberMe preference
        apiClient.setToken(result.token.access_token, rememberMe)
        
        const currentUser = await apiClient.getCurrentUser()
        setUser(currentUser)
        setToken(result.token.access_token) // Set the new token in state
        
        // Sync settings from server after successful login
        await syncSettingsFromServer()
        
        return { success: true }
      } catch (error: any) {
        console.error("Failed to get user info after login:", error)
        return { 
          success: false, 
          error: "Login successful but failed to load user information. Please try again." 
        }
      }
    }
    
    return result
  }

  const logout = () => {
    setUser(null)
    setToken(null) // Clear token from state
    apiClient.clearToken()
    localStorage.removeItem("access_token")
    // Note: We don't clear localStorage settings on logout so they're available for next login
    // The settings context will handle syncing from server on next login
  }

  return (
    <AuthContext.Provider value={{ user, token, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}