"use client"

import React, { createContext, useContext, useEffect, useState, useCallback, useRef, useMemo } from "react"
import { apiClient } from "./api-client"

export interface PaginationSettings {
  showsManagement: number
  userManagement: number
  revenueLedger: number
  partnerPayments: number
  archivedShows: number
  feedbacks: number
  changeRequests: number
  splitHistory: number
}

export type ThemeColor = "emerald" | "blue" | "purple" | "red" | "orange" | "cyan" | "pink" | "indigo"
export type ThemeMode = "light" | "dark" | "system"
export type BorderRadiusStyle = "circle" | "squircle" | "rounded" | "square"
export type DensityMode = "compact" | "default"
export type CardStyle = "bordered" | "elevated" | "flat"
export type DateFormat = "MM/DD/YYYY" | "DD/MM/YYYY" | "YYYY-MM-DD"
export type TimeFormat = "12h" | "24h"
export type LandingPage = "dashboard" | "shows" | "revenue" | "partners" | "archived" | "settings"

export interface TableDensitySettings {
  revenueLedger: DensityMode
  shows: DensityMode
}

export interface UserSettings {
  // Appearance
  liquidGlassEnabled: boolean
  highContrastMode: boolean
  interactiveAnimationsEnabled: boolean
  shadowsEnabled: boolean
  themeColor: ThemeColor
  themeMode: ThemeMode
  borderRadiusStyle: BorderRadiusStyle
  tableDensity: TableDensitySettings
  cardStyle: CardStyle
  fontScale: number // 0.9 | 1 | 1.1 | 1.2
  reduceMotion: boolean
  
  // Localization & Formatting
  dateFormat: DateFormat
  timeFormat: TimeFormat
  
  // Behavior & UX
  defaultLandingPage: LandingPage
  sidebarCollapsed: boolean
  
  // Pagination
  globalPageSize: number | null // null means use individual settings
  pagination: PaginationSettings
  
  // Notifications
  toastDuration: number // in milliseconds
  
  // Security & Session
  sessionTimeout: number // in minutes (0 = never)
  
  // Developer
  developerOptionsEnabled: boolean
  debugMode: boolean
  apiEndpointOverride: string | null
  showApiResponseTimes: boolean
  developerConsoleLogs: DeveloperLog[]
}

export interface DeveloperLog {
  id: string
  timestamp: Date
  type: "info" | "success" | "warning" | "error" | "command"
  message: string
  details?: string
}

const DEFAULT_SETTINGS: UserSettings = {
  // Appearance
  liquidGlassEnabled: true,
  highContrastMode: false,
  interactiveAnimationsEnabled: true,
  shadowsEnabled: true,
  themeColor: "emerald",
  themeMode: "system",
  borderRadiusStyle: "circle",
  tableDensity: {
    revenueLedger: "default",
    shows: "default",
  },
  cardStyle: "elevated",
  fontScale: 1,
  reduceMotion: false,
  
  // Localization & Formatting
  dateFormat: "MM/DD/YYYY",
  timeFormat: "24h",
  
  // Behavior & UX
  defaultLandingPage: "dashboard",
  sidebarCollapsed: false,
  
  // Pagination
  globalPageSize: null,
  pagination: {
    showsManagement: 12,
    userManagement: 10,
    revenueLedger: 10,
    partnerPayments: 10,
    archivedShows: 12,
    feedbacks: 10,
    changeRequests: 10,
    splitHistory: 10,
  },
  
  // Notifications
  toastDuration: 5000, // 5 seconds
  
  // Security & Session
  sessionTimeout: 0, // 0 = never timeout
  
  // Developer
  developerOptionsEnabled: false,
  debugMode: false,
  apiEndpointOverride: null,
  showApiResponseTimes: false,
  developerConsoleLogs: [],
}

const STORAGE_KEY = "evergreen_user_settings"
const DEBOUNCE_DELAY = 1000 // 1 second debounce for saving to server

// Device-specific settings that should NOT sync to server
const DEVICE_SPECIFIC_KEYS: (keyof UserSettings)[] = ['apiEndpointOverride', 'debugMode', 'developerConsoleLogs', 'showApiResponseTimes']

interface SettingsContextType {
  settings: UserSettings
  updateSettings: (updates: Partial<UserSettings>) => void
  resetSettings: () => void
  getPageSize: (page: keyof PaginationSettings) => number
  getTableDensityClass: (table: keyof TableDensitySettings) => string
  isLoading: boolean
  syncSettingsFromServer: () => Promise<void>
  setThemeMode: (mode: ThemeMode) => void
  addDeveloperLog: (type: DeveloperLog["type"], message: string, details?: string) => void
  clearDeveloperLogs: () => void
  formatDate: (date: Date | string) => string
  formatTime: (date: Date | string) => string
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined)

// Helper to merge settings with defaults
function mergeSettings(stored: Partial<UserSettings> | null | undefined): UserSettings {
  if (!stored) return { ...DEFAULT_SETTINGS }
  
  // Migrate old table density structure to new structure
  let migratedTableDensity = { ...DEFAULT_SETTINGS.tableDensity }
  if (stored.tableDensity) {
    const oldDensity = stored.tableDensity as any
    // Migrate from old structure
    if (oldDensity.revenueLedger) {
      migratedTableDensity.revenueLedger = oldDensity.revenueLedger
    } else if (oldDensity.partnerPayments) {
      // partnerPayments now uses revenueLedger
      migratedTableDensity.revenueLedger = oldDensity.partnerPayments
    }
    
    if (oldDensity.shows) {
      migratedTableDensity.shows = oldDensity.shows
    } else if (oldDensity.showsManagement) {
      // showsManagement now uses shows
      migratedTableDensity.shows = oldDensity.showsManagement
    } else if (oldDensity.archivedShows) {
      // archivedShows now uses shows
      migratedTableDensity.shows = oldDensity.archivedShows
    }
  }
  
  return {
    ...DEFAULT_SETTINGS,
    ...stored,
    pagination: {
      ...DEFAULT_SETTINGS.pagination,
      ...(stored.pagination || {}),
    },
    tableDensity: migratedTableDensity,
  }
}

// Helper to remove device-specific keys for server storage
function getServerSettings(settings: UserSettings): Partial<UserSettings> {
  const serverSettings = { ...settings }
  for (const key of DEVICE_SPECIFIC_KEYS) {
    delete serverSettings[key]
  }
  return serverSettings
}

// Helper to get device-specific settings from localStorage
function getDeviceSettings(): Partial<UserSettings> {
  if (typeof window === 'undefined') return {}
  
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) {
      const parsed = JSON.parse(stored)
      const deviceSettings: Partial<UserSettings> = {}
      for (const key of DEVICE_SPECIFIC_KEYS) {
        if (parsed[key] !== undefined) {
          (deviceSettings as any)[key] = parsed[key]
        }
      }
      return deviceSettings
    }
  } catch (error) {
    console.error("Failed to get device settings:", error)
  }
  return {}
}

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS)
  const [mounted, setMounted] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const isUpdatingRef = useRef(false)
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const pendingServerSaveRef = useRef<UserSettings | null>(null)

  // Check if user is authenticated
  const isAuthenticated = useCallback(() => {
    if (typeof window === 'undefined') return false
    return !!(localStorage.getItem("access_token") || sessionStorage.getItem("access_token"))
  }, [])

  // Save settings to server (debounced)
  const saveToServer = useCallback(async (settingsToSave: UserSettings) => {
    if (!isAuthenticated()) return
    
    try {
      const serverSettings = getServerSettings(settingsToSave)
      await apiClient.updateUserSettings(serverSettings)
      console.log("Settings saved to server successfully")
    } catch (error) {
      console.error("Failed to save settings to server:", error)
    }
  }, [isAuthenticated])

  // Debounced save to server
  const debouncedSaveToServer = useCallback((settingsToSave: UserSettings) => {
    // Clear any pending timeout
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current)
    }
    
    // Store the pending settings
    pendingServerSaveRef.current = settingsToSave
    
    // Schedule the save
    saveTimeoutRef.current = setTimeout(() => {
      if (pendingServerSaveRef.current) {
        saveToServer(pendingServerSaveRef.current)
        pendingServerSaveRef.current = null
      }
    }, DEBOUNCE_DELAY)
  }, [saveToServer])

  // Sync settings from server
  const syncSettingsFromServer = useCallback(async () => {
    if (!isAuthenticated()) return
    
    try {
      setIsLoading(true)
      const serverSettings = await apiClient.getUserSettings()
      const deviceSettings = getDeviceSettings()
      
      // Merge server settings with device-specific settings
      const mergedSettings = mergeSettings({
        ...serverSettings,
        ...deviceSettings,
      })
      
      setSettings(mergedSettings)
      
      // Also update localStorage cache
      localStorage.setItem(STORAGE_KEY, JSON.stringify(mergedSettings))
      
      console.log("Settings synced from server")
    } catch (error) {
      console.error("Failed to sync settings from server:", error)
      // Fall back to localStorage
      try {
        const stored = localStorage.getItem(STORAGE_KEY)
        if (stored) {
          setSettings(mergeSettings(JSON.parse(stored)))
        }
      } catch (e) {
        console.error("Failed to load settings from localStorage:", e)
      }
    } finally {
      setIsLoading(false)
    }
  }, [isAuthenticated])

  // Load settings on mount
  useEffect(() => {
    const loadSettings = async () => {
      try {
        // First, load from localStorage for immediate use
        const stored = localStorage.getItem(STORAGE_KEY)
        if (stored) {
          const parsed = JSON.parse(stored)
          const mergedSettings = mergeSettings(parsed)
          setSettings(mergedSettings)
        }

        // If authenticated, sync from server (this will override with server settings)
        if (isAuthenticated()) {
          await syncSettingsFromServer()
        } else {
          setIsLoading(false)
        }
      } catch (error) {
        console.error("Failed to load settings:", error)
        setIsLoading(false)
      }
      setMounted(true)
    }

    loadSettings()
    
    // Cleanup timeout on unmount
    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current)
        // Save any pending changes immediately on unmount
        if (pendingServerSaveRef.current) {
          saveToServer(pendingServerSaveRef.current)
        }
      }
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // Listen for storage changes from other tabs/windows
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      // Ignore if this change came from the current tab
      if (isUpdatingRef.current) {
        return
      }
      
      if (e.key === STORAGE_KEY && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue)
          const mergedSettings = mergeSettings(parsed)
          setSettings(mergedSettings)
        } catch (error) {
          console.error("Failed to parse settings from storage event:", error)
        }
      }
    }

    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [])

  // Apply liquid glass setting to document
  useEffect(() => {
    if (!mounted) return
    
    if (settings.liquidGlassEnabled) {
      document.documentElement.classList.remove("no-liquid-glass")
    } else {
      document.documentElement.classList.add("no-liquid-glass")
    }
  }, [settings.liquidGlassEnabled, mounted])

  // Apply high contrast mode
  useEffect(() => {
    if (!mounted) return
    
    if (settings.highContrastMode) {
      document.documentElement.classList.add("high-contrast")
    } else {
      document.documentElement.classList.remove("high-contrast")
    }
  }, [settings.highContrastMode, mounted])

  // Apply interactive animations setting
  useEffect(() => {
    if (!mounted) return
    
    if (settings.interactiveAnimationsEnabled) {
      document.documentElement.classList.remove("no-interactive-animations")
    } else {
      document.documentElement.classList.add("no-interactive-animations")
    }
  }, [settings.interactiveAnimationsEnabled, mounted])

  // Apply shadows setting
  useEffect(() => {
    if (!mounted) return
    
    if (settings.shadowsEnabled) {
      document.documentElement.classList.remove("no-shadows")
    } else {
      document.documentElement.classList.add("no-shadows")
    }
  }, [settings.shadowsEnabled, mounted])

  // Apply theme color
  useEffect(() => {
    if (!mounted) return
    
    // Remove all theme color classes
    document.documentElement.classList.remove(
      "theme-emerald",
      "theme-blue",
      "theme-purple",
      "theme-red",
      "theme-orange",
      "theme-cyan",
      "theme-pink",
      "theme-indigo"
    )
    
    // Add current theme color class
    document.documentElement.classList.add(`theme-${settings.themeColor}`)
  }, [settings.themeColor, mounted])

  // Apply border radius style
  useEffect(() => {
    if (!mounted) return
    
    // Remove all border radius classes
    document.documentElement.classList.remove(
      "radius-circle",
      "radius-squircle",
      "radius-rounded",
      "radius-square"
    )
    
    // Add current border radius class
    document.documentElement.classList.add(`radius-${settings.borderRadiusStyle}`)
  }, [settings.borderRadiusStyle, mounted])


  // Apply card style
  useEffect(() => {
    if (!mounted) return
    
    // Remove all card style classes
    document.documentElement.classList.remove(
      "card-bordered",
      "card-elevated",
      "card-flat"
    )
    
    // Add current card style class
    document.documentElement.classList.add(`card-${settings.cardStyle}`)
  }, [settings.cardStyle, mounted])

  // Apply font scale
  useEffect(() => {
    if (!mounted) return
    
    document.documentElement.style.setProperty("--font-scale", settings.fontScale.toString())
    document.documentElement.style.fontSize = `${settings.fontScale * 100}%`
  }, [settings.fontScale, mounted])

  // Apply reduce motion
  useEffect(() => {
    if (!mounted) return
    
    if (settings.reduceMotion) {
      document.documentElement.classList.add("reduce-motion")
    } else {
      document.documentElement.classList.remove("reduce-motion")
    }
  }, [settings.reduceMotion, mounted])

  // Save settings to localStorage whenever they change
  useEffect(() => {
    if (!mounted) return
    
    try {
      const currentStored = localStorage.getItem(STORAGE_KEY)
      const newStored = JSON.stringify(settings)
      
      // Only update if the value actually changed to prevent unnecessary writes
      if (currentStored !== newStored) {
        isUpdatingRef.current = true
        localStorage.setItem(STORAGE_KEY, newStored)
        // Reset flag after a short delay to allow storage event to process
        setTimeout(() => {
          isUpdatingRef.current = false
        }, 100)
      }
    } catch (error) {
      console.error("Failed to save settings:", error)
      isUpdatingRef.current = false
    }
  }, [settings, mounted])

  const updateSettings = useCallback((updates: Partial<UserSettings>) => {
    setSettings((prev) => {
      // Check if any values actually changed by comparing with previous state
      const hasChanges = Object.keys(updates).some(key => {
        const typedKey = key as keyof UserSettings
        if (typedKey === 'pagination' && updates.pagination) {
          return JSON.stringify(prev.pagination) !== JSON.stringify(updates.pagination)
        }
        if (typedKey === 'tableDensity' && updates.tableDensity) {
          return JSON.stringify(prev.tableDensity) !== JSON.stringify(updates.tableDensity)
        }
        if (updates[typedKey] !== undefined) {
          return prev[typedKey] !== updates[typedKey]
        }
        return false
      })
      
      // If no changes, return previous state to prevent unnecessary re-renders
      if (!hasChanges) {
        return prev
      }
      
      const newSettings = { 
        ...prev, 
        ...updates,
        pagination: updates.pagination ? {
          ...prev.pagination,
          ...updates.pagination,
        } : prev.pagination,
        tableDensity: updates.tableDensity ? {
          ...prev.tableDensity,
          ...updates.tableDensity,
        } : prev.tableDensity,
      }
      
      // If globalPageSize is set, update all pagination settings
      if (updates.globalPageSize !== undefined && updates.globalPageSize !== null) {
        newSettings.pagination = {
          showsManagement: updates.globalPageSize,
          userManagement: updates.globalPageSize,
          revenueLedger: updates.globalPageSize,
          partnerPayments: updates.globalPageSize,
          archivedShows: updates.globalPageSize,
          feedbacks: updates.globalPageSize,
          changeRequests: updates.globalPageSize,
          splitHistory: updates.globalPageSize,
        }
      }
      
      // Debounce save to server if authenticated
      if (isAuthenticated()) {
        debouncedSaveToServer(newSettings)
      }
      
      return newSettings
    })
  }, [isAuthenticated, debouncedSaveToServer])

  const resetSettings = useCallback(() => {
    setSettings(DEFAULT_SETTINGS)
    
    // Save reset settings to server
    if (isAuthenticated()) {
      debouncedSaveToServer(DEFAULT_SETTINGS)
    }
  }, [isAuthenticated, debouncedSaveToServer])

  const getPageSize = useCallback((page: keyof PaginationSettings): number => {
    if (settings.globalPageSize !== null) {
      return settings.globalPageSize
    }
    // Return the page size, or fallback to default if not set (for backward compatibility)
    const pageSize = settings.pagination[page]
    if (pageSize !== undefined && pageSize !== null) {
      return pageSize
    }
    // Fallback to default for the specific page
    return DEFAULT_SETTINGS.pagination[page]
  }, [settings])

  const getTableDensityClass = useCallback((table: keyof TableDensitySettings): string => {
    const density = settings.tableDensity[table] || "default"
    return `table-density-${density}`
  }, [settings])

  // Set theme mode (light/dark/system) - this updates settings and should be called
  // alongside next-themes' setTheme for immediate UI update
  const setThemeMode = useCallback((mode: ThemeMode) => {
    updateSettings({ themeMode: mode })
  }, [updateSettings])

  // Add a log to the developer console
  const addDeveloperLog = useCallback((type: DeveloperLog["type"], message: string, details?: string) => {
    if (!settings.developerOptionsEnabled) return
    
    const newLog: DeveloperLog = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      type,
      message,
      details,
    }
    
    setSettings(prev => ({
      ...prev,
      developerConsoleLogs: [...prev.developerConsoleLogs.slice(-99), newLog], // Keep last 100 logs
    }))
  }, [settings.developerOptionsEnabled])

  // Clear all developer logs
  const clearDeveloperLogs = useCallback(() => {
    setSettings(prev => ({
      ...prev,
      developerConsoleLogs: [],
    }))
  }, [])

  // Format date according to user preference
  const formatDate = useCallback((date: Date | string): string => {
    const d = typeof date === 'string' ? new Date(date) : date
    if (isNaN(d.getTime())) return 'Invalid Date'
    
    const day = d.getDate().toString().padStart(2, '0')
    const month = (d.getMonth() + 1).toString().padStart(2, '0')
    const year = d.getFullYear()
    
    switch (settings.dateFormat) {
      case 'DD/MM/YYYY':
        return `${day}/${month}/${year}`
      case 'YYYY-MM-DD':
        return `${year}-${month}-${day}`
      case 'MM/DD/YYYY':
      default:
        return `${month}/${day}/${year}`
    }
  }, [settings.dateFormat])

  // Format time according to user preference
  const formatTime = useCallback((date: Date | string): string => {
    const d = typeof date === 'string' ? new Date(date) : date
    if (isNaN(d.getTime())) return 'Invalid Time'
    
    const hours = d.getHours()
    const minutes = d.getMinutes().toString().padStart(2, '0')
    
    if (settings.timeFormat === '24h') {
      return `${hours.toString().padStart(2, '0')}:${minutes}`
    }
    
    // 12h format
    const period = hours >= 12 ? 'PM' : 'AM'
    const hour12 = hours % 12 || 12
    return `${hour12}:${minutes} ${period}`
  }, [settings.timeFormat])

  // Memoize context value to prevent unnecessary re-renders
  const contextValue = useMemo(() => ({
    settings,
    updateSettings,
    resetSettings,
    getPageSize,
    getTableDensityClass,
    isLoading,
    syncSettingsFromServer,
    setThemeMode,
    addDeveloperLog,
    clearDeveloperLogs,
    formatDate,
    formatTime,
  }), [settings, updateSettings, resetSettings, getPageSize, getTableDensityClass, isLoading, syncSettingsFromServer, setThemeMode, addDeveloperLog, clearDeveloperLogs, formatDate, formatTime])

  return (
    <SettingsContext.Provider value={contextValue}>
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings() {
  const context = useContext(SettingsContext)
  if (context === undefined) {
    throw new Error("useSettings must be used within a SettingsProvider")
  }
  return context
}
