export type ChangeRequestStatus = 
  | "draft" | "wip" | "waiting_for_client" 
  | "waiting_for_evergreen" | "approved" | "cancelled"

export interface ChangeRequest {
  id: string
  title: string
  description: string
  status: ChangeRequestStatus
  initiated_by: string
  initiated_by_name?: string
  initiated_at: string
  updated_at?: string
  estimated_hours?: number
  estimated_cost?: number
  production_notes?: string
  production_manager_id?: string
  production_manager_name?: string | null
  production_filled_at?: string
  client_approved_by?: string
  client_approved_by_name?: string | null
  client_approved_at?: string
  evergreen_approved_by?: string
  evergreen_approved_by_name?: string | null
  evergreen_approved_at?: string
  cancelled_by?: string
  cancelled_by_name?: string | null
  cancelled_at?: string
  cancellation_reason?: string
}

export interface ChangeRequestCreate {
  title: string
  description: string
}

export interface ChangeRequestUpdate {
  estimated_hours?: number
  estimated_cost?: number
  production_notes?: string
}

export interface ChangeRequestCancel {
  cancellation_reason: string
}
