// Helper script to get local IP and start dev server with correct API URL
const { spawn, execSync } = require('child_process');
const os = require('os');
const fs = require('fs');
const path = require('path');

function getLocalIP() {
  const interfaces = os.networkInterfaces();
  // First, try to find Wi-Fi or Ethernet adapters (excluding Docker/virtual networks)
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      // Skip internal (loopback) and non-IPv4 addresses
      if (iface.family === 'IPv4' && !iface.internal) {
        // Exclude Docker and virtual network IPs (172.17.x.x, 172.31.x.x, etc.)
        const ipParts = iface.address.split('.');
        const firstOctet = parseInt(ipParts[0]);
        const secondOctet = parseInt(ipParts[1]);
        const isDockerNetwork = (firstOctet === 172 && (secondOctet >= 16 && secondOctet <= 31)) || 
                                (firstOctet === 192 && secondOctet === 168 && parseInt(ipParts[2]) === 29); // Prefer 192.168.29.x
        
        // Prefer Wi-Fi or Ethernet adapters, and prefer 192.168.29.x networks
        if (name.includes('Wi-Fi') || name.includes('Ethernet') || name.includes('WLAN')) {
          if (firstOctet === 192 && secondOctet === 168 && parseInt(ipParts[2]) === 29) {
            return iface.address; // Prefer 192.168.29.x
          }
        }
      }
    }
  }
  // Second pass: prefer 192.168.29.x networks
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        const ipParts = iface.address.split('.');
        const firstOctet = parseInt(ipParts[0]);
        const secondOctet = parseInt(ipParts[1]);
        if (firstOctet === 192 && secondOctet === 168 && parseInt(ipParts[2]) === 29) {
          return iface.address;
        }
      }
    }
  }
  // Fallback to first non-internal IPv4 (excluding Docker networks)
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        const ipParts = iface.address.split('.');
        const firstOctet = parseInt(ipParts[0]);
        const secondOctet = parseInt(ipParts[1]);
        // Exclude Docker networks (172.17-31.x.x)
        if (!(firstOctet === 172 && secondOctet >= 17 && secondOctet <= 31)) {
          return iface.address;
        }
      }
    }
  }
  return 'localhost';
}

const localIP = getLocalIP();
// Backend URL should always be localhost from the server's perspective
// (the proxy route runs server-side and connects to backend on same machine)
// Backend is running on port 8001 (Docker port mapping 8001:8000)
const backendUrl = 'http://localhost:8001';

console.log('🌐 Detected local IP:', localIP);
console.log('📡 Backend URL (for proxy):', backendUrl);
console.log('🔗 Frontend will use /api proxy route (avoids CORS issues)');
console.log('🚀 Starting Next.js dev server on network...\n');

// Create/update .env.local file
// Use /api as the API URL (Next.js proxy route) to avoid CORS issues
// Set BACKEND_URL to localhost since proxy runs server-side on same machine
const envLocalPath = path.join(__dirname, '..', '.env.local');
const envContent = `NEXT_PUBLIC_API_URL=/api
BACKEND_URL=${backendUrl}
`;
fs.writeFileSync(envLocalPath, envContent);
console.log('✅ Created .env.local with proxy configuration\n');
console.log('💡 Access the app at:');
console.log(`   - Desktop: http://localhost:3000`);
console.log(`   - Phone: http://${localIP}:3000\n`);
console.log('⚠️  Make sure your backend server is running on port 8001\n');

// Set environment variables and start Next.js
process.env.NEXT_PUBLIC_API_URL = '/api';
process.env.BACKEND_URL = backendUrl;
const child = spawn('npx', ['next', 'dev', '-H', '0.0.0.0'], {
  stdio: 'inherit',
  shell: true,
  env: { 
    ...process.env, 
    NEXT_PUBLIC_API_URL: '/api',
    BACKEND_URL: backendUrl
  }
});

// Handle process termination
process.on('SIGINT', () => {
  child.kill();
  process.exit();
});

