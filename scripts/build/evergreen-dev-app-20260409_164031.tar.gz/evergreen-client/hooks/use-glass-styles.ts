import { useEffect, useState } from "react"
import { useSettings } from "@/lib/settings-context"

type ButtonVariant = "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"

interface UseGlassStylesOptions {
  variant?: ButtonVariant
  hasCustomBg?: boolean
  hasEvergreenClass?: boolean
  customStyle?: React.CSSProperties
}

export function useGlassStyles({
  variant = "default",
  hasCustomBg = false,
  hasEvergreenClass = false,
  customStyle,
}: UseGlassStylesOptions = {}) {
  const [isDark, setIsDark] = useState(false)
  const { settings } = useSettings()

  useEffect(() => {
    const checkTheme = () => {
      setIsDark(document.documentElement.classList.contains("dark"))
    }
    checkTheme()

    const observer = new MutationObserver(checkTheme)
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    })

    return () => observer.disconnect()
  }, [])

  // Helper function to get primary color as rgba
  const getPrimaryColorRgba = (opacity: number): string => {
    if (typeof window === "undefined") {
      return isDark ? "rgba(52, 211, 153, 0.5)" : "rgba(16, 185, 129, 0.55)"
    }
    
    const primaryValue = getComputedStyle(document.documentElement)
      .getPropertyValue("--primary")
      .trim()
    
    if (!primaryValue) {
      return isDark ? "rgba(52, 211, 153, 0.5)" : "rgba(16, 185, 129, 0.55)"
    }
    
    // Check if primary value is in RGB format (3 numbers without %) or HSL format (has %)
    if (primaryValue.includes("%")) {
      // HSL format (e.g., "145 100% 35%")
      return `hsla(${primaryValue}, ${opacity})`
    } else {
      // RGB format (e.g., "16 185 129")
      const rgbValues = primaryValue.split(/\s+/).filter(v => v)
      if (rgbValues.length === 3) {
        return `rgba(${primaryValue}, ${opacity})`
      } else {
        // Fallback to HSL
        return `hsla(${primaryValue}, ${opacity})`
      }
    }
  }

  const getGlassStyles = (): React.CSSProperties => {
    if (variant === "link") return customStyle || {}

    // If liquid glass is disabled, return styles without backdrop-filter
    const baseStyles: React.CSSProperties = {
      ...(settings.liquidGlassEnabled
        ? {
            WebkitBackdropFilter: "blur(12px) saturate(180%)",
            backdropFilter: "blur(12px) saturate(180%)",
          }
        : {}),
      boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
      ...customStyle,
    }

    if (variant === "default") {
      // If evergreen-button class is present, only apply backdrop filter and shadow
      if (hasEvergreenClass) {
        return {
          ...baseStyles,
          ...(settings.liquidGlassEnabled
            ? {
                WebkitBackdropFilter: isDark
                  ? "blur(12px) saturate(200%) brightness(1.05)"
                  : "blur(12px) saturate(180%)",
                backdropFilter: isDark
                  ? "blur(12px) saturate(200%) brightness(1.05)"
                  : "blur(12px) saturate(180%)",
              }
            : {}),
        }
      }

      // If no custom background, apply default glass background using primary color
      if (!hasCustomBg && !customStyle?.backgroundColor) {
        baseStyles.backgroundColor = isDark
          ? getPrimaryColorRgba(0.5)
          : getPrimaryColorRgba(0.55)
        if (settings.liquidGlassEnabled) {
          baseStyles.WebkitBackdropFilter = isDark
            ? "blur(12px) saturate(200%) brightness(1.05)"
            : "blur(12px) saturate(180%)"
          baseStyles.backdropFilter = isDark
            ? "blur(12px) saturate(200%) brightness(1.05)"
            : "blur(12px) saturate(180%)"
        }
      }

      return baseStyles
    }

    if (variant === "destructive") {
      if (!hasCustomBg && !customStyle?.backgroundColor) {
        baseStyles.backgroundColor = "rgba(239, 68, 68, 0.2)"
      }
      return baseStyles
    }

    if (variant === "outline") {
      if (!customStyle?.backgroundColor) {
        baseStyles.backgroundColor = isDark
          ? "rgba(255, 255, 255, 0.05)"
          : "rgba(255, 255, 255, 0.1)"
      }
      return baseStyles
    }

    if (variant === "secondary") {
      if (!customStyle?.backgroundColor) {
        baseStyles.backgroundColor = isDark
          ? "rgba(255, 255, 255, 0.08)"
          : "rgba(255, 255, 255, 0.3)"
      }
      return baseStyles
    }

    if (variant === "ghost") {
      if (!customStyle?.backgroundColor) {
        baseStyles.backgroundColor = isDark
          ? "rgba(255, 255, 255, 0.03)"
          : "rgba(255, 255, 255, 0.05)"
      }
      return baseStyles
    }

    return baseStyles
  }

  return getGlassStyles()
}

