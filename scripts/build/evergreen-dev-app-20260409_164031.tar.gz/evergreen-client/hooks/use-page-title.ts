import { useLayoutEffect, useEffect, useRef } from "react"

/**
 * Hook to set the page title reliably.
 * Sets the title both synchronously (for immediate effect) and uses useLayoutEffect
 * to ensure it persists even if Next.js or other code tries to reset it.
 */
export function usePageTitle(title: string) {
  const titleRef = useRef(title)

  // Update ref when title changes
  useEffect(() => {
    titleRef.current = title
  }, [title])

  // Set title synchronously if we're on the client
  // This ensures it's set immediately during render, not waiting for effects
  if (typeof window !== "undefined") {
    document.title = title
  }

  // Use useLayoutEffect to set title synchronously before browser paint
  // This runs before useEffect and ensures the title is set early
  useLayoutEffect(() => {
    document.title = titleRef.current
  }, [title])

  // Also set in useEffect as a backup
  useEffect(() => {
    document.title = titleRef.current
  }, [title])

  // Watch for title changes and restore it if something else resets it to default
  useEffect(() => {
    if (typeof window === "undefined") return

    const desiredTitle = titleRef.current
    const defaultTitle = "Myco - Shows and Ledger Management"

    // Check periodically if title was reset to default
    const checkInterval = setInterval(() => {
      // Only restore if title was reset to the default (not if it's a different custom title)
      if (document.title === defaultTitle && desiredTitle !== defaultTitle) {
        document.title = desiredTitle
      }
    }, 200) // Check every 200ms

    // Also use MutationObserver to watch for title changes
    const observer = new MutationObserver(() => {
      // Only restore if title was reset to the default
      if (document.title === defaultTitle && desiredTitle !== defaultTitle) {
        document.title = desiredTitle
      }
    })

    // Observe changes to the title element
    const titleElement = document.querySelector("title")
    if (titleElement) {
      observer.observe(titleElement, {
        childList: true,
        subtree: true,
        characterData: true,
      })
    }

    return () => {
      clearInterval(checkInterval)
      observer.disconnect()
    }
  }, [title])
}

