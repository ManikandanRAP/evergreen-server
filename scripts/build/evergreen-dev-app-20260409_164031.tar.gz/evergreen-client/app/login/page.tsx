"use client"

import { useAuth } from "@/lib/auth-context"
import { useSettings } from "@/lib/settings-context"
import { useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import LoginForm from "@/components/login-form"
import { Loader2 } from "lucide-react"
import { usePageTitle } from "@/hooks/use-page-title"
import type { LandingPage } from "@/lib/settings-context"

export default function LoginPage() {
  const { user, isLoading } = useAuth()
  const { settings, isLoading: isLoadingSettings, updateSettings } = useSettings()
  const router = useRouter()
  const hasInitializedRef = useRef(false)

  usePageTitle("Login - Myco - Shows and Ledger Management")

  useEffect(() => {
    if (!isLoading && !isLoadingSettings && user && !hasInitializedRef.current) {
      hasInitializedRef.current = true

      // Map landing page settings to routes
      const landingPageRoutes: Record<string, string> = {
        dashboard: "/",
        shows: "/shows-management",
        revenue: "/revenue-ledger",
        partners: "/user-management",
        archived: "/archived-shows",
        settings: "/settings",
      }

      // Determine role-based default landing page
      const getRoleBasedDefaultLandingPage = (role: string | null | undefined): LandingPage => {
        if (role === "partner") {
          return "revenue"
        } else if (role === "internal_show_access") {
          return "shows"
        } else {
          // admin, internal_full_access, or any other role
          return "dashboard"
        }
      }

      const currentLandingPage = settings?.defaultLandingPage
      const roleBasedDefault = getRoleBasedDefaultLandingPage(user.role)

      // If user is partner or internal_show_access and their setting is still "dashboard" 
      // (the generic default), initialize it to their role-based default
      // This handles first-time users who haven't customized their landing page yet
      if ((user.role === "partner" || user.role === "internal_show_access") && 
          currentLandingPage === "dashboard") {
        // Initialize with role-based default
        updateSettings({ defaultLandingPage: roleBasedDefault })
        router.push(landingPageRoutes[roleBasedDefault])
        return
      }

      // Use the user's saved preference (or role-based default if not set)
      const landingPage = currentLandingPage || roleBasedDefault
      if (landingPageRoutes[landingPage]) {
        router.push(landingPageRoutes[landingPage])
      } else {
        // Fallback to dashboard if something goes wrong
        router.push("/")
      }
    }
  }, [user, isLoading, isLoadingSettings, settings, router, updateSettings])

  if (isLoading || isLoadingSettings) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="relative inline-flex items-center justify-center">
            <div 
              className="rounded-full p-4"
              style={{
                backgroundColor: "rgba(255, 255, 255, 0.05)",
                WebkitBackdropFilter: "blur(12px) saturate(180%)",
                backdropFilter: "blur(12px) saturate(180%)",
                boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
                border: "1px solid hsl(var(--border))",
              }}
            >
              <Loader2 className="h-8 w-8 text-primary animate-spin" />
            </div>
          </div>
          <p className="text-shimmer mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  if (user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="relative inline-flex items-center justify-center">
            <div 
              className="rounded-full p-4"
              style={{
                backgroundColor: "rgba(255, 255, 255, 0.05)",
                WebkitBackdropFilter: "blur(12px) saturate(180%)",
                backdropFilter: "blur(12px) saturate(180%)",
                boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
                border: "1px solid hsl(var(--border))",
              }}
            >
              <Loader2 className="h-8 w-8 text-primary animate-spin" />
            </div>
          </div>
          <p className="text-shimmer mt-4">Redirecting...</p>
        </div>
      </div>
    )
  }

  return <LoginForm />
}
