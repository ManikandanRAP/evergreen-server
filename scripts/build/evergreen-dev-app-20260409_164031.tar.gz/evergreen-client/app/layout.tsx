import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { AuthProvider } from "@/lib/auth-context"
import { SettingsProvider } from "@/lib/settings-context"
import { Toaster } from "@/components/ui/sonner"
import { ThemeColorUpdater } from "@/components/theme-color-updater"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Myco - Shows and Ledger Management",
  description: "Shows and Ledger Management Application for Myco Users and Partners",
  generator: 'v0.dev',
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon.ico',
    apple: '/favicon.ico',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" />
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" href="/favicon.ico" type="image/x-icon" />
        <link rel="shortcut icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/favicon.ico" />
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#ffffff" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        {/* Chrome on Android - navigation bar color */}
        <meta name="color-scheme" content="light dark" />
        {/* Set dark/light class before first paint so logo and theme match immediately (avoids logo flash on mobile) */}
        <script
          suppressHydrationWarning
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                try {
                  var theme = localStorage.getItem('theme');
                  var isDark = theme === 'dark' || (theme !== 'light' && typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches);
                  if (isDark) document.documentElement.classList.add('dark');
                  else document.documentElement.classList.remove('dark');
                } catch (e) {}
              })();
            `,
          }}
        />
        {/* Apply theme color synchronously before React hydrates to prevent flash */}
        <script
          suppressHydrationWarning
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                if (typeof window === 'undefined') return;
                try {
                  const stored = localStorage.getItem('evergreen_user_settings');
                  if (stored) {
                    const settings = JSON.parse(stored);
                    const themeColor = settings.themeColor || 'emerald';
                    // Remove all theme color classes
                    document.documentElement.classList.remove(
                      'theme-emerald',
                      'theme-blue',
                      'theme-purple',
                      'theme-red',
                      'theme-orange',
                      'theme-cyan',
                      'theme-pink',
                      'theme-indigo'
                    );
                    // Add current theme color class
                    document.documentElement.classList.add('theme-' + themeColor);
                  } else {
                    // Default to emerald if no settings found
                    document.documentElement.classList.add('theme-emerald');
                  }
                } catch (e) {
                  // Fallback to emerald on error
                  document.documentElement.classList.add('theme-emerald');
                }
              })();
            `,
          }}
        />
      </head>
      <body className={inter.className} suppressHydrationWarning>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <SettingsProvider>
            <ThemeColorUpdater />
            <AuthProvider>{children}</AuthProvider>
            <Toaster />
          </SettingsProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
