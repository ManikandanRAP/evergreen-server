"use client"

import SplitHistory from "@/components/split-history"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { usePageTitle } from "@/hooks/use-page-title"

export default function SplitHistoryPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()

  usePageTitle("Split History - Myco - Shows and Ledger Management")

  // Redirect non-admin users
  if (!isLoading && (!user || user.role?.toLowerCase() !== "admin")) {
    router.push("/administrator")
    return null
  }

  const handleBack = () => {
    router.back()
  }

  return <SplitHistory onBack={handleBack} />
}
