"use client"

import AdministratorPage from "@/components/administrator-page"
import { usePageTitle } from "@/hooks/use-page-title"

export default function AdministratorPageRoute() {
  usePageTitle("Administrator - Myco - Shows and Ledger Management")

  return <AdministratorPage />
}
