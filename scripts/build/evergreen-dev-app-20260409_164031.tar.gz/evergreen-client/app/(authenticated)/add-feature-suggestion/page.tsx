"use client"

import AddFeatureSuggestion from "@/components/add-feature-suggestion"
import { usePageTitle } from "@/hooks/use-page-title"

export default function AddFeatureSuggestionPage() {
  usePageTitle("Add Feature Suggestion - Myco - Shows and Ledger Management")

  return <AddFeatureSuggestion />
}
