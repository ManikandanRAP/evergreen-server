"use client"

import VendorSplitManagement from "@/components/vendor-split-management"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Toaster } from "@/components/ui/toaster"
import { usePageTitle } from "@/hooks/use-page-title"

export default function VendorSplitManagementPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()

  usePageTitle("Vendor Split Management - Myco - Shows and Ledger Management")

  // Redirect non-admin users
  if (!isLoading && (!user || user.role?.toLowerCase() !== "admin")) {
    router.push("/administrator")
    return null
  }

  const handleBack = () => {
    router.back()
  }

  return (
    <>
      <VendorSplitManagement onBack={handleBack} />
      <Toaster />
    </>
  )
}
