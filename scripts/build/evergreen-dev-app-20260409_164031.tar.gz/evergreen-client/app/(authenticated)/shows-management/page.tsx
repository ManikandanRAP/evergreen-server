"use client"

import ShowsManagement from "@/components/shows-management"
import { usePageTitle } from "@/hooks/use-page-title"

export default function ShowsManagementPage() {
  usePageTitle("Shows Management - Myco - Shows and Ledger Management")

  return <ShowsManagement />
}
