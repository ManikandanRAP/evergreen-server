"use client"

import React from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Info, CheckCircle, AlertCircle, Download, BookOpen, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"
import { usePageTitle } from "@/hooks/use-page-title"

export default function ImportShowsGuide() {
  const router = useRouter()

  usePageTitle("Import Shows Guide - Myco - Shows and Ledger Management")

  return (
    <div className="space-y-6">
      {/* Header with back button - Mobile: below title, Desktop: back button before title */}
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
        {/* Title and description - buttons align with title only */}
        <div className="flex-1">
          {/* Desktop: back button before title, Mobile: title first */}
          <div className="flex flex-col md:flex-row md:items-start gap-4">
            {/* Back button - Desktop: show before title, Mobile: hide here */}
            <Button variant="outline" onClick={() => router.back()} className="gap-2 w-fit hidden md:flex">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
            <div className="text-center md:text-left">
              <h1 className="text-xl sm:text-3xl font-bold text-emerald-600 tracking-tight">
                CSV Import Template Guide
              </h1>
              <p className="text-sm text-muted-foreground md:text-base">
                Complete reference for importing show data into the Myco Shows Management System
              </p>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between gap-2">
          {/* Last Updated - Button-styled for both desktop and mobile */}
          <div className="hidden md:block">
            <div className="px-3 py-2 border border-border rounded-full bg-background text-sm text-muted-foreground">
              Last Updated: Feb 24, 2026
            </div>
          </div>
          {/* Mobile: back button on left, last updated on right */}
          <div className="flex items-center justify-between w-full md:hidden">
            <Button variant="outline" onClick={() => router.back()} className="gap-2 w-fit">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
            <div className="px-3 py-2 border border-border rounded-full bg-background text-sm text-muted-foreground">
              Updated Feb 24, 2026
            </div>
          </div>
        </div>
      </div>

      {/* Quick Start */}
      <Card className="mb-6 sm:mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-emerald-800 dark:text-emerald-200">
            <Info className="w-5 h-5" />
            Quick Start Process
          </CardTitle>
          <CardDescription>
            Follow these steps to successfully import your show data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-background/50 rounded-lg border border-border">
              <div className="w-8 h-8 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto mb-2 text-sm font-bold">1</div>
              <h3 className="font-semibold text-emerald-800 dark:text-emerald-200">Download Template</h3>
              <p className="text-sm text-muted-foreground">Get the CSV template from the import dialog</p>
            </div>
            <div className="text-center p-4 bg-background/50 rounded-lg border border-border">
              <div className="w-8 h-8 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto mb-2 text-sm font-bold">2</div>
              <h3 className="font-semibold text-emerald-800 dark:text-emerald-200">Fill Your Data</h3>
              <p className="text-sm text-muted-foreground">Use this guide to fill out the template correctly</p>
            </div>
            <div className="text-center p-4 bg-background/50 rounded-lg border border-border">
              <div className="w-8 h-8 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto mb-2 text-sm font-bold">3</div>
              <h3 className="font-semibold text-emerald-800 dark:text-emerald-200">Upload & Import</h3>
              <p className="text-sm text-muted-foreground">Upload your completed CSV file</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Important Notes */}
      <Alert className="mb-6 sm:mb-8 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800">
        <AlertCircle className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
        <AlertDescription className="text-emerald-800 dark:text-emerald-200">
          <strong>Important:</strong> Only the <strong className="text-emerald-900 dark:text-emerald-100">"Show Name"</strong> field is required. All other fields are optional but help with better reporting and data completeness.
        </AlertDescription>
      </Alert>

      {/* Field Reference Tables */}
      <div className="space-y-8">
        
        {/* Core Show Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">1. Core Show Information</CardTitle>
            <CardDescription>Essential show details (Show Name is required)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Field</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Valid Values</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Example</TableHead>
                      <TableHead className="px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="bg-red-50 dark:bg-red-950/20">
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-red-800 dark:text-red-200 text-sm sm:text-base whitespace-nowrap">Show Name</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Any text</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"The Daily Show"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="destructive">Required</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Show Type</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Branded, Original, Partner, Hybrid</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Original"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Format</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">video, audio, both</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"audio"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Ranking Category</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">1, 2, 3, 4, 5 or Level 1-5</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"3"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Is Original Content</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Yes, No</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Yes"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Is Rate Card Show</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Yes, No</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"No"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Business & Relationship Details */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">2. Business & Relationship Details</CardTitle>
            <CardDescription>Partnership and business information</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Field</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Valid Values</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Example</TableHead>
                      <TableHead className="px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Relationship</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">strong, medium, weak</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"strong"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Start Date</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Multiple formats supported</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"01/15/2024"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-blue-600 dark:text-blue-400">See Date Formats</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Minimum Guarantee</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Yes, No</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Yes"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Ownership by Evergreen (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"75.5"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Cadence</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Daily, Weekly, Biweekly, Monthly, Ad hoc</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Weekly"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Content & Audience */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">3. Content & Audience</CardTitle>
            <CardDescription>Target audience and content details</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Field</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Valid Values</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Example</TableHead>
                      <TableHead className="px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Genre</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">23 predefined genres (see Genre Options below)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"True Crime"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case & hyphen insensitive</Badge>
                        <span className="block mt-1 text-muted-foreground">"Arts" maps to "Arts & Culture"</span>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Age Demographic</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">18-24, 25-34, 35-44, 45-54, 55+</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"25-34"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Exact values only</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Gender Demographic (M/F)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">MM/FF format</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"60/40"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Male/Female percentage</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Region Demographic</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Urban, Rural, Both</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Urban"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Average Length (Minutes)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Integer</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"30"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Whole number</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Ad Slots</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Integer</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"5"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Whole number</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Financial Data */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">4. Financial Data</CardTitle>
            <CardDescription>CPM and revenue information</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Field</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Valid Values</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Example</TableHead>
                      <TableHead className="px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Span CPM</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Decimal number</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"25.50"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">USD, no currency symbol</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Latest CPM</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">Decimal number</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"28.75"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">USD, no currency symbol</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Revenue 2023</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">Decimal number</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"125000.00"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">USD, no currency symbol</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Revenue 2024</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">Decimal number</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"150000.00"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">USD, no currency symbol</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Revenue 2025</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">Decimal number</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"175000.00"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">USD, no currency symbol</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Revenue Distribution Percentages */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">5. Revenue Distribution Percentages</CardTitle>
            <CardDescription>Percentage breakdown of revenue sources (0-100)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Field</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Valid Values</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Example</TableHead>
                      <TableHead className="px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Standard Ads (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"45.5"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Programmatic Ads/Span (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"30.0"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Side Bonus (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"5.0"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">YouTube Ads (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"10.0"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Subscriptions (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"8.5"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Sponsorship Ad FP - Lead (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"2.5"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Sponsorship Ad - Partner Lead (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"1.0"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Sponsorship Ad - Partner Sold (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"1.5"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Merchandise (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"3.0"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Branded Revenue (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"5.0"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Marketing Services Revenue (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"2.0"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Hands-off Percentages */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">6. Hands-off Percentages</CardTitle>
            <CardDescription>Percentage of revenue that is hands-off (0-100)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Field</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Valid Values</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Example</TableHead>
                      <TableHead className="px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Direct Customer - Hands Off (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"20.0"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">YouTube - Hands Off (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"15.0"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Subscription - Hands Off (%)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">0-100</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"10.0"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Decimal number, 0-100 range</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">7. Contact Information</CardTitle>
            <CardDescription>Primary contacts for the show</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Field</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Valid Values</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Example</TableHead>
                      <TableHead className="px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Primary Contact (Show)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Any text</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"John Doe"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Show's primary contact name</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Primary Contact (Host)</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Any text</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Jane Smith"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Host's primary contact name</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Evergreen Production Staff Name</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Any text</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Mike Johnson"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Evergreen staff member name</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* System & Operational */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">8. System & Operational</CardTitle>
            <CardDescription>System settings and operational flags</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Field</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Valid Values</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Example</TableHead>
                      <TableHead className="px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Subnetwork Name</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Any text</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Network A"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Subnetwork identifier</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Is Active</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Yes, No</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Yes"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                        <span className="ml-2 text-sm text-muted-foreground">Default: Yes</span>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Is Undersized</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Yes, No</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"No"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Primary Education Demographic</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Any text</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"College"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Primary education level</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Secondary Education Demographic</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Any text</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Graduate"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">Secondary education level</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Revenue Flags */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">9. Revenue Flags</CardTitle>
            <CardDescription>Boolean flags indicating revenue types (Yes/No)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Field</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Valid Values</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Example</TableHead>
                      <TableHead className="px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Has Sponsorship Revenue</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Yes, No</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Yes"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Has Non Evergreen Revenue</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">Yes, No</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"No"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Has Partner Ledger Access</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Yes, No</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"Yes"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 whitespace-nowrap">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Has Branded Revenue</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">Yes, No</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"No"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Has Marketing Revenue</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">Yes, No</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"No"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">Has Web Management Revenue</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base">Yes, No</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base">"No"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3">
                        <Badge variant="outline" className="text-orange-600 dark:text-orange-400">Case Insensitive</Badge>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Integration Data */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">10. Integration Data</CardTitle>
            <CardDescription>QuickBooks Online integration fields</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Field</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Valid Values</TableHead>
                      <TableHead className="border-r px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Example</TableHead>
                      <TableHead className="px-3 sm:px-4 py-2 sm:py-3 text-left font-semibold text-sm sm:text-base whitespace-nowrap">Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">QBO Show Name</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Any text</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"The Daily Show - QBO"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">QuickBooks Online show name</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 font-semibold text-sm sm:text-base whitespace-nowrap">QBO Show ID</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-green-600 dark:text-green-400 font-semibold text-sm sm:text-base whitespace-nowrap">Integer</TableCell>
                      <TableCell className="border-r px-3 sm:px-4 py-2 sm:py-3 text-purple-600 dark:text-purple-400 italic text-sm sm:text-base whitespace-nowrap">"12345"</TableCell>
                      <TableCell className="px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base whitespace-nowrap">QuickBooks Online show ID number</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Date Format Support */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">Date Format Support</CardTitle>
            <CardDescription>The Start Date field accepts multiple common date formats</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-foreground mb-3">Supported Formats:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <code className="bg-muted px-2 py-1 rounded">2024-01-15</code> (ISO Standard)
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <code className="bg-muted px-2 py-1 rounded">01/15/2024</code> (US Format)
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <code className="bg-muted px-2 py-1 rounded">1-15-24</code> (2-digit year)
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <code className="bg-muted px-2 py-1 rounded">12,31,23</code> (Comma separator)
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-3">Year Logic (2-digit years):</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <Info className="w-4 h-4 text-blue-500" />
                    Years 00-68 → 2000-2068
                  </li>
                  <li className="flex items-center gap-2">
                    <Info className="w-4 h-4 text-blue-500" />
                    Years 69-99 → 1969-1999
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Genre Options */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">Genre Options (23 Predefined)</CardTitle>
            <CardDescription>Use one of these values in the Genre column. Case and hyphen insensitive; &quot;Arts&quot; and &quot;Arts & Culture&quot; both map to Arts & Culture.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
              {[
                "History", "Human Resources", "Human Interest", "Fun & Nostalgia",
                "True Crime", "Financial", "News & Politics", "Movies",
                "Music", "Religious", "Health & Wellness", "Parenting",
                "Lifestyle", "Storytelling", "Literature", "Sports",
                "Pop Culture", "Arts & Culture", "Business", "Philosophy",
                "Self-Help", "Marketing", "Law"
              ].map((genre, index) => (
                <Badge key={index} variant="outline" className="p-2 text-center text-xs sm:text-sm">
                  {genre}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Common Validation Errors */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl text-red-800 dark:text-red-200">Common Validation Errors & Solutions</CardTitle>
            <CardDescription>How to fix the most common import errors</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg">
                <h4 className="font-semibold text-red-800 dark:text-red-200 mb-2">"Invalid Show Type"</h4>
                <p className="text-sm text-red-700 dark:text-red-300 mb-2">Use exactly: Branded, Original, Partner, or Hybrid (any case)</p>
                <p className="text-sm text-muted-foreground">❌ Invalid: "branded", "Podcast", "Video Series"</p>
                <p className="text-sm text-green-600 dark:text-green-400">✅ Valid: "original", "Original", "ORIGINAL", "hybrid", "Hybrid"</p>
              </div>
              
              <div className="p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg">
                <h4 className="font-semibold text-red-800 dark:text-red-200 mb-2">"Format must be MM/FF"</h4>
                <p className="text-sm text-red-700 dark:text-red-300 mb-2">Use MM/FF format for Gender Demographic</p>
                <p className="text-sm text-muted-foreground">❌ Invalid: "Male", "Female", "Both", "60-40"</p>
                <p className="text-sm text-green-600 dark:text-green-400">✅ Valid: "60/40", "70/30", "50/50"</p>
              </div>
              
              <div className="p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg">
                <h4 className="font-semibold text-red-800 dark:text-red-200 mb-2">"Invalid Age Demographic"</h4>
                <p className="text-sm text-red-700 dark:text-red-300 mb-2">Use exactly: 18-24, 25-34, 35-44, 45-54, 55+</p>
                <p className="text-sm text-muted-foreground">❌ Invalid: "18-34", "25-54", "Young Adult"</p>
                <p className="text-sm text-green-600 dark:text-green-400">✅ Valid: "25-34", "55+"</p>
              </div>

              <div className="p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg">
                <h4 className="font-semibold text-red-800 dark:text-red-200 mb-2">"Value must be between 0 and 100"</h4>
                <p className="text-sm text-red-700 dark:text-red-300 mb-2">All percentage fields must be between 0 and 100</p>
                <p className="text-sm text-muted-foreground">❌ Invalid: "150", "-10", "101"</p>
                <p className="text-sm text-green-600 dark:text-green-400">✅ Valid: "0", "50.5", "100"</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Best Practices */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl sm:text-2xl">Best Practices</CardTitle>
            <CardDescription>Tips for successful CSV imports</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3">Before Importing:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Test with a few shows first
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Use the preview feature to catch errors
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Fill as many fields as possible for better reporting
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-3">Data Quality:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Use consistent formatting for similar data types
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Keep your data current with regular updates
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Reference this guide while filling the template
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

    </div>
  )
}
