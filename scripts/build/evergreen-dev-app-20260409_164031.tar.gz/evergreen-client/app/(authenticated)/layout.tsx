"use client"

import { useAuth } from "@/lib/auth-context"
import { useRouter, usePathname } from "next/navigation"
import { useEffect, useState } from "react"
import DashboardNav from "@/components/dashboard-nav"
import MobileFloatingNav from "@/components/mobile-floating-nav"
import { cn } from "@/lib/utils"
import { Loader2 } from "lucide-react"

export default function AuthenticatedLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [animationKey, setAnimationKey] = useState(0)

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  // Single animation per page change
  useEffect(() => {
    setAnimationKey(prev => prev + 1)
  }, [pathname])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="relative inline-flex items-center justify-center">
            <div 
              className="rounded-full p-4"
              style={{
                backgroundColor: "rgba(255, 255, 255, 0.05)",
                WebkitBackdropFilter: "blur(12px) saturate(180%)",
                backdropFilter: "blur(12px) saturate(180%)",
                boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
                border: "1px solid hsl(var(--border))",
              }}
            >
              <Loader2 className="h-8 w-8 text-primary animate-spin" />
            </div>
          </div>
          <p className="text-shimmer mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null // Will redirect to login
  }

  return (
    <div className="min-h-screen">
      <DashboardNav
        onSidebarToggle={setIsSidebarCollapsed}
      />
      <div className={cn("transition-all duration-300 ease-in-out", isSidebarCollapsed ? "lg:pl-20" : "lg:pl-64")}>
        {/* Desktop version with animation */}
        <main 
          key={animationKey}
          className="hidden lg:block p-4 lg:p-8 pb-[100px] lg:pb-8 animate-in fade-in duration-300"
        >
          {children}
        </main>
        {/* Mobile version without animation */}
        <main className="block lg:hidden p-4 pb-[100px]">
          {children}
        </main>
      </div>
      <MobileFloatingNav />
    </div>
  )
}
