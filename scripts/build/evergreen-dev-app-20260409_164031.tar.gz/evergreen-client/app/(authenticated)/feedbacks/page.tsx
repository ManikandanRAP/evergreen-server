"use client"

import Feedbacks from "@/components/feedbacks"
import { usePageTitle } from "@/hooks/use-page-title"

export default function FeedbacksPage() {
  usePageTitle("Feedbacks - Myco - Shows and Ledger Management")

  return <Feedbacks />
}
