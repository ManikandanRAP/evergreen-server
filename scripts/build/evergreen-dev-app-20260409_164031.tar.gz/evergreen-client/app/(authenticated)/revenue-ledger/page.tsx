"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import RevenueLedger from "@/components/revenue-ledger"
import { Loader2 } from "lucide-react"
import { usePageTitle } from "@/hooks/use-page-title"

export default function RevenueLedgerPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  usePageTitle("Revenue Ledger - Myco - Shows and Ledger Management")

  useEffect(() => {
    if (!isLoading && user && user.role === "internal_show_access") {
      router.push("/shows-management")
    }
  }, [user, isLoading, router])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="relative inline-flex items-center justify-center">
            <div 
              className="rounded-full p-4"
              style={{
                backgroundColor: "rgba(255, 255, 255, 0.05)",
                WebkitBackdropFilter: "blur(12px) saturate(180%)",
                backdropFilter: "blur(12px) saturate(180%)",
                boxShadow: "0 2px 16px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.03)",
                border: "1px solid hsl(var(--border))",
              }}
            >
              <Loader2 className="h-8 w-8 text-primary animate-spin" />
            </div>
          </div>
          <p className="text-shimmer mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  if (user?.role === "internal_show_access") {
    return null
  }

  return <RevenueLedger />
}
