"use client"

import ChangeRequests from "@/components/change-requests"
import { usePageTitle } from "@/hooks/use-page-title"

export default function ChangeRequestsPage() {
  usePageTitle("Change Requests - Myco - Shows and Ledger Management")

  return <ChangeRequests />
}
