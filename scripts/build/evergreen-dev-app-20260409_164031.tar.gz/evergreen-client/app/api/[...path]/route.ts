import { NextRequest, NextResponse } from 'next/server'

// Default to localhost; on some Windows/Docker setups the backend is reachable via IPv6 (::1).
// We also implement a small fallback retry to 127.0.0.1 when possible.
const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8001'

// Ensure long-running requests (e.g. DB imports) don't get cut off by the Next.js route handler.
export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path } = await params
  return proxyRequest(request, path, 'GET')
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path } = await params
  return proxyRequest(request, path, 'POST')
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path } = await params
  return proxyRequest(request, path, 'PUT')
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path } = await params
  return proxyRequest(request, path, 'DELETE')
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path } = await params
  return proxyRequest(request, path, 'PATCH')
}

export async function OPTIONS(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path } = await params
  return proxyRequest(request, path, 'OPTIONS')
}

async function proxyRequest(
  request: NextRequest,
  pathSegments: string[],
  method: string
) {
  try {
    const path = pathSegments.join('/')
    const url = new URL(path, `${BACKEND_URL}/`)
    
    // Get the query string from the original request
    const searchParams = request.nextUrl.searchParams.toString()
    if (searchParams) {
      url.search = searchParams
    }

    // Get request body if it exists (IMPORTANT: do not read multipart bodies into text;
    // forward the stream so large file uploads keep working and don't exhaust memory).
    let body: BodyInit | null | undefined
    const contentType = request.headers.get('content-type')
    const contentLength = request.headers.get('content-length')
    
    // Only try to parse body if there's actual content
    const hasBody = method !== 'GET' && method !== 'HEAD' && request.body && contentLength !== '0'
    
    if (hasBody) {
      try {
        if (contentType?.includes('multipart/form-data')) {
          body = request.body
        } else if (contentType?.includes('application/json')) {
          const text = await request.text()
          // Only parse if there's actual content
          if (text && text.trim()) {
            body = text
          }
        } else if (contentType?.includes('application/x-www-form-urlencoded')) {
          body = await request.text()
        } else {
          // Fall back to streaming when possible
          body = request.body ?? (await request.text())
        }
      } catch {
        // No body or empty body - that's fine for some requests like PATCH without payload
      }
    }

    // Forward headers (excluding host and connection)
    const headers = new Headers()
    request.headers.forEach((value, key) => {
      if (
        key.toLowerCase() !== 'host' &&
        key.toLowerCase() !== 'connection' &&
        key.toLowerCase() !== 'content-length'
      ) {
        headers.set(key, value)
      }
    })

    const doFetch = async (u: string) => {
      // Allow long-running operations like DB import/export.
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 30 * 60_000) // 30 minutes
      return await fetch(u, {
        method,
        headers,
        body,
        signal: controller.signal,
        // Required when streaming request bodies in Node.js fetch
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        duplex: body && typeof body !== 'string' ? 'half' : undefined,
      }).finally(() => clearTimeout(timeoutId))
    }

    // Make the request to the backend (with a conservative fallback retry).
    let response: Response
    try {
      response = await doFetch(url.toString())
    } catch (e) {
      // Retry only if the body is replayable (string/undefined). Multipart streams cannot be replayed.
      const replayable = body == null || typeof body === 'string'
      const currentBase = new URL('/', `${BACKEND_URL}/`).toString().replace(/\/$/, '')
      const altBase = currentBase.includes('localhost')
        ? currentBase.replace('localhost', '127.0.0.1')
        : currentBase.includes('127.0.0.1')
          ? currentBase.replace('127.0.0.1', 'localhost')
          : null

      if (replayable && altBase) {
        const altUrl = new URL(path, `${altBase}/`)
        if (searchParams) altUrl.search = searchParams
        response = await doFetch(altUrl.toString())
      } else {
        throw e
      }
    }

    // Create response with same status and headers
    const proxiedResponse = new NextResponse(response.status === 204 ? null : response.body, {
      status: response.status,
      statusText: response.statusText,
    })

    // Copy response headers
    response.headers.forEach((value, key) => {
      // Skip headers that Next.js manages
      if (
        key.toLowerCase() !== 'content-encoding' &&
        key.toLowerCase() !== 'transfer-encoding'
      ) {
        proxiedResponse.headers.set(key, value)
      }
    })

    return proxiedResponse
  } catch (error) {
    console.error('Proxy error:', error)
    return NextResponse.json(
      { 
        detail: error instanceof Error 
          ? `Failed to connect to backend: ${error.message}` 
          : 'Failed to connect to backend'
      },
      { status: 502 }
    )
  }
}

