# Testing Theme Colors on Android PWA

## How to Test Android Status Bar and Navigation Bar Theme Colors

### Prerequisites
1. ✅ PWA is installed on your Android phone
2. ✅ You're logged in to the app
3. ✅ Backend is accessible (login works)

### Testing Steps

#### 1. **Install the PWA (if not already installed)**
   - Open the app in Chrome on your phone
   - Tap the menu (three dots) → "Install app" or "Add to Home Screen"
   - Launch the app from the home screen icon

#### 2. **Test Light Mode**
   - Open the installed PWA
   - Tap the theme toggle button (sun/moon icon) in the navigation
   - Select **"Light"**
   - **Observe the status bar**: Should be **white** or light colored
   - **Observe the navigation bar**: Should be **white** or light colored
   - The status bar icons should be **dark** (black/gray)

#### 3. **Test Dark Mode**
   - Tap the theme toggle button again
   - Select **"Dark"**
   - **Observe the status bar**: Should be **dark** (almost black: #0a0a0a)
   - **Observe the navigation bar**: Should be **dark** (almost black)
   - The status bar icons should be **light** (white)

#### 4. **Test System Theme**
   - Tap the theme toggle button
   - Select **"System"**
   - Change your phone's system theme (Settings → Display → Dark theme)
   - The status bar and navigation bar should update automatically

### What to Look For

**✅ Working Correctly:**
- Status bar matches the app's background color
- Navigation bar matches the app's background color
- Status bar icons change color for contrast (dark icons on light bar, light icons on dark bar)
- Changes happen immediately when switching themes

**❌ Not Working:**
- Status bar stays the same color regardless of theme
- Navigation bar doesn't change
- Status bar icons don't change color
- No visual feedback when switching themes

### Troubleshooting

1. **If status bar doesn't change:**
   - Make sure you're using the **installed PWA**, not just the browser
   - Close and reopen the PWA app
   - Clear Chrome cache and reinstall the PWA

2. **If only partial change:**
   - Check Android version (works best on Android 5.0+)
   - Some Android skins (OneUI, MIUI) may override theme colors
   - Try on Chrome browser first, then install as PWA

3. **Verify meta tag is updating:**
   - Open Chrome DevTools on your computer
   - Connect your phone via USB debugging
   - Check the `<meta name="theme-color">` tag in the HTML
   - It should change when you toggle themes

### Technical Details

The theme color is controlled by:
- `<meta name="theme-color">` tag - Updated dynamically by `ThemeColorUpdater` component
- Values:
  - Light mode: `#ffffff` (white)
  - Dark mode: `#0a0a0a` (very dark gray/black)

The component updates the meta tag in real-time when the theme changes.

